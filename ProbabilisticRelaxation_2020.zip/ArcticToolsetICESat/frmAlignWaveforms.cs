﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Xml;


using DataStructDefinition;

namespace ArcticToolsetICESat
{
    public partial class frmAlignWaveforms : Form
    {
        #region public variables
        string openWaveformDataPathName;
        string pSaveBinaryWFDataPathName;


        public frmAlignWaveforms()
        {
            InitializeComponent();
        }

        private void btnOpen1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Title = "Open waveform binary data";
            openDialog.Filter = "DAT（*.dat)|*.dat";
            openDialog.ShowDialog();
            openWaveformDataPathName = openDialog.FileName;
            textBox1.Enabled = false;
            textBox1.Text = openWaveformDataPathName;
            openDialog.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "dat files (*.dat)|*.dat|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.Title = "Save Waveform Data";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pSaveBinaryWFDataPathName = saveFileDialog1.FileName;
                textBox2.Text = pSaveBinaryWFDataPathName;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region Main Entry

        private void btnOK_Click(object sender, EventArgs e)
        {
            #region checke parameters
            if (textBox1.Text == null)
            {
                MessageBox.Show("Choose smoothed waveforms.");
                return;
            }
            if (textBox2.Text == null)
            {
                MessageBox.Show("Specify the outputs.");
                return;
            }

            #endregion

            #region read in the smoothed binary waveform data
            //Dictionary key = lakeID_Date
            List<FPWaveformDataNode> pSmoothedFootprintWFdata = readinSmoothedWF(openWaveformDataPathName);
            #endregion

            #region convert waveform to volt unit and label each gate using elevation
            Dictionary<string, List<alignWaveformDataNode>> pAlignedWaveformDataDict = ConvertAndLabelTimeTag(pSmoothedFootprintWFdata);
            #endregion

            #region extract the effective Signal part
            //Dictionary key = lakeID_Date
            Dictionary<string, List<effectiveSignalDataNode>> pExtractedWFSignalDict = extractAllEffectiveSignal(pAlignedWaveformDataDict);
            #endregion

            #region save the aligned waveform and the extracted signal part
            saveAlignedAndExtractedWF(pAlignedWaveformDataDict, pExtractedWFSignalDict);
            #endregion

            this.Close();
        }

        private void saveAlignedAndExtractedWF(Dictionary<string, List<alignWaveformDataNode>> pAlignedWaveformDataDict, Dictionary<string, List<effectiveSignalDataNode>> pExtractedWFSignalDict)
        {
            int charPosition = pSaveBinaryWFDataPathName.LastIndexOf("\\");
            string saveFilePath = pSaveBinaryWFDataPathName.Substring(0, charPosition + 1);

            List<Type> knownTypes = new List<Type> { typeof(List<alignWaveformDataNode>) };
            DataContractSerializer serializer = new DataContractSerializer(typeof(Dictionary<string, List<alignWaveformDataNode>>), knownTypes);

            System.IO.FileStream filestream = new System.IO.FileStream(saveFilePath + "Step2_AlignedFullWF.dat", FileMode.Create);
            serializer.WriteObject(filestream, pAlignedWaveformDataDict);

            List<Type> knownTypes2 = new List<Type> { typeof(List<effectiveSignalDataNode>) };
            DataContractSerializer serializer2 = new DataContractSerializer(typeof(Dictionary<string, List<effectiveSignalDataNode>>), knownTypes2);

            System.IO.FileStream filestream2 = new System.IO.FileStream(saveFilePath + "Step2_AlignedSignalExtractedWF.dat", FileMode.Create);
            serializer2.WriteObject(filestream2, pExtractedWFSignalDict);


            filestream.Close();
            filestream2.Close();



        }

        #endregion

        #region functions for extracting effective signal part
        private Dictionary<string, List<effectiveSignalDataNode>> extractAllEffectiveSignal(Dictionary<string, List<alignWaveformDataNode>> pAlignedWaveformDataDict)
        {
            Dictionary<string, List<effectiveSignalDataNode>> pEffectiveSignalDict = new Dictionary<string, List<effectiveSignalDataNode>>();

            foreach (KeyValuePair<string, List<alignWaveformDataNode>> pKeyValue in pAlignedWaveformDataDict)
            {
                List<effectiveSignalDataNode> pExtractWFlist = new List<effectiveSignalDataNode>();

                string lakeAndDate = pKeyValue.Key;
                List<alignWaveformDataNode> pWFlist = pKeyValue.Value;

                foreach (alignWaveformDataNode pSingleWF in pWFlist)
                {
                    effectiveSignalDataNode pEffectiveWFnode = extractSingleWaveform(pSingleWF);

                    pExtractWFlist.Add(pEffectiveWFnode);
                }

                pEffectiveSignalDict.Add(lakeAndDate, pExtractWFlist);
            }

            return pEffectiveSignalDict;
        }

        private effectiveSignalDataNode extractSingleWaveform(alignWaveformDataNode pSingleWF)
        {
            effectiveSignalDataNode pExtractedWFpart = new effectiveSignalDataNode();

            pExtractedWFpart.FootprintID = pSingleWF.FootprintID;
            pExtractedWFpart.MinVolt = pSingleWF.MinVolt;


            float tempBegGateElev = pSingleWF.EndGateElev - pSingleWF.SigBegOffset;
            float tempEndGateElev = pSingleWF.EndGateElev - pSingleWF.SigEndOffset;

            //Get the gate number closest to the begGateElev and endGateElev
            int begGate, endGate;
            begGate = getClosestGateNum(tempBegGateElev, pSingleWF.TimeLabelledByElev);
            endGate = getClosestGateNum(tempEndGateElev, pSingleWF.TimeLabelledByElev);

            if (begGate < 0) begGate = 0;

            pExtractedWFpart.BegGate = begGate;
            pExtractedWFpart.BegGateElev = pSingleWF.TimeLabelledByElev[begGate];

            float[] pFullWF = pSingleWF.VoltWaveform;
            float[] pFullSmthedWF = pSingleWF.SmthVoltWaveform;
            int signalLength = endGate - begGate;
            float[] pSignalPartWF;
            float[] PSmthSignalPartWF;

            int upBound;
            if (endGate + 2 > 543)
            {
                upBound = 543;
                pSignalPartWF = new float[543 - begGate + 1];
                PSmthSignalPartWF = new float[543 - begGate + 1];
            }
            else
            {
                upBound = endGate + 2;
                pSignalPartWF = new float[signalLength + 3];
                PSmthSignalPartWF = new float[signalLength + 3];
            }

            int j = 0;
            for (int i = begGate; i <= upBound; i++)
            {
                pSignalPartWF[j] = pFullWF[i];
                PSmthSignalPartWF[j] = pFullSmthedWF[i];

                j++;
            }

            pExtractedWFpart.SignalWaveform = pSignalPartWF;
            pExtractedWFpart.SmoothedSignalWaveform = PSmthSignalPartWF;
            pExtractedWFpart.NoiseLevel = pSingleWF.NoiseLevel;
            pExtractedWFpart.DefaultGauFitSTD = pSingleWF.DefaultGauFitSTD;
            pExtractedWFpart.SNR = pSingleWF.SNR;


            return pExtractedWFpart;
        }

        private int getClosestGateNum(float begGateElev, float[] timeRepByElev)
        {
            int gateNum = int.MinValue;

            List<float> timeElev = new List<float>(timeRepByElev);

            float closestValue = timeElev.Aggregate((x, y) => Math.Abs(x - begGateElev) < Math.Abs(y - begGateElev) ? x : y);
            gateNum = timeElev.IndexOf(closestValue);

            return gateNum;
        }


        #endregion

        #region functions for converting WF to volts & labelling time tab using elev, determine Gate shift for each FP
        private Dictionary<string, List<alignWaveformDataNode>> ConvertAndLabelTimeTag(List<FPWaveformDataNode> pSmoothedFootprintWFdata)
        {
            Dictionary<string, List<alignWaveformDataNode>> pAlignedWaveformDataDict = new Dictionary<string, List<alignWaveformDataNode>>();
            foreach (FPWaveformDataNode smoothedWFnode in pSmoothedFootprintWFdata)
            {
                alignWaveformDataNode pNewAlignWFnode = new alignWaveformDataNode();

                pNewAlignWFnode.Date = smoothedWFnode.DateTime;
                pNewAlignWFnode.Elev = smoothedWFnode.Elev;
                pNewAlignWFnode.ElevMaxAmp = smoothedWFnode.ElevMaxAmp;
                pNewAlignWFnode.Geoid = smoothedWFnode.Geoid;
                //the End Gate Elev has already been corrected by EGM96
                pNewAlignWFnode.EndGateElev = smoothedWFnode.EndGateElev;//smoothedWFnode.Elev + smoothedWFnode.LdRngOff;// +smoothedWFnode.Geoid;
                pNewAlignWFnode.FootprintID = smoothedWFnode.FootprintID;
                pNewAlignWFnode.GranulNum = smoothedWFnode.GranulNum;
                pNewAlignWFnode.LakeID = smoothedWFnode.LakeID;
                pNewAlignWFnode.Latitude = smoothedWFnode.Latitude;
                pNewAlignWFnode.LdRgOffset = smoothedWFnode.LdRngOff;
                pNewAlignWFnode.Longitude = smoothedWFnode.Longitude;
                pNewAlignWFnode.SecondIndex = smoothedWFnode.SecondIndex;
                pNewAlignWFnode.SigBegOffset = smoothedWFnode.SignalBegin;
                pNewAlignWFnode.SigEndOffset = smoothedWFnode.SignalEnd;
                pNewAlignWFnode.DefaultGauFitSTD = smoothedWFnode.DefaultGauFitSTD;
                pNewAlignWFnode.SNR = smoothedWFnode.SNR;
                pNewAlignWFnode.ValidateDEM = smoothedWFnode.ValidateDEM;

                float pTempNoise = smoothedWFnode.Threshold;
                if (pTempNoise < 128) pNewAlignWFnode.NoiseLevel = Convert.ToSingle(0.006675 * pTempNoise - 0.19528);
                else pNewAlignWFnode.NoiseLevel = Convert.ToSingle(0.006198 * pTempNoise - 0.13442);

                float[] voltWaveform = convertToVolts(smoothedWFnode.Waveform);
                pNewAlignWFnode.VoltWaveform = voltWaveform;

                float[] smthVoltWaveform = convertToVolts(smoothedWFnode.SmoothedWF);
                pNewAlignWFnode.SmthVoltWaveform = smthVoltWaveform;

                float[] timeLabelElev = calElevTimeLabel(pNewAlignWFnode.EndGateElev, smoothedWFnode.TimeTag);
                pNewAlignWFnode.TimeLabelledByElev = timeLabelElev;

                string neighborhoodName = smoothedWFnode.LakeID.ToString() + "_" + smoothedWFnode.DateTime.ToString();

                if (pAlignedWaveformDataDict.ContainsKey(neighborhoodName))
                {
                    List<alignWaveformDataNode> pTempAlignWFlist = pAlignedWaveformDataDict[neighborhoodName];
                    pTempAlignWFlist.Add(pNewAlignWFnode);
                }
                else
                {
                    List<alignWaveformDataNode> pTempAlignWFlist = new List<alignWaveformDataNode>();
                    pTempAlignWFlist.Add(pNewAlignWFnode);
                    pAlignedWaveformDataDict.Add(neighborhoodName, pTempAlignWFlist);
                }
                //pNewAlignWFnode.GateShift
            }

            Dictionary<string, List<alignWaveformDataNode>> pAlignedWFDict = new Dictionary<string, List<alignWaveformDataNode>>();
            foreach (KeyValuePair<string, List<alignWaveformDataNode>> keyValue in pAlignedWaveformDataDict)
            {
                List<alignWaveformDataNode> tempAlignWFlist = keyValue.Value;

                float maxEndGateElev = -10000;
                foreach (alignWaveformDataNode alignNode in tempAlignWFlist)
                {
                    if (alignNode.EndGateElev > maxEndGateElev) maxEndGateElev = alignNode.EndGateElev;
                }

                List<alignWaveformDataNode> newAlignNodeList = new List<alignWaveformDataNode>();
                foreach (alignWaveformDataNode alignNode2 in tempAlignWFlist)
                {
                    float tempEndGate = alignNode2.EndGateElev;
                    float gateShift = (maxEndGateElev - tempEndGate) / 0.149896f;
                    float[] voltWF = alignNode2.VoltWaveform;
                    List<float> pTempList = new List<float>(voltWF);
                    pTempList.Sort();
                    float minVolt = pTempList[0];//find the min volt value in this waveform

                    alignWaveformDataNode newNode = alignNode2;
                    newNode.GateShift = gateShift;
                    newNode.MinVolt = minVolt;
                    newAlignNodeList.Add(newNode);
                }

                pAlignedWFDict.Add(keyValue.Key, newAlignNodeList);
            }


            return pAlignedWFDict;
        }

        private float[] convertToVolts(float[] pWaveformDNcount)
        {
            int length = pWaveformDNcount.Length;
            float[] voltWaveform = new float[length];

            for (int i = 0; i < length; i++)
            {
                if (pWaveformDNcount[i] < 128) voltWaveform[i] = Convert.ToSingle(0.006675 * pWaveformDNcount[i] - 0.19528);
                else voltWaveform[i] = Convert.ToSingle(0.006198 * pWaveformDNcount[i] - 0.13442);
            }

            return voltWaveform;
        }

        private float[] calElevTimeLabel(float endGateElev, float[] timeTagList)
        {
            int length = timeTagList.Length;
            float[] timeTagLabeledbyElev = new float[length];

            List<float> pTempList = new List<float>(timeTagList);
            pTempList.Sort((x, y) => -1 * x.CompareTo(y));//find the max time tag

            float maxTime = pTempList[0];

            for (int i = 0; i < length; i++)
            {
                float time = timeTagList[i];
                timeTagLabeledbyElev[i] = endGateElev + 0.149896f * (maxTime + 0.5f - time);
            }

            return timeTagLabeledbyElev;
        }

        #endregion

        #region functions for reading in smoothed waveform data
        private List<FPWaveformDataNode> readinSmoothedWF(string openWaveformDataPathName)
        {
            string fromTypeFullName = "System.Collections.Generic.List`1[[DataStructDefinition.FPWaveformDataNode, ArcticToolsetICESat, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null]]";
            string fromType = "DataStructDefinition.FPWaveformDataNode";

            string toTypeFullName = "System.Collections.Generic.List`1[DataStructDefinition.FPWaveformDataNode]";
            string toType = "DataStructDefinition.FPWaveformDataNode";

            SerializeAndDeserialize pSerialAndDeserial = new SerializeAndDeserialize();

            List<FPWaveformDataNode> temp = pSerialAndDeserial.deSeriralizeData(openWaveformDataPathName, fromTypeFullName, fromType, toTypeFullName, toType);

            return temp;
        }
        #endregion


    }


}
