﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace ArcticToolsetICESat
{
    public class GaussianFitting : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public GaussianFitting()
        {
        }

        protected override void OnClick()
        {
            frmGaussianFitting pForm = new frmGaussianFitting();
            pForm.ShowDialog();

            ArcMap.Application.CurrentTool = null;
        }

        protected override void OnUpdate()
        {
        }
    }
}
