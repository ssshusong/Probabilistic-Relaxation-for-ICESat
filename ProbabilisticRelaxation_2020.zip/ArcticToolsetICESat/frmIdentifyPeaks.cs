﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Xml;
using System.Linq;

using DataStructDefinition;

namespace ArcticToolsetICESat
{
    public partial class frmIdentifyPeaks : Form
    {
        #region public variable
        string openWFsignalPathName;
        string saveBinaryWFsignalPathName;

        //decide the indicator for peak identification
        bool UseOnly2ndDer = false;
        bool UseOnly1stDer = false;
        bool Use1stAnd2ndDer = false;
        bool Use1stOr2ndDer = true;

        //smooth for 1st derivative, kernal sigma
        float p1stDerSmoothSigma = 0.0f;

        //distance control, merge the two peaks if the distance between them is less than the value below
        //distance 1 is calculated following 
        //Kailath, T. (1967), The Divergence and Bhattacharyya Distance Measures in Signal Selection, IEEE Transactions on Communication Technology, 15(1), 52-60.
        float distanceControl;
        float distance1 = 0.3f;
        //distance2 is the difference between two peaks
        float distance2 = 3.0f;
        //determine which distance formula should be used; True --> calPeakDistance (Kailath), False --> calPeakDistance2 (location difference)
        bool DisFlag = false;

        //determine whether the peak being fully merged or partly merged (need second judgement) 
        bool fullMerge = true;




        public frmIdentifyPeaks()
        {
            InitializeComponent();
        }

        private void btnOpen1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Title = "Open waveform signal data";
            openDialog.Filter = "DAT（*.dat)|*.dat";
            openDialog.ShowDialog();
            openWFsignalPathName = openDialog.FileName;
            textBox1.Enabled = true;
            textBox1.Text = openWFsignalPathName;
            openDialog.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "dat files (*.dat)|*.dat|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.Title = "Save identified gaussian peaks";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                saveBinaryWFsignalPathName = saveFileDialog1.FileName;
                textBox2.Text = saveBinaryWFsignalPathName;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region Main entry
        private void btnOK_Click(object sender, EventArgs e)
        {
            #region check parameters
            if (textBox1.Text == null)
            {
                MessageBox.Show("Choose waveforms signal data.");
                return;
            }
            if (textBox2.Text == null)
            {
                MessageBox.Show("Specify the outputs.");
                return;
            }

            #endregion

            #region readin waveform signal data
            //Dictionary key = lakeID_Date
            Dictionary<string, List<effectiveSignalDataNode>> pExtratedWFSignalDict = readinExtractedWF(openWFsignalPathName);

            #endregion

            #region calculate the first and the second forward derivative
            //Dictionary key = lakeID_Date
            Dictionary<string, List<FirstSecondDerivativeNode>> pFirstSecondDerivative = calFirstSecondDerivative(pExtratedWFSignalDict);
            
            #endregion

            #region make a initial estimation of the parameters of each gaussian peaks
            //Dictionary key = lakeID_Date
            Dictionary<string, List<InitialWFPeakParameterNode>> pInitialWFPeakParameterDict = estimateInitialParameter(pFirstSecondDerivative);
            #endregion

            #region save the output
            saveWFgaussianPara(pInitialWFPeakParameterDict);
            #endregion

            this.Close();

        }

        private void saveWFgaussianPara(Dictionary<string, List<InitialWFPeakParameterNode>> pInitialWFPeakParameterDict)
        {
            List<Type> knownTypes = new List<Type> {typeof(List<InitialWFPeakParameterNode>)};
            DataContractSerializer serializer = new DataContractSerializer(typeof(Dictionary<string, List<InitialWFPeakParameterNode>>),knownTypes);

            System.IO.FileStream fileStream = new FileStream(saveBinaryWFsignalPathName, FileMode.Create);
            serializer.WriteObject(fileStream,pInitialWFPeakParameterDict);

            fileStream.Close();
        }

        #endregion

        #region read in extracted waveform signal data
        private Dictionary<string, List<effectiveSignalDataNode>> readinExtractedWF(string openWFsignalPathName)
        {
            FileStream ReadStream = new FileStream(openWFsignalPathName, FileMode.Open);

            List<Type> knownTypes = new List<Type> { typeof(List<effectiveSignalDataNode>) };
            DataContractSerializer serializer = new DataContractSerializer(typeof(Dictionary<string, List<effectiveSignalDataNode>>), knownTypes);

            XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(ReadStream, new XmlDictionaryReaderQuotas());//CreateTextReader(ReadStream, new XmlDictionaryReaderQuotas());

            Dictionary<string, List<effectiveSignalDataNode>> ptemp = serializer.ReadObject(reader, true) as Dictionary<string, List<effectiveSignalDataNode>>;

            ReadStream.Close();

            return ptemp;
        }

        #endregion

        #region calculate the forward first and second derivative for each waveform gate
        private Dictionary<string, List<FirstSecondDerivativeNode>> calFirstSecondDerivative(Dictionary<string, List<effectiveSignalDataNode>> pExtratedWFSignalDict)
        {
            Dictionary<string, List<FirstSecondDerivativeNode>> pF1stS2ndDerivativeDict = new Dictionary<string, List<FirstSecondDerivativeNode>>();

            foreach(KeyValuePair<string, List<effectiveSignalDataNode>> pKeyValue in pExtratedWFSignalDict)
            {
                List<FirstSecondDerivativeNode> pDerivativeList = new List<FirstSecondDerivativeNode>();

                List<effectiveSignalDataNode> pWFSignalList = pKeyValue.Value;

                foreach(effectiveSignalDataNode pSingleSignal in pWFSignalList)
                {
                    FirstSecondDerivativeNode pNewDerivativeNode = new FirstSecondDerivativeNode();
                    long pFootprintID = pSingleSignal.FootprintID;

                    float[] smoothWF_2ndDer = pSingleSignal.SmoothedSignalWaveform;
                    float[] initialWF = pSingleSignal.SignalWaveform;
                    float[] WFusedToCal1stDer;

                    pNewDerivativeNode.FootprintID = pFootprintID;
                    pNewDerivativeNode.MinVolt = pSingleSignal.MinVolt;
                    pNewDerivativeNode.SmoothedSignalWaveform = pSingleSignal.SmoothedSignalWaveform;
                    pNewDerivativeNode.InitialWaveform = pSingleSignal.SignalWaveform;
                    pNewDerivativeNode.NoiseLevel = pSingleSignal.NoiseLevel;

                    #region smooth WF to calculate 1st Derivative
                    if (p1stDerSmoothSigma > 0)
                    {
                        float[] smoothWF_1stDer = new float[initialWF.Length];
                        for (int i = 0; i < initialWF.Length; i++)
                        {
                            Dictionary<float, float> pWFTimeIntervalAndValue;
                            findNeighborWithinFilterWidth(i, initialWF, out pWFTimeIntervalAndValue);
                            if (pWFTimeIntervalAndValue.Count == 1) smoothWF_1stDer[i] = initialWF[i];
                            else
                            {
                                Dictionary<float, float> pWeightedWF = calculateWeight(pWFTimeIntervalAndValue);
                                float pSmthWFvalue = 0;
                                foreach (KeyValuePair<float, float> keyvalue in pWeightedWF)
                                {
                                    pSmthWFvalue = pSmthWFvalue + Math.Abs(Convert.ToSingle(keyvalue.Key)) * Convert.ToSingle(keyvalue.Value);
                                }

                                smoothWF_1stDer[i] = pSmthWFvalue;
                            }

                        }
                        WFusedToCal1stDer = smoothWF_1stDer;
                    }
                    else WFusedToCal1stDer = initialWF;

                    #endregion

                    int length = smoothWF_2ndDer.Length;

                    float[] F1stDerivative = new float[length - 1];
                    float[] S2ndDerivative = new float[length - 2];

                    for(int i = 0; i<length-2;i++)
                    {
                        //calculate the first derivative using foward difference
                        F1stDerivative[i] = WFusedToCal1stDer[i + 1] - WFusedToCal1stDer[i];
                        //calculate the second derivative using foward difference
                        S2ndDerivative[i] = smoothWF_2ndDer[i + 2] - 2 * smoothWF_2ndDer[i + 1] + smoothWF_2ndDer[i];
                    }

                    pNewDerivativeNode.FirstDerivative = F1stDerivative;
                    pNewDerivativeNode.SecondDerivative = S2ndDerivative;
                    pDerivativeList.Add(pNewDerivativeNode);
                }

                pF1stS2ndDerivativeDict.Add(pKeyValue.Key, pDerivativeList);
            }

            return pF1stS2ndDerivativeDict;
        }

        private void findNeighborWithinFilterWidth(int j, float[] pInitiWF, out Dictionary<float, float> pWFTimeIntervalAndValue)
        {
            //temp setting
            float totalNeighborNum = 4;
            float[] timeTagList = Enumerable.Range(1, pInitiWF.Length).Select(x => (float)x).ToArray();
            pWFTimeIntervalAndValue = new Dictionary<float, float>();

            bool flag = true;
            int i = 0;
            while (flag)
            {
                bool flag1 = true;
                bool flag2 = true;

                if ((j - i >= 0))
                {
                    if ((timeTagList[j] - timeTagList[j - i]) <= (totalNeighborNum / 2))
                        pWFTimeIntervalAndValue.Add(timeTagList[j] - timeTagList[j - i], pInitiWF[j - i]);
                    else
                        flag1 = false;

                }
                else if (flag1) flag1 = false;

                if ((j + i < pInitiWF.Length))
                {
                    if ((j + i) > j)
                    {
                        if ((timeTagList[j + i] - timeTagList[j]) <= (totalNeighborNum / 2))
                            pWFTimeIntervalAndValue.Add(timeTagList[j] - timeTagList[j + i], pInitiWF[j + i]);
                        else
                            flag2 = false;
                    }

                }
                else if (flag2) flag2 = false;

                i++;

                if (flag1 == false & flag2 == false)
                    flag = false;
            }
        }

        private Dictionary<float, float> calculateWeight(Dictionary<float, float> pWFTimeIntervalAndValue)
        {
            Dictionary<float, float> WeightAndValue1 = new Dictionary<float, float>();
            Dictionary<float, float> WeightAndValue2 = new Dictionary<float, float>();

            float pTotalWeight = 0;
            foreach (KeyValuePair<float, float> keyValue in pWFTimeIntervalAndValue)
            {
                float pTimeInterval = keyValue.Key;
                float pWeight = gaussianAlgorithm(Math.Abs(pTimeInterval), p1stDerSmoothSigma);
                pTotalWeight = pWeight + pTotalWeight;
                if (pTimeInterval < 0) WeightAndValue1.Add(-pWeight, keyValue.Value);
                else WeightAndValue1.Add(pWeight, keyValue.Value);
            }

            foreach (KeyValuePair<float, float> keyValue in WeightAndValue1)
            {
                float pNormalizedWeight = keyValue.Key / pTotalWeight;
                WeightAndValue2.Add(pNormalizedWeight, keyValue.Value);
            }

            return WeightAndValue2;
        }

        private float gaussianAlgorithm(float pTimeInterval, float pGaussianSigma)
        {
            float e = Convert.ToSingle(Math.E), pPi = Convert.ToSingle(Math.PI);
            float pWeight = Convert.ToSingle((1 / (pGaussianSigma * (Math.Sqrt(2 * pPi)))) * (1 / Math.Pow(e, (Math.Pow(pTimeInterval, 2) / (2 * Math.Pow(pGaussianSigma, 2))))));

            return pWeight;
        }

        #endregion

        #region functions for the estimation of initial parameters 
        private Dictionary<string, List<InitialWFPeakParameterNode>> estimateInitialParameter(Dictionary<string, List<FirstSecondDerivativeNode>> pFirstSecondDerivative)
        {
            Dictionary<string, List<InitialWFPeakParameterNode>> pInitialParameterDict = new Dictionary<string, List<InitialWFPeakParameterNode>>();

            foreach(KeyValuePair<string, List<FirstSecondDerivativeNode>> pKeyValue in pFirstSecondDerivative)
            {
                List<InitialWFPeakParameterNode> pInitialParameterList = new List<InitialWFPeakParameterNode>();

                List<FirstSecondDerivativeNode> pWFDerivativeList = pKeyValue.Value;

                foreach(FirstSecondDerivativeNode psingleDerivativeNode in pWFDerivativeList)
                {
                    InitialWFPeakParameterNode pInitialWFparaNode = new InitialWFPeakParameterNode();

                    float[] p1stDerivative = psingleDerivativeNode.FirstDerivative;
                    float[] p2ndDerivative = psingleDerivativeNode.SecondDerivative;
                    float[] pSmoothWF = psingleDerivativeNode.SmoothedSignalWaveform;
                    float[] pInitialWF = psingleDerivativeNode.InitialWaveform;
                    float pNoiseLevel = psingleDerivativeNode.NoiseLevel;

                    long pFootprintID = psingleDerivativeNode.FootprintID;

                    List<singleGaussianParameters> pSingleParameters = new List<singleGaussianParameters>();
                    Dictionary<float, float> inflectionPairs = searchInflectionPairs(p2ndDerivative);
                    Dictionary<int, int> summitPoints = searchSummitPoints(p1stDerivative);

                    if (Use1stAnd2ndDer || UseOnly2ndDer)
                        pSingleParameters = determineInitPara(inflectionPairs, pSmoothWF, pNoiseLevel, summitPoints);
                    if(UseOnly1stDer||Use1stOr2ndDer)
                        pSingleParameters = determineInitPara_1stDerOnly(pSmoothWF, pNoiseLevel, summitPoints, inflectionPairs);

                    pSingleParameters.Sort((x, y) => x.TimeLocation.CompareTo(y.TimeLocation));

                    if (DisFlag) distanceControl = distance1;
                    else distanceControl = distance2;
                    //Merge adjacent peaks with the distance  less than distanceControl
                    if (distanceControl > 0)
                    {
                        List<singleGaussianParameters> mergedPeakList = null;
                        if (pSingleParameters.Count > 1) mergedPeakList = DiscardMergeGauPeaks(pSingleParameters, pInitialWF);
                        else mergedPeakList = pSingleParameters;
                        pInitialWFparaNode.AllPeakParameters = mergedPeakList;
                    }
                    else pInitialWFparaNode.AllPeakParameters = pSingleParameters;

                    pInitialWFparaNode.FootprintID = pFootprintID;
                    pInitialWFparaNode.MinVolt = psingleDerivativeNode.MinVolt;
                    pInitialWFparaNode.NoiseLevel = psingleDerivativeNode.NoiseLevel;

                    pInitialParameterList.Add(pInitialWFparaNode);
                }

                pInitialParameterDict.Add(pKeyValue.Key, pInitialParameterList);
            }

            return pInitialParameterDict;            
        }

        private Dictionary<int, int> searchSummitPoints(float[] p1stDerivative)
        {
            Dictionary<int, int> summitPoints = new Dictionary<int, int>();

            for (int i = 1; i < p1stDerivative.Length-2; i++)
            {
                //summits at the beginning and the end will not be counted
                if (p1stDerivative[i] >= 0 && p1stDerivative[i + 1] < 0) summitPoints.Add(i, i + 1);
            }

            return summitPoints;
        }

        private List<singleGaussianParameters> determineInitPara_1stDerOnly(float[] pSignalWF, float pNoiseLevel, Dictionary<int, int> summitPoints, Dictionary<float, float> inflectionPairs)
        {
            List<singleGaussianParameters> pSingleWFgaussianPara = new List<singleGaussianParameters>();

            foreach (KeyValuePair<int,int> pKeyValue in summitPoints)
            {
                float amplitude = Math.Max(pSignalWF[pKeyValue.Key], pSignalWF[pKeyValue.Value]);
                if (amplitude <= pNoiseLevel) continue;

                float location = pKeyValue.Key + 1 + 0.5f;

                float sigma = 1.0f;

                singleGaussianParameters pSinPara = new singleGaussianParameters();
                pSinPara.Amplitude = amplitude;
                pSinPara.Sigma = sigma;
                pSinPara.TimeLocation = location;

                pSingleWFgaussianPara.Add(pSinPara);
            }

            #region use 2nd derivative, either meet 1st der or 2nd der
            if (Use1stOr2ndDer)
            {
                foreach (KeyValuePair<float, float> pInfPair in inflectionPairs)
                {
                    int pStartPos = Convert.ToInt32(Math.Ceiling(pInfPair.Key)) - 1;
                    int pEndPos = Convert.ToInt32(Math.Floor(pInfPair.Value)) - 1;

                    //discard the peak with 1 bin width
                    if (pStartPos == pEndPos) continue;

                    bool containSummit = false;
                    foreach (KeyValuePair<int, int> summit in summitPoints)
                    {
                        if (summit.Key >= pStartPos && summit.Key <= pEndPos) { containSummit = true; break; }
                        if (summit.Value >= pStartPos && summit.Value <= pEndPos) { containSummit = true; break; }
                    }

                    if (containSummit) continue;
                    else
                    {
                        singleGaussianParameters pSinPara = new singleGaussianParameters();

                        float maxAmp = -999;
                        //int maxPosition = -999;

                        for (int i = pStartPos; i < pEndPos + 1; i++)
                        {
                            if (pSignalWF[i] > maxAmp)
                            {
                                maxAmp = pSignalWF[i];
                                //maxPosition = i + 1;
                            }
                        }

                        pSinPara.Amplitude = maxAmp;
                        pSinPara.Sigma = 1.0f;
                        pSinPara.TimeLocation = (pStartPos + pEndPos) / 2 + 1;

                        pSingleWFgaussianPara.Add(pSinPara);
                    }

                }
            }

            #endregion



            return pSingleWFgaussianPara;
        }

        private Dictionary<float, float> searchInflectionPairs(float[] pDerivative)
        {
            int length = pDerivative.Length;

            //key is the first inflection, value is the second inflection
            Dictionary<float, float> inflectionPairs = new Dictionary<float, float>();

            float firstInflection = -1, secondInflection = -1;
            bool firstFlag = false, secondFlag = false;
            for (int i = 1; i < length - 1; i++)//control the boundary, therefore i starts from 0 and ends at lenght -1
            {
                if (!firstFlag && !secondFlag)
                {
                    //no inflection has been located, searching for the first inflection
                    if (pDerivative[i - 1] > 0 && pDerivative[i] == 0 && pDerivative[i + 1] < 0)
                    {
                        firstFlag = true;
                        firstInflection = i + 1;
                    }
                     
                    if (pDerivative[i] > 0 && pDerivative[i + 1] < 0)
                    {
                        firstFlag = true;
                        firstInflection = i + 1 + 0.5f;
                    }

                    if (pDerivative[i-1] > 0 && pDerivative[i] < 0)
                    {
                        firstFlag = true;
                        firstInflection = i + 0.5f;
                    }
                }
                
                if (firstFlag && !secondFlag)
                {
                    //the first inflection point has been located, so searching for the second inflection
                    if (pDerivative[i - 1] < 0 && pDerivative[i] == 0 && pDerivative[i + 1] > 0)
                    {
                        secondFlag = true;
                        secondInflection = i + 1;
                    }

                    if (pDerivative[i] < 0 && pDerivative[i + 1] > 0)
                    {
                        secondFlag = true;
                        secondInflection = i + 1 + 0.5f;
                    }
                }
                
                if (firstFlag && secondFlag)
                {
                    //Both inflections were located, searching for the next pair
                    inflectionPairs.Add(firstInflection, secondInflection);

                    firstFlag = false;
                    secondFlag = false;
                }
            }

            return inflectionPairs;
        }

        private List<singleGaussianParameters> determineInitPara(Dictionary<float, float> inflectionPairs, float[] pSignalWF, float noiseLevel, Dictionary<int, int> summitPoints)
        {
            List<singleGaussianParameters> pSingleWFgaussianPara = new List<singleGaussianParameters>();
            
            int length = pSignalWF.Length;

            foreach (KeyValuePair<float, float> pInfPair in inflectionPairs)
            {
                float maxAmp = -999;
                int maxPosition = -999;

                int pStartPos = Convert.ToInt32(Math.Ceiling(pInfPair.Key)) - 1;
                int pEndPos = Convert.ToInt32(Math.Floor(pInfPair.Value)) - 1;

                for (int i = pStartPos; i < pEndPos + 1; i++)
                {
                    if (pSignalWF[i] > maxAmp)
                    {
                        maxAmp = pSignalWF[i];
                        maxPosition = i + 1;
                    }
                }

                #region 1st derivative control, meet both 1st and 2nd Derivatives
                if (Use1stAnd2ndDer)
                {
                    //discard the peak with 1 bin width
                    if (pStartPos == pEndPos) continue;

                    bool containSummit = false;
                    foreach (KeyValuePair<int, int> summit in summitPoints)
                    {
                        if (summit.Key >= pStartPos && summit.Key <= pEndPos) { containSummit = true; break; }
                        if (summit.Value >= pStartPos && summit.Value <= pEndPos) { containSummit = true; break; }
                    }

                    if (!containSummit) continue;
                }
                #endregion

                //throw away the peak with amplitude lower than the noise level
                if (maxAmp <= noiseLevel) continue;

                float sigma= (pInfPair.Value - pInfPair.Key) / 2;
                //if ((maxPosition - pInfPair.Key) >= (pInfPair.Value - maxPosition)) sigma = (pInfPair.Value - maxPosition);
                //else sigma = maxPosition - pInfPair.Key;

                singleGaussianParameters pSinPara = new singleGaussianParameters();
                pSinPara.Amplitude = maxAmp;
                pSinPara.Sigma = sigma;
                pSinPara.TimeLocation = maxPosition; // pInfPair.Key + (pInfPair.Value - pInfPair.Key) / 2; //

                pSingleWFgaussianPara.Add(pSinPara);
            }

                return pSingleWFgaussianPara;
        }

        private List<singleGaussianParameters> DiscardMergeGauPeaks(List<singleGaussianParameters> fittedUnNormPara, float[] pInitialWaveForm)
        {
            //key is the ID of the peak merged from old peaks
            Dictionary<int, singleGaussianParameters> pMergedPeakParaDict = new Dictionary<int, singleGaussianParameters>();

            ////remove the old peak if the amplitude is less than the Amplitude-control     
            //fittedUnNormPara.RemoveAll(item => item.Amplitude < absPeakAmpControl);

            ////remove the old peak if the amplitude is less than the Sigma-control     
            //fittedUnNormPara.RemoveAll(item => item.Sigma < absPeakSigControl);

            if (!(fittedUnNormPara.Count > 1)) return fittedUnNormPara;

            //sort the list
            fittedUnNormPara.Sort((x, y) => x.TimeLocation.CompareTo(y.TimeLocation));

            //Calculate distance of the adjacent two peaks, the key is the first peak number
            Dictionary<int, float> distanceTable = new Dictionary<int, float>();

            //Calculate peak-valley ratio: min(WFi)/[max(Amp1,Amp2)]
            Dictionary<int, float> peakValleyTable = new Dictionary<int, float>();

            int peakCount = fittedUnNormPara.Count;
            for (int i = 0; i < peakCount - 1; i++)
            {
                //get the 1st peak para
                singleGaussianParameters firstPeakPara = fittedUnNormPara[i];
                //get the 2nd peak para
                singleGaussianParameters secondPeakPara = fittedUnNormPara[i + 1];

                float pDistance;
                if (DisFlag) pDistance = calPeakDistance(firstPeakPara, secondPeakPara);
                else pDistance = calPeakDistance2(firstPeakPara, secondPeakPara);

                //key is the position of the 1st peak
                distanceTable.Add(i, pDistance);

                float peakValleyRatio = calPeakValleyRatio(firstPeakPara, secondPeakPara, pInitialWaveForm);

                peakValleyTable.Add(i, peakValleyRatio);
            }

            //sort the distance table, ascending order
            distanceTable = distanceTable.OrderBy(x => x.Value).ToDictionary(x => x.Key, x => x.Value);

            //the two peaks with the smallest distance will be merged firstly
            //And the mapping of this two-to-one merge will be noted down in the table below
            //key is the old-peak ID, value is the newly merged peak ID
            int newlyMergePeakID = 0;
            Dictionary<int, int> p2to1Map = new Dictionary<int, int>();
            foreach (KeyValuePair<int, float> pDisKeyValue in distanceTable)
            {
                int firstPeakID = pDisKeyValue.Key;
                int secondPeakID = firstPeakID + 1;

                //get the peak-valley ratio
                float peakValleyRatio = peakValleyTable[firstPeakID];

                //get the two peaks
                singleGaussianParameters p1stPeak = fittedUnNormPara[firstPeakID];
                singleGaussianParameters p2ndPeak = fittedUnNormPara[secondPeakID];

                ////compare |T1-T2| to |sig1+sig2|
                //float dT = p2ndPeak.TimeLocation - p1stPeak.TimeLocation;
                //float plusSig = p1stPeak.Sigma + p2ndPeak.Sigma;

                float pDistance = pDisKeyValue.Value;
                if ((pDistance <= distanceControl) && (peakValleyRatio >= 0.95))// || dT<plusSig)
                {
                    #region

                    //if the two peaks were both not mereged to the other peaks in previous step
                    if (!p2to1Map.ContainsKey(firstPeakID) && !p2to1Map.ContainsKey(secondPeakID))
                    {


                        //merge the two peaks
                        singleGaussianParameters pNewPeak = doTheMerge(p1stPeak, p2ndPeak);

                        pMergedPeakParaDict.Add(newlyMergePeakID, pNewPeak);

                        p2to1Map.Add(firstPeakID, newlyMergePeakID);
                        p2to1Map.Add(secondPeakID, newlyMergePeakID);

                        newlyMergePeakID++;

                        continue;
                    }

                    //check either of these two peaks has already or not been merged into other peaks
                    //if so, calculate the distance between the newly merged peak and the old peak
                    //the first peak was merged to the other peak in previous step, but the second was not
                    if (p2to1Map.ContainsKey(firstPeakID) && !p2to1Map.ContainsKey(secondPeakID))
                    {
                        //get the newly merged peak
                        int mergedPeakID = p2to1Map[firstPeakID];
                        singleGaussianParameters pNewMergedPeak = pMergedPeakParaDict[mergedPeakID];


                        if (!fullMerge)
                        {
                            //calculate the distance between the newly-merged-peak and the second old-peak
                            float pNewOldDistance;
                            if (DisFlag) pNewOldDistance = calPeakDistance(pNewMergedPeak, p2ndPeak);
                            else pNewOldDistance = calPeakDistance2(pNewMergedPeak, p2ndPeak);


                            ////compare |T2-Tnew| to |sig_new+sig2|
                            //float dTnew = Math.Abs(p2ndPeak.TimeLocation - pNewMergedPeak.TimeLocation);
                            //float plusSigNew = p2ndPeak.Sigma + pNewMergedPeak.Sigma;

                            //merged the peaks if the distance less than the control value
                            if (pNewOldDistance < distanceControl)// || dTnew < plusSigNew)
                            {
                                singleGaussianParameters pNewPeak = doTheMerge(pNewMergedPeak, p2ndPeak);

                                pMergedPeakParaDict[mergedPeakID] = pNewPeak;
                                p2to1Map.Add(secondPeakID, mergedPeakID);
                            }
                        }
                        else
                        {
                            singleGaussianParameters pNewPeak = doTheMerge(pNewMergedPeak, p2ndPeak);

                            pMergedPeakParaDict[mergedPeakID] = pNewPeak;
                            p2to1Map.Add(secondPeakID, mergedPeakID);
                        }

                        continue;
                    }

                    //the second peak was merged in previous step, but the first was not
                    if (!p2to1Map.ContainsKey(firstPeakID) && p2to1Map.ContainsKey(secondPeakID))
                    {
                        //get the newly merged peak
                        int mergedPeakID = p2to1Map[secondPeakID];
                        singleGaussianParameters pNewMergedPeak = pMergedPeakParaDict[mergedPeakID];


                        if (!fullMerge)
                        {
                            //calculate the distance
                            float pNewOldDistance;
                            if (DisFlag) pNewOldDistance = calPeakDistance(pNewMergedPeak, p1stPeak);
                            else pNewOldDistance = calPeakDistance2(pNewMergedPeak, p1stPeak);

                            ////compare |T1-Tnew| to |sig_new+sig1|
                            //float dTnew = Math.Abs(p1stPeak.TimeLocation - pNewMergedPeak.TimeLocation);
                            //float plusSigNew = p1stPeak.Sigma + pNewMergedPeak.Sigma;

                            //merge them
                            if (pNewOldDistance < distanceControl)// || dTnew<plusSigNew)
                            {
                                singleGaussianParameters pNewPeak = doTheMerge(pNewMergedPeak, p1stPeak);

                                pMergedPeakParaDict[mergedPeakID] = pNewPeak;
                                p2to1Map.Add(firstPeakID, mergedPeakID);
                            }
                        }
                        else
                        {
                            singleGaussianParameters pNewPeak = doTheMerge(pNewMergedPeak, p1stPeak);

                            pMergedPeakParaDict[mergedPeakID] = pNewPeak;
                            p2to1Map.Add(firstPeakID, mergedPeakID);
                        }

                        continue;
                    }

                    //if both the peaks were merged to other peaks in previous step
                    if (p2to1Map.ContainsKey(firstPeakID) && p2to1Map.ContainsKey(secondPeakID))
                    {
                        //check whether them were merged to the same peak
                        int mergedPeakID1st = p2to1Map[firstPeakID];
                        int mergedPeakID2nd = p2to1Map[secondPeakID];

                        //merge if they were previously merged to different peaks
                        if (mergedPeakID1st != mergedPeakID2nd)
                        {
                            //get the merged peak
                            singleGaussianParameters pMergedPeak1st = pMergedPeakParaDict[mergedPeakID1st];
                            singleGaussianParameters pMergedPeak2nd = pMergedPeakParaDict[mergedPeakID2nd];

                            if (!fullMerge)
                            {
                                //calculate the distance
                                float pNewNewDistance;
                                if (DisFlag) pNewNewDistance = calPeakDistance(pMergedPeak1st, pMergedPeak2nd);
                                else pNewNewDistance = calPeakDistance2(pMergedPeak1st, pMergedPeak2nd);

                                if (pNewNewDistance < distanceControl)
                                {
                                    singleGaussianParameters pNewPeak = doTheMerge(pMergedPeak1st, pMergedPeak2nd);

                                    pMergedPeakParaDict[mergedPeakID1st] = pNewPeak;
                                    pMergedPeakParaDict.Remove(mergedPeakID2nd);

                                    //all the old-peak merged to pMergedPeak2nd now are merged to pMergedPeak1st, so change the pOldNewPeaksMap
                                    foreach (int key in p2to1Map.Keys.ToList())
                                    {
                                        int previousMergedPeak = p2to1Map[key];
                                        if (previousMergedPeak == mergedPeakID2nd)
                                        {
                                            p2to1Map[key] = mergedPeakID1st;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                singleGaussianParameters pNewPeak = doTheMerge(pMergedPeak1st, pMergedPeak2nd);

                                pMergedPeakParaDict[mergedPeakID1st] = pNewPeak;
                                pMergedPeakParaDict.Remove(mergedPeakID2nd);
                            }

                            //all the old-peak merged to pMergedPeak2nd now are merged to pMergedPeak1st, so change the pOldNewPeaksMap
                            foreach (int key in p2to1Map.Keys.ToList())
                            {
                                int previousMergedPeak = p2to1Map[key];
                                if (previousMergedPeak == mergedPeakID2nd)
                                {
                                    p2to1Map[key] = mergedPeakID1st;
                                }
                            }
                        }

                        continue;
                    }

                    #endregion
                }
                else
                {
                    #region

                    if (!p2to1Map.ContainsKey(firstPeakID))
                    {
                        //get the first peak
                        singleGaussianParameters firstPeak = fittedUnNormPara[firstPeakID];
                        pMergedPeakParaDict.Add(newlyMergePeakID, firstPeak);
                        p2to1Map.Add(firstPeakID, newlyMergePeakID);

                        newlyMergePeakID++;
                    }

                    if (!p2to1Map.ContainsKey(secondPeakID))
                    {
                        //get the first peak
                        singleGaussianParameters secondPeak = fittedUnNormPara[secondPeakID];
                        pMergedPeakParaDict.Add(newlyMergePeakID, secondPeak);
                        p2to1Map.Add(secondPeakID, newlyMergePeakID);

                        newlyMergePeakID++;
                    }

                    #endregion
                }
            }

            List<singleGaussianParameters> pMergedPeakList = pMergedPeakParaDict.Values.ToList();
            pMergedPeakList.Sort((x, y) => x.TimeLocation.CompareTo(y.TimeLocation));

            return pMergedPeakList;
        }

        private float calPeakValleyRatio(singleGaussianParameters firstPeakPara, singleGaussianParameters secondPeakPara, float[] pInitialWaveForm)
        {
            int firstLocation = Convert.ToInt32( Math.Ceiling( firstPeakPara.TimeLocation));
            int secondLocation = Convert.ToInt32(Math.Ceiling(secondPeakPara.TimeLocation));

            float minValue = float.MaxValue;
            for (int i = firstLocation-1; i <= secondLocation-1; i++)
            {
                float wfValue = pInitialWaveForm[i];
                if (wfValue < minValue) minValue = wfValue;
            }

            float maxPeakValue = Math.Max(pInitialWaveForm[firstLocation-1], pInitialWaveForm[secondLocation-1]);

            return minValue / maxPeakValue;
        }

        private singleGaussianParameters doTheMerge(singleGaussianParameters p1stPeak, singleGaussianParameters p2ndPeak)
        {
            singleGaussianParameters pMergedPeak = new singleGaussianParameters();

            //firstly calculate the areas
            float area1 = calGaussianArea(p1stPeak.Amplitude, p1stPeak.Sigma);
            float area2 = calGaussianArea(p2ndPeak.Amplitude, p2ndPeak.Sigma);

            //then merge the two peaks follow the way used by ICESat official document
            //calculate the weights of these two peaks
            float peak1wt = area1 / (area1 + area2);
            float peak2wt = 1 - peak1wt;

            float newAmplitude = Convert.ToSingle(Math.Max(p1stPeak.Amplitude, p2ndPeak.Amplitude));
            float newSigma = p1stPeak.Sigma + p2ndPeak.Sigma; //peak1wt * p1stPeak.Sigma + peak2wt * p2ndPeak.Sigma;
            float newTimeLoc;

            newTimeLoc = peak1wt * p1stPeak.TimeLocation + peak2wt * p2ndPeak.TimeLocation;
            //if (p1stPeak.Amplitude > p2ndPeak.Amplitude)
            //    newTimeLoc = p1stPeak.TimeLocation;
            //else
            //    newTimeLoc = p2ndPeak.TimeLocation;

            pMergedPeak.TimeLocation = newTimeLoc;
            pMergedPeak.Sigma = newSigma;
            pMergedPeak.Amplitude = newAmplitude;

            return pMergedPeak;
        }

        private float calGaussianArea(float amplitude, float sigma)
        {
            return amplitude * sigma * Convert.ToSingle(Math.Sqrt(2 * Math.PI));
        }

        private float calPeakDistance(singleGaussianParameters firstPeakPara, singleGaussianParameters secondPeakPara)
        {
            //Distance between two Univariate-Gaussian, refer
            //Kailath, T. (1967), The Divergence and Bhattacharyya Distance Measures in Signal Selection, IEEE Transactions on Communication Technology, 15(1), 52-60.

            float firstMean = firstPeakPara.TimeLocation;
            float secondMean = secondPeakPara.TimeLocation;

            float firstSig = firstPeakPara.Sigma;
            float secondSig = secondPeakPara.Sigma;

            float distance = Convert.ToSingle(0.25 * Math.Pow(firstMean - secondMean, 2) / (Math.Pow(firstSig, 2) + Math.Pow(secondSig, 2)) + 0.5 * Math.Log((Math.Pow(firstSig, 2) + Math.Pow(secondSig, 2)) / (2 * firstSig * secondSig)));

            return distance;
        }

        private float calPeakDistance2(singleGaussianParameters firstPeakPara, singleGaussianParameters secondPeakPara)
        {
            //location difference
            float firstMean = firstPeakPara.TimeLocation;
            float secondMean = secondPeakPara.TimeLocation;

            //float firstSig = firstPeakPara.Sigma;
            //float secondSig = secondPeakPara.Sigma;

            float distance = Convert.ToSingle(Math.Abs(firstMean - secondMean));
            return distance;
        }

        #endregion

    }
}
