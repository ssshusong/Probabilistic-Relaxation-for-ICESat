﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Data;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;


using ESRI.ArcGIS.Catalog;
using ESRI.ArcGIS.CatalogUI;
using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;


using DataStructDefinition;

namespace ArcticToolsetICESat
{
    public partial class frmReadinAndSmoothWF : Form
    {
        #region public variables
        string pFootprintsShpPathName;
        string pSaveBinaryWFDataPathName;

        //control whether use Gaussian kernel 
        bool useGauKernel = true;
        bool GLA14 = false;

        float pFilterwid = 4, pGaussianSigma = 1f;

        #endregion

        #region input path and name
        public frmReadinAndSmoothWF()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOpen1_Click(object sender, EventArgs e)
        {
            IGxDialog pGXDialog = new GxDialogClass();
            IEnumGxObject pEnumGxObj;
            pGXDialog.ObjectFilter = new GxFilterShapefiles();
            pGXDialog.Title = "Enter Lake Shapefile:";
            pGXDialog.DoModalOpen(0, out pEnumGxObj);

            try
            {
                if (pEnumGxObj == null) return;
                else if (pEnumGxObj.Next() == null) return;
                else
                {
                    pEnumGxObj.Reset();
                    pFootprintsShpPathName = pEnumGxObj.Next().FullName;
                    textBox1.Text = pFootprintsShpPathName;
                    textBox1.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "dat files (*.dat)|*.dat|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.Title = "Save Waveform Data";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pSaveBinaryWFDataPathName = saveFileDialog1.FileName;
                textBox2.Text = pSaveBinaryWFDataPathName;
            }
        }

        #endregion

        #region Main Entry
        private void btnOK_Click(object sender, EventArgs e)
        {
            #region check the input parameters
            if (textBox1.Text == null)
            {
                MessageBox.Show("Input footprint shapefile.");
                textBox1.Focus();
                return;
            }


            if (textBox2.Text == null)
            {
                MessageBox.Show("Set output path and name！");
                textBox2.Focus();
                return;
            }

            if (radioButton1.Checked == true) GLA14 = false;
            if (radioButton2.Checked == true) GLA14 = true;
            #endregion

            #region ProgessDialog
            IProgressDialogFactory pProgressDlgFact;
            IProgressDialog2 pProgressDialog;
            IStepProgressor pStepProgressor;
            ITrackCancel pTrackCancel;

            //Show a progress dialog while we cycle through the features
            pTrackCancel = new CancelTracker();
            pProgressDlgFact = new ProgressDialogFactory();
            pProgressDialog = pProgressDlgFact.Create(pTrackCancel, 0) as IProgressDialog2;
            pProgressDialog.CancelEnabled = true;

            pProgressDialog.Animation = esriProgressAnimationTypes.esriProgressGlobe;

            //Set the properties of the Step Progressor
            pStepProgressor = pProgressDialog as IStepProgressor;
            pStepProgressor.MinRange = 0;
            pStepProgressor.StepValue = 1;
            #endregion

            #region readin waveform data
            string pTempFootprintPath, pTempFootprintName;
            splitPathandName(pFootprintsShpPathName, out pTempFootprintPath, out pTempFootprintName);
            IFeatureClass pFPfeatureCls = openObjFeatureClass(pTempFootprintPath, pTempFootprintName);
            List<FPWaveformDataNode> pAllFootprintWFdata = getFootprintData(pFPfeatureCls);


            #endregion

            #region smooth waveform
            List<FPWaveformDataNode> pSmoothedAllFootprintWFdata = smoothWaveforms(pAllFootprintWFdata);

            #endregion

            #region saveOutput
            //saveSmoothedWaveform(pSaveBinaryWFDataPathName, pSmoothedAllFootprintWFdata);
            SerializeAndDeserialize pSerialAndDeserial = new SerializeAndDeserialize();
            pSerialAndDeserial.serializeData(pSaveBinaryWFDataPathName, pSmoothedAllFootprintWFdata);

            //List<FPWaveformDataNode> temp = pSerialAndDeserial.deSeriralizeData(pSaveBinaryWFDataPathName);

            #endregion

            pProgressDialog.HideDialog();

            this.Close();

        }

        #endregion

        #region function for smoothing waveform
        private List<FPWaveformDataNode> smoothWaveforms(List<FPWaveformDataNode> pAllFootprintWFdata)
        {
            List<FPWaveformDataNode> pSmoothedWaveformData = new List<FPWaveformDataNode>();

            foreach (FPWaveformDataNode pFPnode in pAllFootprintWFdata)
            {
                float[] pInitiWF = pFPnode.Waveform;
                float[] pSmthWF = new float[544];

                //Generate time location list
                //temporary, applicable for N=392, p=1, q=4
                //For GLA12, N = 544, p = 1, q = 1
                int[] pCompressionRatio = new int[2];
                pCompressionRatio[0] = pFPnode.Pvalue;
                pCompressionRatio[1] = pFPnode.Qvalue;
                int nValue = pFPnode.Nvalue;
                float[] timeTagList = calRelativeTime(nValue, pCompressionRatio);

                if (useGauKernel)
                {
                    #region
                    for (int i = 0; i < 544; i++)
                    {
                        Dictionary<float, float> pWFTimeIntervalAndValue;
                        findNeighborWithinFilterWidth(i, pInitiWF, timeTagList, out pWFTimeIntervalAndValue);

                        if (pWFTimeIntervalAndValue.Count == 1) pSmthWF[i] = pInitiWF[i];
                        else
                        {
                            Dictionary<float, float> pWeightedWF = calculateWeight(pWFTimeIntervalAndValue);
                            float pSmthWFvalue = 0;
                            foreach (KeyValuePair<float, float> keyvalue in pWeightedWF)
                            {
                                pSmthWFvalue = pSmthWFvalue + Math.Abs(Convert.ToSingle(keyvalue.Key)) * Convert.ToSingle(keyvalue.Value);
                            }

                            pSmthWF[i] = pSmthWFvalue;
                        }
                    }
                    #endregion
                }
                else
                {
                    #region
                    for (int i = 0; i < 544; i++)
                    {
                        Dictionary<float, float> pWFTimeIntervalAndValue;
                        findNeighborWithinFilterWidth(i, pInitiWF, timeTagList, out pWFTimeIntervalAndValue);

                        if (pWFTimeIntervalAndValue.Count == 1) pSmthWF[i] = pInitiWF[i];
                        else
                        {
                            #region
                            float weightedValue = 0;

                            foreach (KeyValuePair<float, float> pKeyValue in pWFTimeIntervalAndValue)
                            {
                                int timeInt = Convert.ToInt32(Math.Abs(pKeyValue.Key));
                                switch (timeInt)
                                {
                                    case 0:
                                        weightedValue = weightedValue + pKeyValue.Value * 5 / 9;
                                        break;
                                    case 1:
                                        weightedValue = weightedValue + pKeyValue.Value * 1.5f / 9;
                                        break;
                                    case 2:
                                        weightedValue = weightedValue + pKeyValue.Value * 0.5f / 9;
                                        break;
                                    default:
                                        break;
                                }
                            }

                            pSmthWF[i] = weightedValue;
                            #endregion
                        }
                    }
                    #endregion
                }

                FPWaveformDataNode pNewNode = pFPnode;
                pNewNode.Waveform = pInitiWF;
                pNewNode.SmoothedWF = pSmthWF;
                pNewNode.TimeTag = timeTagList;
                pSmoothedWaveformData.Add(pNewNode);
            }

            return pSmoothedWaveformData;
        }

        private Dictionary<float, float> calculateWeight(Dictionary<float, float> pWFTimeIntervalAndValue)
        {
            Dictionary<float, float> WeightAndValue1 = new Dictionary<float, float>();
            Dictionary<float, float> WeightAndValue2 = new Dictionary<float, float>();

            float pTotalWeight = 0;
            foreach (KeyValuePair<float, float> keyValue in pWFTimeIntervalAndValue)
            {
                float pTimeInterval = keyValue.Key;
                float pWeight = gaussianAlgorithm(Math.Abs(pTimeInterval), pGaussianSigma);
                pTotalWeight = pWeight + pTotalWeight;
                if (pTimeInterval < 0) WeightAndValue1.Add(-pWeight, keyValue.Value);
                else WeightAndValue1.Add(pWeight, keyValue.Value);
            }

            foreach (KeyValuePair<float, float> keyValue in WeightAndValue1)
            {
                float pNormalizedWeight = keyValue.Key / pTotalWeight;
                WeightAndValue2.Add(pNormalizedWeight, keyValue.Value);
            }

            return WeightAndValue2;
        }

        private float gaussianAlgorithm(float pTimeInterval, float pGaussianSigma)
        {
            float e = Convert.ToSingle(Math.E), pPi = Convert.ToSingle(Math.PI);
            float pWeight = Convert.ToSingle((1 / (pGaussianSigma * (Math.Sqrt(2 * pPi)))) * (1 / Math.Pow(e, (Math.Pow(pTimeInterval, 2) / (2 * Math.Pow(pGaussianSigma, 2))))));

            return pWeight;
        }

        private void findNeighborWithinFilterWidth(int j, float[] pInitiWF, float[] timeTagList, out Dictionary<float, float> pWFTimeIntervalAndValue)
        {
            pWFTimeIntervalAndValue = new Dictionary<float, float>();

            bool flag = true;
            int i = 0;
            while (flag)
            {
                bool flag1 = true;
                bool flag2 = true;

                if ((j - i >= 0))
                {
                    if ((timeTagList[j] - timeTagList[j - i]) <= (pFilterwid / 2))
                        pWFTimeIntervalAndValue.Add(timeTagList[j] - timeTagList[j - i], pInitiWF[j - i]);
                    else
                        flag1 = false;

                }
                else if (flag1) flag1 = false;

                if ((j + i < 544))
                {
                    if ((j + i) > j)
                    {
                        if ((timeTagList[j + i] - timeTagList[j]) <= (pFilterwid / 2))
                            pWFTimeIntervalAndValue.Add(timeTagList[j] - timeTagList[j + i], pInitiWF[j + i]);
                        else
                            flag2 = false;
                    }

                }
                else if (flag2) flag2 = false;

                i++;

                if (flag1 == false & flag2 == false)
                    flag = false;
            }
        }

        #endregion

        #region functions for reading footprint waveform data
        private List<FPWaveformDataNode> getFootprintData(IFeatureClass pFPfeatureCls)
        {
            List<FPWaveformDataNode> pFootprintDataList = new List<FPWaveformDataNode>();

            int elevPos, NvalPos, QvalPos, PvalPos, CompTypePos, elevMaxAmp, geoidPos, gauFitSTDPos, latPos, lonPos, snrPos, IDPos, thresholdPos, sigBegPos, sigEndPos, ldRngOffPos, maxRngOffPos, gmcPos, datePos, FIDPos, granulNumPos, secIndPos, validDEMPos;
            if (GLA14)
            {
                elevPos = pFPfeatureCls.FindField("elev");
                elevMaxAmp = pFPfeatureCls.FindField("elevCbyM");
            }
            else
            {
                //For GLA12
                elevPos = pFPfeatureCls.FindField("elevMaxAm");
                elevMaxAmp = pFPfeatureCls.FindField("elevCentd");
            }

            geoidPos = pFPfeatureCls.FindField("Geoid");
            IDPos = pFPfeatureCls.FindField("ID");
            thresholdPos = pFPfeatureCls.FindField("FlThresh");
            sigBegPos = pFPfeatureCls.FindField("SgBegOff");
            sigEndPos = pFPfeatureCls.FindField("SgEndOff");
            
            gmcPos = pFPfeatureCls.FindField("GmC");
            NvalPos = pFPfeatureCls.FindField("Nvalue");
            QvalPos = pFPfeatureCls.FindField("Qvalue");
            PvalPos = pFPfeatureCls.FindField("Pvalue");
            CompTypePos = pFPfeatureCls.FindField("CompType");

            if (GLA14)
            {
                ldRngOffPos = pFPfeatureCls.FindField("ldRngOff");
                maxRngOffPos = pFPfeatureCls.FindField("MaxAmOff");
            }
            else
            {
                //for GLA12
                ldRngOffPos = pFPfeatureCls.FindField("IceRgOff");
                maxRngOffPos = pFPfeatureCls.FindField("LdRgOff");
            }

            datePos = pFPfeatureCls.FindField("date");
            FIDPos = pFPfeatureCls.FindField("FPID");
            granulNumPos = pFPfeatureCls.FindField("GranuNum");
            secIndPos = pFPfeatureCls.FindField("RecInd");
            gauFitSTDPos = pFPfeatureCls.FindField("GauFitSTD");
            snrPos = pFPfeatureCls.FindField("SNR");
            latPos = pFPfeatureCls.FindField("Lat_km");
            lonPos = pFPfeatureCls.FindField("Lon_km");
            validDEMPos = pFPfeatureCls.FindField("validDEM");

            //get the positio of waveform gates
            List<int> pWFGatePos = new List<int>();
            for (int i = 0; i < 544; i++)
            {
                string fieldName = "wf" + i.ToString();

                int ptempPos = pFPfeatureCls.FindField(fieldName);

                pWFGatePos.Add(ptempPos);
            }

            int featureCount = pFPfeatureCls.FeatureCount(null);
            IFeature pTempFeature = null;
            for (int i = 0; i < featureCount; i++)
            {
                FPWaveformDataNode pFPDataNode = new FPWaveformDataNode();
                pTempFeature = pFPfeatureCls.GetFeature(i);

                pFPDataNode.Elev = Convert.ToSingle(pTempFeature.get_Value(elevPos));
                pFPDataNode.ElevMaxAmp = Convert.ToSingle(pTempFeature.get_Value(elevMaxAmp));
                pFPDataNode.Geoid = Convert.ToSingle(pTempFeature.get_Value(geoidPos));
                pFPDataNode.DateTime = Convert.ToDateTime(pTempFeature.get_Value(datePos));
                pFPDataNode.FootprintID = Convert.ToInt32(pTempFeature.get_Value(FIDPos));
                pFPDataNode.GranulNum = Convert.ToInt32(pTempFeature.get_Value(granulNumPos));
                pFPDataNode.LakeID = Convert.ToInt32(pTempFeature.get_Value(IDPos));
                pFPDataNode.LdRngOff = Convert.ToSingle(pTempFeature.get_Value(ldRngOffPos));
                pFPDataNode.MaxRngOff = Convert.ToSingle(pTempFeature.get_Value(maxRngOffPos));

                if (GLA14)
                {
                    pFPDataNode.EndGateElev = pFPDataNode.ElevMaxAmp + pFPDataNode.MaxRngOff - Convert.ToSingle(pTempFeature.get_Value(gmcPos));
                }
                else
                {
                    //For GLA12
                    pFPDataNode.EndGateElev = pFPDataNode.ElevMaxAmp + pFPDataNode.MaxRngOff + Convert.ToSingle(pTempFeature.get_Value(gmcPos));
                }

                pFPDataNode.SecondIndex = Convert.ToInt16(pTempFeature.get_Value(secIndPos));
                pFPDataNode.SignalBegin = Convert.ToSingle(pTempFeature.get_Value(sigBegPos));
                pFPDataNode.SignalEnd = Convert.ToSingle(pTempFeature.get_Value(sigEndPos));
                pFPDataNode.Threshold = Convert.ToInt32(pTempFeature.get_Value(thresholdPos));
                pFPDataNode.SNR = Convert.ToSingle(pTempFeature.get_Value(snrPos));
                pFPDataNode.Latitude = Convert.ToSingle(pTempFeature.get_Value(latPos));
                pFPDataNode.Longitude = Convert.ToSingle(pTempFeature.get_Value(lonPos));
                pFPDataNode.DefaultGauFitSTD = Convert.ToSingle(pTempFeature.get_Value(gauFitSTDPos));
                pFPDataNode.CompressionType = Convert.ToInt32(pTempFeature.get_Value(CompTypePos));
                pFPDataNode.Nvalue = Convert.ToInt32(pTempFeature.get_Value(NvalPos));
                pFPDataNode.Pvalue = Convert.ToInt32(pTempFeature.get_Value(PvalPos));
                pFPDataNode.Qvalue = Convert.ToInt32(pTempFeature.get_Value(QvalPos));

                if (validDEMPos>0) pFPDataNode.ValidateDEM = Convert.ToSingle(pTempFeature.get_Value(validDEMPos));
                else pFPDataNode.ValidateDEM = Convert.ToSingle(0);

                pWFGatePos.Sort();
                int j = 0;
                float[] pWF = new float[544];
                foreach (int wfPos in pWFGatePos)
                {
                    Int16 pWFgateValue = Convert.ToInt16(pTempFeature.get_Value(wfPos));
                    pWF[j] = pWFgateValue;
                    j++;
                }

                pFPDataNode.Waveform = pWF;

                pFootprintDataList.Add(pFPDataNode);
            }

            return pFootprintDataList;
        }

        private float[] calRelativeTime(int pNval, int[] pCompressionRatio)
        {
            float[] pRelTime = new float[544];

            int flag_CompGateNum = 544 - pNval;
            if (flag_CompGateNum < 0) flag_CompGateNum = 0;
            if (flag_CompGateNum > 543) flag_CompGateNum = 544;

            float dTchange;
            if (flag_CompGateNum == 0) dTchange = 0;
            else
            {
                for (int i = 0; i < flag_CompGateNum; i++)
                {
                    pRelTime[i] = Convert.ToSingle((pCompressionRatio[1] - 1) * 0.5) + Convert.ToSingle(pCompressionRatio[1] * i);
                }

                dTchange = Convert.ToSingle(pCompressionRatio[1] * flag_CompGateNum);
            }

            if (flag_CompGateNum <= 543)
            {
                for (int i = flag_CompGateNum; i < 544; i++)
                {
                    pRelTime[i] = dTchange + Convert.ToSingle((pCompressionRatio[0] - 1) * 0.5) + Convert.ToSingle(pCompressionRatio[0] * (i - flag_CompGateNum));
                }
            }

            return pRelTime;
        }

        #endregion

        #region Split path from name
        private void splitPathandName(string pShpFullPathandName, out string pTempPath, out string pTempName)
        {
            int charPos = pShpFullPathandName.LastIndexOf("\\");
            pTempPath = pShpFullPathandName.Substring(0, charPos + 1);
            pTempName = pShpFullPathandName.Substring(charPos + 1);
        }
        #endregion

        #region Create Workspace
        private IFeatureWorkspace CreateWorkSpace(string openShpfilePath)
        {
            IWorkspaceFactory shapefileWSF = new ShapefileWorkspaceFactory();
            IWorkspace WSP = null;
            try
            {
                WSP = shapefileWSF.OpenFromFile(openShpfilePath, 0);
            }
            catch (Exception e)
            {
                MessageBox.Show("Error in create workspace!");
            }

            return WSP as IFeatureWorkspace;
        }

        #endregion

        #region Input FeatureClass
        private IFeatureClass openObjFeatureClass(string ShpfilePath, string ShpfileName)
        {
            IFeatureWorkspace pFWorkspace = CreateWorkSpace(ShpfilePath);

            IFeatureClass pObjFeatureClass = null;
            try
            {
                pObjFeatureClass = pFWorkspace.OpenFeatureClass(ShpfileName);
            }
            catch (Exception e)
            {
                MessageBox.Show("Error in open featureClass!");
            }

            return pObjFeatureClass;
        }
        #endregion
    }

}
