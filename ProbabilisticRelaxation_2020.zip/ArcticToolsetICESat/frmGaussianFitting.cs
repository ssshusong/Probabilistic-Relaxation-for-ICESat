﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Xml;
using System.Linq;

using Microsoft.Office.Core;
using Microsoft.Office.Interop;
using Excel = Microsoft.Office.Interop.Excel;

using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;

using DataStructDefinition;

namespace ArcticToolsetICESat
{
    public partial class frmGaussianFitting : Form
    {
        #region public variables
        string openWFSignalPathName;
        string openInitialParameterPathName;
        string pSavePathName;

        double noiseCK = 0.001, timePosCK = 0.01, sigCK = 0.01, ampCK = 0.001;//criteria for ending the gaussian fitting
        double nsMaxDelta = 0.1, ampMaxDelta = 0.1, timeLocMaxDelta = 5, sigMaxDelta = 0.1;//Maximum delta during fitting
        int maxIterNum = 100;

        //absolute peak amplitude control, during fitting iteration,peak amplitude should not be less than the value below
        float absPeakAmpControl = 0.01f;
        float absPeakSigControl = 0.5f;

        //distance control, merge the two peaks if the distance between them is less than the value below
        //distance1 is calculated following 
        //Kailath, T. (1967), The Divergence and Bhattacharyya Distance Measures in Signal Selection, IEEE Transactions on Communication Technology, 15(1), 52-60.
        float distanceControl;
        float distance1 =3;
        //distance2 is the difference between two peaks
        float distance2;
        //determine which distance formula should be used; True --> calPeakDistance (Kailath), False --> calPeakDistance2 (location difference)
        bool DisFlag = false;

        //determine whether the peak being fully merged or partly merged (need second judgement) 
        bool fullMerge = false;

        //decide whether use hierarchical weight
        bool useHierarchWt = true;
       

        public frmGaussianFitting()
        {
            InitializeComponent();
        }

        private void btnOpn_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Title = "Open waveform signal data";
            openDialog.Filter = "DAT（*.dat)|*.dat";
            openDialog.ShowDialog();
            openWFSignalPathName = openDialog.FileName;
            textBox1.Enabled = true;
            textBox1.Text = openWFSignalPathName;
            openDialog.Dispose();
        }

        private void btnOpenInitial_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Title = "Open initial parameter estimates";
            openDialog.Filter = "DAT（*.dat)|*.dat";
            openDialog.ShowDialog();
            openInitialParameterPathName = openDialog.FileName;
            textBox2.Enabled = true;
            textBox2.Text = openInitialParameterPathName;
            openDialog.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "dat files (*.dat)|*.dat|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.Title = "Save fitted Gaussian fitting";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pSavePathName = saveFileDialog1.FileName;
                textBox3.Text = pSavePathName;
            }
        }

        #endregion

        #region main entry

        private void fittingBtn_Click(object sender, EventArgs e)
        {
            #region check parameters
            if (textBox1.Text == null)
            {
                MessageBox.Show("Choose waveforms signal data.");
                return;
            }
            if (textBox2.Text == null)
            {
                MessageBox.Show("Choose parameter estimates.");
                return;
            }
            if (textBox3.Text == null)
            {
                MessageBox.Show("Specify output.");
                return;
            }
            
            #endregion

            #region reading data: waveform and initial parameter estimates
            //Dictionary key = lakeID_Date
            Dictionary<string, List<effectiveSignalDataNode>> pExtratedWFSignalDict = readinExtractedWF(openWFSignalPathName);
            Dictionary<string, List<InitialWFPeakParameterNode>> pInitialParaEstimatesDict = readinInitParaEstimate(openInitialParameterPathName);
            #endregion

            #region Gaussian Fitting
            Dictionary<string, List<fittedGaussianParameterNode>> pFittedParametersDict = fitGaussianPeaks(pExtratedWFSignalDict, pInitialParaEstimatesDict);
            #endregion

            #region save the fitted output
            saveFittedWF(pSavePathName, pFittedParametersDict);
            #endregion

            this.Close();
        }

        //for validation
       
        private void saveFittedWF(string pSavePathName, Dictionary<string, List<fittedGaussianParameterNode>> pFittedParametersDict)
        {
            List<Type> knownTypes = new List<Type> { typeof(List<fittedGaussianParameterNode>) };
            DataContractSerializer serializer = new DataContractSerializer(typeof(Dictionary<string, List<fittedGaussianParameterNode>>), knownTypes);

            System.IO.FileStream fileStream = new FileStream(pSavePathName, FileMode.Create);
            serializer.WriteObject(fileStream, pFittedParametersDict);

            fileStream.Close();
        }

        #endregion

        #region functions for Gaussian fitting
        private Dictionary<string, List<fittedGaussianParameterNode>> fitGaussianPeaks(Dictionary<string, List<effectiveSignalDataNode>> pExtratedWFSignalDict, Dictionary<string, List<InitialWFPeakParameterNode>> pInitialParaEstimatesDict)
        {
            Dictionary<string, List<fittedGaussianParameterNode>> pFittedParametersDict = new Dictionary<string, List<fittedGaussianParameterNode>>();

            foreach (KeyValuePair<string, List<effectiveSignalDataNode>> pKeyValue in pExtratedWFSignalDict)
            {
                List<fittedGaussianParameterNode> pFittedParaList = new List<fittedGaussianParameterNode>();

                //waveform signal list for the same lake in one day
                List<effectiveSignalDataNode> pSameLakeSignalList = pKeyValue.Value;
                //parameter list
                List<InitialWFPeakParameterNode> pInitialParaList = pInitialParaEstimatesDict[pKeyValue.Key];
                

                foreach (effectiveSignalDataNode pSignalNode in pSameLakeSignalList)
                {
                    long footPrintID = pSignalNode.FootprintID;

                    #region get the initial parameters
                    InitialWFPeakParameterNode pTempInitialParaNode = new InitialWFPeakParameterNode();
                    foreach (InitialWFPeakParameterNode pParaNode in pInitialParaList)
                    {
                        if (pParaNode.FootprintID == footPrintID)
                        {
                            pTempInitialParaNode = pParaNode;
                            break;
                        }
                    }

                    List<singleGaussianParameters> initialParaList = pTempInitialParaNode.AllPeakParameters.ToList();
                    float initialNoiseLevel = pTempInitialParaNode.NoiseLevel;

                    if (initialParaList.Count == 0)
                    {
                        continue;
                    }
                    #endregion

                    #region fit waveform
                    //decide whether need to fit until no more peak-removal
                    bool fitTillNoRemoval = true;

                    if (initialParaList.Count == 0) return null;
                    initialParaList.Sort((x, y) => -1 * x.Amplitude.CompareTo(y.Amplitude));
                    singleGaussianParameters p1stPeak = initialParaList[0];
                    float pMaxPeakAbsAmp = p1stPeak.Amplitude - initialNoiseLevel;

                    if (pMaxPeakAbsAmp > 0.45) fitTillNoRemoval = true;
                    else fitTillNoRemoval = false;

                    //1st Gaussian fitting
                    List<singleGaussianParameters> inputParaList = initialParaList;
                    float inputNoiseLevel = initialNoiseLevel;
                    List<singleGaussianParameters> fittedParaList;
                    float fittedNoiseLevel = 0;
                    double[] fittedWF = null;

                    if (DisFlag) distanceControl = distance1;
                    else distanceControl = distance2;

                    fittedWF = DoTheFitting(pSignalNode, initialParaList, inputParaList, inputNoiseLevel, out fittedParaList, out fittedNoiseLevel);


                    #region fit until no more peak-removal
                    if (!fitTillNoRemoval)
                    {
                        List<singleGaussianParameters> mergedPeakList = null;
                        mergedPeakList = DiscardMergeGauPeaks(fittedParaList);

                        if (mergedPeakList.Count > 1)
                            fittedWF = DoTheFitting(pSignalNode, initialParaList, mergedPeakList, inputNoiseLevel, out fittedParaList, out fittedNoiseLevel);

                        //remove the old peak if the amplitude is less than the Amplitude-control     
                        fittedParaList.RemoveAll(item => item.Amplitude < absPeakAmpControl);

                        ////remove the old peak if the amplitude is less than the Sigma-control     
                        fittedParaList.RemoveAll(item => item.Sigma < absPeakSigControl);
                    }
                    else
                    {
                        //Discard the peaks with amplitude less than Amp-control, merge the peaks with distance less than distance-control
                        //then fit again 
                        List<singleGaussianParameters> mergedPeakList = null;
                        if (fittedParaList.Count > 1) mergedPeakList = DiscardMergeGauPeaks(fittedParaList);
                        else mergedPeakList = fittedParaList;

                        bool flag;
                        int previousPeakNum;

                        if (initialParaList.Count == mergedPeakList.Count)
                        {
                            flag = false;
                            previousPeakNum = initialParaList.Count;
                        }
                        else
                        {
                            flag = true;
                            previousPeakNum = mergedPeakList.Count;
                        }

                        //fit until there is no peak with amplitude less than amp-control and no peak merged to other peaks                    
                        while (flag)
                        {
                            inputParaList = mergedPeakList;
                            inputNoiseLevel = fittedNoiseLevel;

                            fittedWF = DoTheFitting(pSignalNode, initialParaList, inputParaList, inputNoiseLevel, out fittedParaList, out fittedNoiseLevel);

                            if (fittedParaList.Count > 1) mergedPeakList = DiscardMergeGauPeaks(fittedParaList);
                            else mergedPeakList = fittedParaList;

                            int currentPeakNum = mergedPeakList.Count;

                            if (currentPeakNum == previousPeakNum) flag = false;
                            previousPeakNum = currentPeakNum;
                        }
                    }
                    #endregion

                    #endregion

                    #region prepare the output

                    fittedGaussianParameterNode pFittedWFNode = new fittedGaussianParameterNode();
                    pFittedWFNode.FittedPeaksParameters = fittedParaList;
                    pFittedWFNode.InitialPeaksParameters = initialParaList;
                    pFittedWFNode.FittedVoltWaveform = Array.ConvertAll(fittedWF, x => (float)x);
                    pFittedWFNode.FootprintID = footPrintID;
                    pFittedWFNode.FitNoiseLevel = fittedNoiseLevel;
                    pFittedWFNode.InitialNoiseLevel = pSignalNode.NoiseLevel;
                    pFittedWFNode.GateShift = pSignalNode.GateShift;
                    pFittedWFNode.BegGate = pSignalNode.BegGate;
                    pFittedWFNode.BegGateElev = pSignalNode.BegGateElev;
                    pFittedWFNode.SmoothedVoltWaveform = pSignalNode.SmoothedSignalWaveform;
                    pFittedWFNode.InitialVoltWaveform = pSignalNode.SignalWaveform;
                    pFittedWFNode.DefaultGauFitSTD = pSignalNode.DefaultGauFitSTD;
                    pFittedWFNode.SNR = pSignalNode.SNR;

                    float newFitGauStd = calFitGaussianSTD(pFittedWFNode.FittedVoltWaveform, pFittedWFNode.InitialVoltWaveform);
                    pFittedWFNode.NewGauFitSTD = newFitGauStd;

                    pFittedParaList.Add(pFittedWFNode);
                    #endregion

                }

                pFittedParametersDict.Add(pKeyValue.Key, pFittedParaList);
            }

            return pFittedParametersDict;
        }

        private List<singleGaussianParameters> DiscardMergeGauPeaks(List<singleGaussianParameters> fittedUnNormPara)
        {
            //key is the ID of the peak merged from old peaks
            Dictionary<int, singleGaussianParameters> pMergedPeakParaDict = new Dictionary<int, singleGaussianParameters>();

            //remove the old peak if the amplitude is less than the Amplitude-control     
            fittedUnNormPara.RemoveAll(item => item.Amplitude < absPeakAmpControl);

            ////remove the old peak if the amplitude is less than the Sigma-control     
            fittedUnNormPara.RemoveAll(item => item.Sigma < absPeakSigControl);

            if (!(fittedUnNormPara.Count > 1)) return fittedUnNormPara;

            //sort the list
            fittedUnNormPara.Sort((x, y) => x.TimeLocation.CompareTo(y.TimeLocation));

            //Calculate distance of the adjacent two peaks, the key is the first peak number
            Dictionary<int, float> distanceTable = new Dictionary<int, float>();
            int peakCount = fittedUnNormPara.Count;
            for (int i = 0; i < peakCount - 1; i++)
            {
                //get the 1st peak para
                singleGaussianParameters firstPeakPara = fittedUnNormPara[i];
                //get the 2nd peak para
                singleGaussianParameters secondPeakPara = fittedUnNormPara[i + 1];

                float pDistance;
                if (DisFlag) pDistance = calPeakDistance(firstPeakPara, secondPeakPara);
                else pDistance = calPeakDistance2(firstPeakPara, secondPeakPara);

                //key is the position of the 1st peak
                distanceTable.Add(i, pDistance);
            }

            //sort the distance table, ascending order
            distanceTable = distanceTable.OrderBy(x => x.Value).ToDictionary(x => x.Key, x => x.Value);

            //the two peaks with the smallest distance will be merged firstly
            //And the mapping of this two-to-one merge will be noted down in the table below
            //key is the old-peak ID, value is the newly merged peak ID
            int newlyMergePeakID = 0;
            Dictionary<int, int> p2to1Map = new Dictionary<int, int>();
            foreach (KeyValuePair<int, float> pDisKeyValue in distanceTable)
            {
                int firstPeakID = pDisKeyValue.Key;
                int secondPeakID = firstPeakID + 1;

                //get the two peaks
                singleGaussianParameters p1stPeak = fittedUnNormPara[firstPeakID];
                singleGaussianParameters p2ndPeak = fittedUnNormPara[secondPeakID];

                ////compare |T1-T2| to |sig1+sig2|
                //float dT = p2ndPeak.TimeLocation - p1stPeak.TimeLocation;
                //float plusSig = p1stPeak.Sigma + p2ndPeak.Sigma;

                float pDistance = pDisKeyValue.Value;
                if (pDistance < distanceControl)// || dT<plusSig)
                {
                    #region

                    //if the two peaks were both not mereged to the other peaks in previous step
                    if (!p2to1Map.ContainsKey(firstPeakID) && !p2to1Map.ContainsKey(secondPeakID))
                    {


                        //merge the two peaks
                        singleGaussianParameters pNewPeak = doTheMerge(p1stPeak, p2ndPeak);

                        pMergedPeakParaDict.Add(newlyMergePeakID, pNewPeak);

                        p2to1Map.Add(firstPeakID, newlyMergePeakID);
                        p2to1Map.Add(secondPeakID, newlyMergePeakID);

                        newlyMergePeakID++;

                        continue;
                    }

                    //check either of these two peaks has already or not been merged into other peaks
                    //if so, calculate the distance between the newly merged peak and the old peak
                    //the first peak was merged to the other peak in previous step, but the second was not
                    if (p2to1Map.ContainsKey(firstPeakID) && !p2to1Map.ContainsKey(secondPeakID))
                    {
                        //get the newly merged peak
                        int mergedPeakID = p2to1Map[firstPeakID];
                        singleGaussianParameters pNewMergedPeak = pMergedPeakParaDict[mergedPeakID];


                        if (!fullMerge)
                        {
                            //calculate the distance between the newly-merged-peak and the second old-peak
                            float pNewOldDistance;
                            if (DisFlag) pNewOldDistance = calPeakDistance(pNewMergedPeak, p2ndPeak);
                            else pNewOldDistance = calPeakDistance2(pNewMergedPeak, p2ndPeak);


                            ////compare |T2-Tnew| to |sig_new+sig2|
                            //float dTnew = Math.Abs(p2ndPeak.TimeLocation - pNewMergedPeak.TimeLocation);
                            //float plusSigNew = p2ndPeak.Sigma + pNewMergedPeak.Sigma;

                            //merged the peaks if the distance less than the control value
                            if (pNewOldDistance < distanceControl)// || dTnew < plusSigNew)
                            {
                                singleGaussianParameters pNewPeak = doTheMerge(pNewMergedPeak, p2ndPeak);

                                pMergedPeakParaDict[mergedPeakID] = pNewPeak;
                                p2to1Map.Add(secondPeakID, mergedPeakID);
                            }
                        }
                        else
                        {
                            singleGaussianParameters pNewPeak = doTheMerge(pNewMergedPeak, p2ndPeak);

                            pMergedPeakParaDict[mergedPeakID] = pNewPeak;
                            p2to1Map.Add(secondPeakID, mergedPeakID);
                        }

                        continue;
                    }

                    //the second peak was merged in previous step, but the first was not
                    if (!p2to1Map.ContainsKey(firstPeakID) && p2to1Map.ContainsKey(secondPeakID))
                    {
                        //get the newly merged peak
                        int mergedPeakID = p2to1Map[secondPeakID];
                        singleGaussianParameters pNewMergedPeak = pMergedPeakParaDict[mergedPeakID];


                        if (!fullMerge)
                        {
                            //calculate the distance
                            float pNewOldDistance;
                            if (DisFlag) pNewOldDistance = calPeakDistance(pNewMergedPeak, p1stPeak);
                            else pNewOldDistance = calPeakDistance2(pNewMergedPeak, p1stPeak);

                            ////compare |T1-Tnew| to |sig_new+sig1|
                            //float dTnew = Math.Abs(p1stPeak.TimeLocation - pNewMergedPeak.TimeLocation);
                            //float plusSigNew = p1stPeak.Sigma + pNewMergedPeak.Sigma;

                            //merge them
                            if (pNewOldDistance < distanceControl)// || dTnew<plusSigNew)
                            {
                                singleGaussianParameters pNewPeak = doTheMerge(pNewMergedPeak, p1stPeak);

                                pMergedPeakParaDict[mergedPeakID] = pNewPeak;
                                p2to1Map.Add(firstPeakID, mergedPeakID);
                            }
                        }
                        else
                        {
                            singleGaussianParameters pNewPeak = doTheMerge(pNewMergedPeak, p1stPeak);

                            pMergedPeakParaDict[mergedPeakID] = pNewPeak;
                            p2to1Map.Add(firstPeakID, mergedPeakID);
                        }

                        continue;
                    }

                    //if both the peaks were merged to other peaks in previous step
                    if (p2to1Map.ContainsKey(firstPeakID) && p2to1Map.ContainsKey(secondPeakID))
                    {
                        //check whether them were merged to the same peak
                        int mergedPeakID1st = p2to1Map[firstPeakID];
                        int mergedPeakID2nd = p2to1Map[secondPeakID];

                        //merge if they were previously merged to different peaks
                        if (mergedPeakID1st != mergedPeakID2nd)
                        {
                            //get the merged peak
                            singleGaussianParameters pMergedPeak1st = pMergedPeakParaDict[mergedPeakID1st];
                            singleGaussianParameters pMergedPeak2nd = pMergedPeakParaDict[mergedPeakID2nd];

                            if (!fullMerge)
                            {
                                //calculate the distance
                                float pNewNewDistance;
                                if (DisFlag) pNewNewDistance = calPeakDistance(pMergedPeak1st, pMergedPeak2nd);
                                else pNewNewDistance = calPeakDistance2(pMergedPeak1st, pMergedPeak2nd);

                                if (pNewNewDistance < distanceControl)
                                {
                                    singleGaussianParameters pNewPeak = doTheMerge(pMergedPeak1st, pMergedPeak2nd);

                                    pMergedPeakParaDict[mergedPeakID1st] = pNewPeak;
                                    pMergedPeakParaDict.Remove(mergedPeakID2nd);

                                    //all the old-peak merged to pMergedPeak2nd now are merged to pMergedPeak1st, so change the pOldNewPeaksMap
                                    foreach (int key in p2to1Map.Keys.ToList())
                                    {
                                        int previousMergedPeak = p2to1Map[key];
                                        if (previousMergedPeak == mergedPeakID2nd)
                                        {
                                            p2to1Map[key] = mergedPeakID1st;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                singleGaussianParameters pNewPeak = doTheMerge(pMergedPeak1st, pMergedPeak2nd);

                                pMergedPeakParaDict[mergedPeakID1st] = pNewPeak;
                                pMergedPeakParaDict.Remove(mergedPeakID2nd);
                            }

                            //all the old-peak merged to pMergedPeak2nd now are merged to pMergedPeak1st, so change the pOldNewPeaksMap
                            foreach (int key in p2to1Map.Keys.ToList())
                            {
                                int previousMergedPeak = p2to1Map[key];
                                if (previousMergedPeak == mergedPeakID2nd)
                                {
                                    p2to1Map[key] = mergedPeakID1st;
                                }
                            }
                        }

                        continue;
                    }

                    #endregion
                }
                else
                {
                    #region

                    if (!p2to1Map.ContainsKey(firstPeakID))
                    {
                        //get the first peak
                        singleGaussianParameters firstPeak = fittedUnNormPara[firstPeakID];
                        pMergedPeakParaDict.Add(newlyMergePeakID, firstPeak);
                        p2to1Map.Add(firstPeakID, newlyMergePeakID);

                        newlyMergePeakID++;
                    }

                    if (!p2to1Map.ContainsKey(secondPeakID))
                    {
                        //get the first peak
                        singleGaussianParameters secondPeak = fittedUnNormPara[secondPeakID];
                        pMergedPeakParaDict.Add(newlyMergePeakID, secondPeak);
                        p2to1Map.Add(secondPeakID, newlyMergePeakID);

                        newlyMergePeakID++;
                    }

                    #endregion
                }
            }

            List<singleGaussianParameters> pMergedPeakList = pMergedPeakParaDict.Values.ToList();
            pMergedPeakList.Sort((x, y) => x.TimeLocation.CompareTo(y.TimeLocation));

            return pMergedPeakList;
        }

        private singleGaussianParameters doTheMerge(singleGaussianParameters p1stPeak, singleGaussianParameters p2ndPeak)
        {
            singleGaussianParameters pMergedPeak = new singleGaussianParameters();

            //firstly calculate the areas
            float area1 = calGaussianArea(p1stPeak.Amplitude, p1stPeak.Sigma);
            float area2 = calGaussianArea(p2ndPeak.Amplitude, p2ndPeak.Sigma);

            //then merge the two peaks follow the way used by ICESat official document
            //calculate the weights of these two peaks
            float peak1wt = area1 / (area1 + area2);
            float peak2wt = 1 - peak1wt;

            float newAmplitude = Convert.ToSingle(Math.Max(p1stPeak.Amplitude, p2ndPeak.Amplitude));
            float newSigma = p1stPeak.Sigma + p2ndPeak.Sigma; //peak1wt * p1stPeak.Sigma + peak2wt * p2ndPeak.Sigma;
            float newTimeLoc;

            newTimeLoc = peak1wt * p1stPeak.TimeLocation + peak2wt * p2ndPeak.TimeLocation;
            //if (p1stPeak.Amplitude > p2ndPeak.Amplitude)
            //    newTimeLoc = p1stPeak.TimeLocation;
            //else
            //    newTimeLoc = p2ndPeak.TimeLocation;

            pMergedPeak.TimeLocation = newTimeLoc;
            pMergedPeak.Sigma = newSigma;
            pMergedPeak.Amplitude = newAmplitude;

            return pMergedPeak;
        }

        private float calGaussianArea(float amplitude, float sigma)
        {
            return amplitude * sigma * Convert.ToSingle(Math.Sqrt(2 * Math.PI));
        }

        private float calPeakDistance(singleGaussianParameters firstPeakPara, singleGaussianParameters secondPeakPara)
        {
            //Distance between two Univariate-Gaussian, refer
            //Kailath, T. (1967), The Divergence and Bhattacharyya Distance Measures in Signal Selection, IEEE Transactions on Communication Technology, 15(1), 52-60.

            float firstMean = firstPeakPara.TimeLocation;
            float secondMean = secondPeakPara.TimeLocation;

            float firstSig = firstPeakPara.Sigma;
            float secondSig = secondPeakPara.Sigma;

            float distance = Convert.ToSingle(0.25 * Math.Pow(firstMean - secondMean, 2) / (Math.Pow(firstSig, 2) + Math.Pow(secondSig, 2)) + 0.5 * Math.Log((Math.Pow(firstSig, 2) + Math.Pow(secondSig, 2)) / (2 * firstSig * secondSig)));

            return distance;
        }

        private float calPeakDistance2(singleGaussianParameters firstPeakPara, singleGaussianParameters secondPeakPara)
        {
            //location difference
            float firstMean = firstPeakPara.TimeLocation;
            float secondMean = secondPeakPara.TimeLocation;

            //float firstSig = firstPeakPara.Sigma;
            //float secondSig = secondPeakPara.Sigma;

            float distance = Convert.ToSingle(Math.Abs(firstMean - secondMean));
            return distance;
        }

        private double[] DoTheFitting(effectiveSignalDataNode pSignalNode, List<singleGaussianParameters> initialParaList, List<singleGaussianParameters> inputParaList, float inputNoise, out List<singleGaussianParameters> fittedParaList, out float fittedNoise)
        {
            #region Normalize the initial waveform

            //get the waveform and the gate time
            double[] pInitiWF_Volt = Array.ConvertAll(pSignalNode.SignalWaveform, x => (double)x);
            double[] pNormWF = new double[pInitiWF_Volt.Length];//normalized waveform

            //generate an array with increment of 1.0 each step
            double[] pSampTime = Enumerable.Range(1, pInitiWF_Volt.Length).Select(x => (double)x).ToArray();

            //Normalize the waveform
            double maxWF = pInitiWF_Volt.Max();
            double minWF = pSignalNode.MinVolt;//pInitiWF_Volt.Min(); //

            for (int i = 0; i < pInitiWF_Volt.Length; i++)
            {
                pNormWF[i] = (pInitiWF_Volt[i] - minWF) / (maxWF - minWF);
            }

            #endregion

            #region normalize model waveform
            //inputNoise = Convert.ToSingle( minWF);

            inputParaList.Sort((x, y) => x.TimeLocation.CompareTo(y.TimeLocation));
            int numGauPeaks = inputParaList.Count;//Number of Gaussian peaks
            double[] pInitialEstimate = new double[numGauPeaks * 3 + 1];
            pInitialEstimate[numGauPeaks * 3] = inputNoise;
            for (int i = 0; i < numGauPeaks; i++)
            {
                singleGaussianParameters pSingleGauPara = inputParaList[i];
                pInitialEstimate[i] = pSingleGauPara.Amplitude - inputNoise;
                pInitialEstimate[i + 1 * numGauPeaks] = pSingleGauPara.TimeLocation;
                pInitialEstimate[i + 2 * numGauPeaks] = pSingleGauPara.Sigma;
            }

            Vector<double> pInitialParaVec = DenseVector.OfArray(pInitialEstimate);//Estimated parameters from interation             
            Vector<double> pModelWaveform = calModeledWF(pSampTime, pInitialParaVec, numGauPeaks);//Waveform calculated from the initial estimated parameters

            Vector<double> pModelWaveform_Norm = DenseVector.Build.Dense(pModelWaveform.Count);

            for (int i = 0; i < pModelWaveform.Count; i++)
            {
                pModelWaveform_Norm[i] = (pModelWaveform[i] - minWF) / (maxWF - minWF);
            }

            #endregion

            #region normalize the parameters
            double[] pInitialEstimate_Norm = new double[numGauPeaks * 3 + 1];
            pInitialEstimate_Norm[numGauPeaks * 3] = (pInitialEstimate[numGauPeaks * 3] - minWF) / (maxWF - minWF);//normalize the noise level

            for (int i = 0; i < numGauPeaks; i++)
            {
                singleGaussianParameters pSingleGauPara = inputParaList[i];
                pInitialEstimate_Norm[i] = (pInitialEstimate[i] + pInitialEstimate[numGauPeaks * 3] - minWF) / (maxWF - minWF) - pInitialEstimate_Norm[numGauPeaks * 3];//normalize amplitude
                pInitialEstimate_Norm[i + 1 * numGauPeaks] = pInitialEstimate[i + 1 * numGauPeaks];
                pInitialEstimate_Norm[i + 2 * numGauPeaks] = pInitialEstimate[i + 2 * numGauPeaks];
            }
            //pParaIterVec_unNorm[i] = (pParaIterEstimate[i] + pParaIterEstimate[3 * numGauPeaks]) * (maxWF - minWF) - pParaIterVec_unNorm[3 * numGauPeaks];

            #endregion

            #region Gaussian Fitting
            int iterationNum = 0;//iteration Number

            Matrix<double> sampWeight = calSampleWeightMatrix(pSampTime.Length, initialParaList, inputNoise);//Sample Weight Matrix
            Matrix<double> prioriParaMatrix = calPrioriParaMatrix(numGauPeaks);//Parameter priori matrix

            Vector<double> pNormWFvector = Vector<double>.Build.Dense(pNormWF);//Normalized WF vector
            Vector<double> pParaIterEstimate = DenseVector.OfArray(pInitialEstimate_Norm);//Estimated parameters from interation            
            Vector<double> pParaIterVec_unNorm;// unnormalized paraters during iteration

            Matrix<double> A_derivative = calADeriativeMatrix(pSampTime, pParaIterEstimate, numGauPeaks);//Matrix of derivatives of the model waveform with respect to the parameters.
            //Vector<double> pModelWaveform = calModeledWF(pSampTime, pParaIterEstimate, numGauPeaks);//Waveform calculated from the initial estimated parameters
            Vector<double> pParaChangeVec = Vector<double>.Build.Dense(pInitialEstimate_Norm.Length);//Parameter changes;

            //Matrix<double> pWeightAroundPeak = calWeightAroundPeak(initialParaList, pNormWF);

            bool flag_iteration = true;
            while (flag_iteration)
            {
                Vector<double> pWFdifference = pNormWFvector - pModelWaveform_Norm;
                Vector<double> pWeightedWFdifference = pWFdifference;//pWeightAroundPeak *difference * weight

                Matrix<double> pTemp = A_derivative.Transpose() * sampWeight * A_derivative;
                Matrix<double> pTemp2 = pTemp + prioriParaMatrix;

                pParaChangeVec = (A_derivative.Transpose() * sampWeight * A_derivative + prioriParaMatrix).Inverse() * A_derivative.Transpose() * sampWeight * pWeightedWFdifference;
                Vector<double> ParaChgVecTemp = DenseVector.OfVector(pParaChangeVec);

                #region constrain paramter change
                for (int i = 0; i < numGauPeaks; i++)//Constraints for parameter change
                {
                    if (Math.Abs(pParaChangeVec[i]) >= pParaIterEstimate[i] * ampMaxDelta)
                    {
                        if (pParaChangeVec[i] < 0)
                            pParaChangeVec[i] = -pParaIterEstimate[i] * 0.03;
                        else
                            pParaChangeVec[i] = pParaIterEstimate[i] * 0.03;

                        //pParaChangeVec[i] = 0;
                    }

                    if ((pParaIterEstimate[i] + pParaChangeVec[i]) <= 0) pParaChangeVec[i] = 0;

                    //for this step, if the horizontal shift > timeLocMaxDelta, then only allow 10% of the change
                    if (Math.Abs(pParaChangeVec[i + numGauPeaks]) >= timeLocMaxDelta)
                    {
                        if (pParaChangeVec[i + numGauPeaks] > 0)
                            pParaChangeVec[i + numGauPeaks] = timeLocMaxDelta * 0.1;
                        else
                            pParaChangeVec[i + numGauPeaks] = -timeLocMaxDelta * 0.1;

                        //pParaChangeVec[i + numGauPeaks] = 0;
                    }


                    if (Math.Abs(pParaChangeVec[i + 2 * numGauPeaks]) >= pParaIterEstimate[i + 2 * numGauPeaks] * sigMaxDelta)
                    {
                        if (pParaChangeVec[i + 2 * numGauPeaks] > 0)
                            pParaChangeVec[i + 2 * numGauPeaks] = pParaIterEstimate[i + 2 * numGauPeaks] * 0.05;
                        else
                            pParaChangeVec[i + 2 * numGauPeaks] = -pParaIterEstimate[i + 2 * numGauPeaks] * 0.05;

                        //pParaChangeVec[i + 2 * numGauPeaks] = 0;
                    }

                    if ((pParaIterEstimate[i + 2 * numGauPeaks] + pParaChangeVec[i + 2 * numGauPeaks]) <= 0) pParaChangeVec[i + 2 * numGauPeaks] = 0;
                }

                if (Math.Abs(pParaChangeVec[3 * numGauPeaks]) >= nsMaxDelta * pParaIterEstimate[3 * numGauPeaks])
                {
                    if (pParaChangeVec[3 * numGauPeaks] > 0)
                        pParaChangeVec[3 * numGauPeaks] = pParaIterEstimate[3 * numGauPeaks] * 0.05;
                    else
                        pParaChangeVec[3 * numGauPeaks] = -pParaIterEstimate[3 * numGauPeaks] * 0.05;

                    //pParaChangeVec[3 * numGauPeaks] = 0;
                }
                if ((pParaIterEstimate[3 * numGauPeaks] + pParaChangeVec[3 * numGauPeaks]) <= 0) pParaChangeVec[3 * numGauPeaks] = 0;


                pParaIterEstimate = pParaIterEstimate + pParaChangeVec;//Update the parameters

                //compare to the initial peak location, if the total horizontal shift > 3, then drag it back to the initial location
                for (int i = 0; i < numGauPeaks; i++)//Constraints for parameter change
                {
                    if (Math.Abs(pParaIterEstimate[i + numGauPeaks] - pInitialEstimate_Norm[i + numGauPeaks]) > 3)
                    {
                        pParaIterEstimate[i] = pInitialEstimate_Norm[i];
                        pParaIterEstimate[i + numGauPeaks] = pInitialEstimate_Norm[i + numGauPeaks];
                        pParaIterEstimate[i + 2 * numGauPeaks] = pInitialEstimate_Norm[i + 2 * numGauPeaks];
                    }
                }
                //if (drag) pParaIterEstimate[3 * numGauPeaks] = pInitialEstimate[3 * numGauPeaks];

                //if (pParaIterEstimate[3 * numGauPeaks] <= 0) pParaIterEstimate[3 * numGauPeaks] = inputNoise;

                #endregion

                A_derivative = calADeriativeMatrix(pSampTime, pParaIterEstimate, numGauPeaks);//new matrix of derivatives of the model waveform with respect to the parameters.

                #region calculate model waveform based on the updated parameters
                //un-normalize the parameters firstly
                pParaIterVec_unNorm = DenseVector.OfVector(pParaIterEstimate);
                pParaIterVec_unNorm[3 * numGauPeaks] = pParaIterEstimate[3 * numGauPeaks] * (maxWF - minWF) + minWF;
                for (int i = 0; i < numGauPeaks; i++)
                {
                    pParaIterVec_unNorm[i] = (pParaIterEstimate[i] + pParaIterEstimate[3 * numGauPeaks]) * (maxWF - minWF) - pParaIterVec_unNorm[3 * numGauPeaks] + minWF;
                }

                //calculate the un-normalized model waveform
                pModelWaveform = calModeledWF(pSampTime, pParaIterVec_unNorm, numGauPeaks);//waveform calculated from the newly estimated parameters.

                //normalize the model waveform
                for (int i = 0; i < pModelWaveform.Count; i++)
                {
                    pModelWaveform_Norm[i] = (pModelWaveform[i] - minWF) / (maxWF - minWF);
                }
                #endregion

                iterationNum++;

                #region iteration judge
                int judgeCnt = 0;

                for (int i = 0; i < numGauPeaks; i++)
                {
                    if (Math.Abs(pParaChangeVec[i]) / pParaIterEstimate[i] < ampCK & Math.Abs(pParaChangeVec[i + numGauPeaks]) < timePosCK & Math.Abs(pParaChangeVec[i + 2 * numGauPeaks]) / pParaIterEstimate[i + 2 * numGauPeaks] < sigCK) judgeCnt++;
                }

                if (pParaChangeVec[3 * numGauPeaks] / pParaIterEstimate[3 * numGauPeaks] < noiseCK) judgeCnt++;
                if (!(judgeCnt < numGauPeaks + 1) & iterationNum > 5) flag_iteration = false;

                if (iterationNum > maxIterNum) flag_iteration = false;
                #endregion
            }

            #endregion

            #region un-normalize the waveform and parameters

            double[] pUnnormalizedWF = new double[pModelWaveform.Count];//Un-normalized waveform
            for (int i = 0; i < pModelWaveform.Count; i++)
            {
                pUnnormalizedWF[i] = pModelWaveform[i];
            }

            double[] unNormParameter = new double[pParaIterEstimate.Count];//Un-normalized Parameter
            unNormParameter[3 * numGauPeaks] = pParaIterEstimate[3 * numGauPeaks] * (maxWF - minWF) + minWF;//unnormalize the noise level

            for (int i = 0; i < numGauPeaks; i++)
            {
                unNormParameter[i] = (pParaIterEstimate[i] + pParaIterEstimate[3 * numGauPeaks]) * (maxWF - minWF) + minWF - unNormParameter[3 * numGauPeaks];
                unNormParameter[i + 1 * numGauPeaks] = pParaIterEstimate[i + 1 * numGauPeaks];
                unNormParameter[i + 2 * numGauPeaks] = pParaIterEstimate[i + 2 * numGauPeaks];
            }

            #endregion

            #region prepare the output
            fittedParaList = new List<singleGaussianParameters>();
            singleGaussianParameters pOnePeakPara;
            for (int i = 0; i < numGauPeaks; i++)
            {
                pOnePeakPara = new singleGaussianParameters();

                pOnePeakPara.Amplitude = Convert.ToSingle(unNormParameter[i]);
                pOnePeakPara.TimeLocation = Convert.ToSingle(unNormParameter[i + 1 * numGauPeaks]);
                pOnePeakPara.Sigma = Convert.ToSingle(unNormParameter[i + 2 * numGauPeaks]);

                fittedParaList.Add(pOnePeakPara);
            }

            fittedNoise = Convert.ToSingle(unNormParameter[3 * numGauPeaks]);
            #endregion

            return pUnnormalizedWF;
        }

        private float calFitGaussianSTD(float[] p1, float[] p2)
        {
            float fitGauSTD = 0;

            float[] pDiff = calTwoArraysDiff(p1, p2);
            float meanV = pDiff.Average();

            //float sumofSquaresDiff = pDiff.Select(val => (val * val)).Sum();
            float sumofSquaresDiff = pDiff.Select(val =>  (val - meanV) * (val - meanV)).Sum();
            fitGauSTD = Convert.ToSingle(Math.Sqrt(sumofSquaresDiff / pDiff.Length));

            return fitGauSTD;
        }

        private float[] calTwoArraysDiff(float[] p1, float[] p2)
        {
            float[] diffArray = new float[p1.Length];

            for (int i = 0; i < p1.Length; i++)
            {
                diffArray[i] = p1[i] - p2[i];
            }

            return diffArray;
        }

        private Matrix<double> calSampleWeightMatrix(int pSampleNum, List<singleGaussianParameters> initialParaList, float noiseLevel)
        {
            if (initialParaList.Count == 0) return null;
            initialParaList.Sort((x, y) => -1 * x.Amplitude.CompareTo(y.Amplitude));
            singleGaussianParameters p1stPeak = initialParaList[0];
            float p1stAbsAmp = p1stPeak.Amplitude - noiseLevel;
            double weight= 10;
            double peakWeight = 100;
            //neighbor bin scale
            int scale = 4;
            //control the number of neighbors around peak
            float neighborNumArdPeak = 0;

            #region set the weight based on max peak amplitude
            if (p1stAbsAmp >= 1.2) 
            {
                weight = 200;
                peakWeight = 15000;
                neighborNumArdPeak = 1;
                scale = 15;
            }

            if(p1stAbsAmp>=1.0 && p1stAbsAmp <1.2)
            {
                weight = 100;
                peakWeight = 8000;
                neighborNumArdPeak = 2;
                scale = 8;
            }

            if (p1stAbsAmp >= 0.6 && p1stAbsAmp < 1.0)
            {
                weight = 50;
                peakWeight = 3000;
                neighborNumArdPeak = 2;
                scale = 5;
            }

            if (p1stAbsAmp >= 0.3 && p1stAbsAmp < 0.6)
            {
                weight = 30;
                peakWeight = 1500;
                neighborNumArdPeak = 2;
                scale = 5;
            }

            if (p1stAbsAmp >= 0.15 && p1stAbsAmp<0.3)
            {
                weight = 10;
                peakWeight = 1000;
                neighborNumArdPeak = 1;
                scale = 5;
            }

            if(p1stAbsAmp <0.15)
            {
                weight = 5;
                peakWeight = 800;
                neighborNumArdPeak = 0;
                scale = 6;
            }
            #endregion

            //double weight = 100;//1 / Math.Pow(0.03, 2);//
            Matrix<double> pWeightMatrix = DenseMatrix.Build.Diagonal(pSampleNum, pSampleNum, weight);

            int peakNum = initialParaList.Count;

            //use hierarchical Weight or not
            if (useHierarchWt)
            {
                #region
                for (int i = 0; i < initialParaList.Count; i++)
                {
                    singleGaussianParameters peakPara = initialParaList[i];
                    double peakLocation = peakPara.TimeLocation;
                    int peakFloorGate = Convert.ToInt32(Math.Floor(peakLocation));
                    int peakCeilGate = Convert.ToInt32(Math.Ceiling(peakLocation));

                    switch (i)
                    {
                        case 0:
                            pWeightMatrix[peakFloorGate, peakFloorGate] = peakWeight;
                            pWeightMatrix[peakCeilGate, peakCeilGate] = peakWeight;
                            for (int j = 0; j < neighborNumArdPeak; j++)
                            {
                                if (peakFloorGate - (j + 1) > 0 && (pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] == weight))
                                    pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] = peakWeight / scale;
                                if (peakCeilGate + (j + 1) < (pSampleNum - 1) && (pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] == weight))
                                    pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] = peakWeight / scale;
                            }
                            break;
                        case 1:
                            pWeightMatrix[peakFloorGate, peakFloorGate] = peakWeight *3/4;
                            pWeightMatrix[peakCeilGate, peakCeilGate] = peakWeight * 3/4;
                            for (int j = 0; j < neighborNumArdPeak; j++)
                            {
                                if (peakFloorGate - (j + 1) > 0 && (pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] == weight))
                                    pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] = peakWeight / scale;
                                if (peakCeilGate + (j + 1) < (pSampleNum - 1) && (pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] == weight))
                                    pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] = peakWeight / scale;
                            }
                            break;
                        case 2:
                            pWeightMatrix[peakFloorGate, peakFloorGate] = peakWeight * 3 / 4;
                            pWeightMatrix[peakCeilGate, peakCeilGate] = peakWeight * 3 / 4;
                            for (int j = 0; j < neighborNumArdPeak; j++)
                            {
                                if (peakFloorGate - (j + 1) > 0 && (pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] == weight))
                                    pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] = peakWeight / scale;
                                if (peakCeilGate + (j + 1) < (pSampleNum - 1) && (pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] == weight))
                                    pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] = peakWeight / scale;
                            }
                            break;
                        default:
                            pWeightMatrix[peakFloorGate, peakFloorGate] = peakWeight * 2 / 4;
                            pWeightMatrix[peakCeilGate, peakCeilGate] = peakWeight * 2 / 4;
                            for (int j = 0; j < neighborNumArdPeak; j++)
                            {
                                if (peakFloorGate - (j + 1) > 0 && (pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] == weight))
                                    pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] = peakWeight / scale;
                                if (peakCeilGate + (j + 1) < (pSampleNum - 1) && (pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] == weight))
                                    pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] = peakWeight / scale;
                            }
                            break;
                    }
                }
                #endregion
            }
            else
            {
                #region
                foreach (singleGaussianParameters peakPara in initialParaList)
                {
                    double peakLocation = peakPara.TimeLocation;
                    int peakFloorGate = Convert.ToInt32(Math.Floor(peakLocation));
                    int peakCeilGate = Convert.ToInt32(Math.Ceiling(peakLocation));

                    //4000-2000 is tested to produce better result
                    pWeightMatrix[peakFloorGate, peakFloorGate] = peakWeight;
                    pWeightMatrix[peakCeilGate, peakCeilGate] = peakWeight;

                    for (int j = 0; j < neighborNumArdPeak; j++)
                    {
                        if (peakFloorGate - (j + 1) > 0 && (pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] == weight))
                            pWeightMatrix[peakFloorGate - (j + 1), peakFloorGate - (j + 1)] = peakWeight / scale;
                        if (peakCeilGate + (j + 1) < (pSampleNum - 1) && (pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] == weight))
                            pWeightMatrix[peakCeilGate + (j + 1), peakCeilGate + (j + 1)] = peakWeight / scale;
                    }
                }
                #endregion
            }

            return pWeightMatrix;
        }

        private Matrix<double> calPrioriParaMatrix( int numGauPeaks)
        {
            int pParamNum=3 * numGauPeaks + 1;
            Matrix<double> prioriMatrix = DenseMatrix.Build.Diagonal(pParamNum, pParamNum);

            for (int i = 0; i < numGauPeaks; i++)
            {
                //Amplitude weight
                prioriMatrix[i, i] = 1 / Math.Sqrt(0.001); //60; //
                //Time location weight
                prioriMatrix[i + numGauPeaks, i + numGauPeaks] =  1 / Math.Sqrt(0.1); //60;//
                //Sigma weight
                prioriMatrix[i + 2 * numGauPeaks, i + 2 * numGauPeaks] = 1 / Math.Sqrt(0.001); // 50;//
            }

            //Noise weight
            prioriMatrix[pParamNum - 1, pParamNum - 1] = 1 / Math.Sqrt(1000000);

            return prioriMatrix;
        }

        private Matrix<double> calADeriativeMatrix(double[] pSampTime, Vector<double> pParaEstimate, int numGauPeaks)
        {
            int sampleN = pSampTime.Length;
            int parameterN = pParaEstimate.Count;

            Matrix<double> A = Matrix<double>.Build.Dense(sampleN, parameterN);

            for (int i = 0; i < sampleN; i++)
            {
                for (int j = 0; j < numGauPeaks; j++)
                {
                    A[i, j] = calAmpDerivative(pSampTime[i], pParaEstimate[j + numGauPeaks], pParaEstimate[j + 2 * numGauPeaks]);//3 types of parameters, therefore 2 * numGauPeaks
                    A[i, j + numGauPeaks] = calTimePosDerivative(A[i, j], pSampTime[i], pParaEstimate[j], pParaEstimate[j + numGauPeaks], pParaEstimate[j + 2 * numGauPeaks]);
                    A[i, j + 2 * numGauPeaks] = calSigDerivative(A[i, j + numGauPeaks], pSampTime[i], pParaEstimate[j + numGauPeaks], pParaEstimate[j + 2 * numGauPeaks]);
                }

                A[i, 3 * numGauPeaks] = 1;
            }

            return A;
        }

        private double calAmpDerivative(double pSampleTimeValue, double pTimePosEstimate, double pSigEstimate)
        {
            double pAmpDerivValue = 0;

            pAmpDerivValue = 1 / (Math.Pow(Math.E, Math.Pow(pSampleTimeValue - pTimePosEstimate, 2) / (2 * Math.Pow(pSigEstimate, 2))));

            return pAmpDerivValue;
        }

        private double calTimePosDerivative(double AmpDerivative, double pSampleTimeValue, double pAmpEstimate, double pTimePosEstimate, double pSigEstimate)
        {
            double pTimeDerivValue = 0;
            pTimeDerivValue = pAmpEstimate * AmpDerivative * (pSampleTimeValue - pTimePosEstimate) / Math.Pow(pSigEstimate, 2) ;
            return pTimeDerivValue;
        }

        private double calSigDerivative(double TimeDerivative, double pSampleTimeV, double pTimePosEstimate, double pSigEstimate)
        {
            double pSigDerivative = 0;
            pSigDerivative = TimeDerivative * (pSampleTimeV - pTimePosEstimate) / pSigEstimate;

            return pSigDerivative;
        }

        private Vector<double> calModeledWF(double[] pSampTime, Vector<double> pParaEstimate, int numGauPeaks)
        {
            int pSampleNum = pSampTime.Length;
            Vector<double> pModelWF = Vector<double>.Build.Dense(pSampleNum);
            double tempValue = 0;

            for (int i = 0; i < pSampleNum; i++)
            {
                pModelWF[i] = pModelWF[i] + pParaEstimate[3 * numGauPeaks];
                for (int j = 0; j < numGauPeaks; j++)
                {
                    tempValue = pParaEstimate[j] * calAmpDerivative(pSampTime[i], pParaEstimate[j + numGauPeaks], pParaEstimate[j + 2 * numGauPeaks]);
                    pModelWF[i] = pModelWF[i] + tempValue;
                }
            }

            return pModelWF;
        }

        private double[] calSingleGaussian(double[] sampleTime, double Amp, double TimePos, double Sig, double Noise)
        {
            double[] calculatedSingleGau = new double[sampleTime.Length];

            double singleSampleValue;

            for (int i = 0; i < sampleTime.Length; i++)
            {
                singleSampleValue = Amp * calAmpDerivative(sampleTime[i], TimePos, Sig) + Noise;
                calculatedSingleGau[i] = singleSampleValue;
            }

            return calculatedSingleGau;
        }
        #endregion

        #region read in data
        private Dictionary<string, List<InitialWFPeakParameterNode>> readinInitParaEstimate(string openInitialParameterPathName)
        {
            FileStream readStream = new FileStream(openInitialParameterPathName, FileMode.Open);
            List<Type> knownTypes = new List<Type> { typeof(List<InitialWFPeakParameterNode>) };
            DataContractSerializer serializer = new DataContractSerializer(typeof(Dictionary<string, List<InitialWFPeakParameterNode>>), knownTypes);

            XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(readStream, new XmlDictionaryReaderQuotas());

            Dictionary<string, List<InitialWFPeakParameterNode>> pDictionary = serializer.ReadObject(reader, true) as Dictionary<string, List<InitialWFPeakParameterNode>>;

            readStream.Close();

            return pDictionary;
        }

        private Dictionary<string, List<effectiveSignalDataNode>> readinExtractedWF(string openWFSignalPathName)
        {
            FileStream ReadStream = new FileStream(openWFSignalPathName, FileMode.Open);

            List<Type> knownTypes = new List<Type> { typeof(List<effectiveSignalDataNode>) };
            DataContractSerializer serializer = new DataContractSerializer(typeof(Dictionary<string, List<effectiveSignalDataNode>>), knownTypes);

            XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(ReadStream, new XmlDictionaryReaderQuotas());//CreateTextReader(ReadStream, new XmlDictionaryReaderQuotas());

            Dictionary<string, List<effectiveSignalDataNode>> ptemp = serializer.ReadObject(reader, true) as Dictionary<string, List<effectiveSignalDataNode>>;

            ReadStream.Close();

            return ptemp;
        }

        #endregion

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
