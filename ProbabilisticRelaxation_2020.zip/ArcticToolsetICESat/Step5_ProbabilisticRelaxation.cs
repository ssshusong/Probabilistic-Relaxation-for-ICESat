﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace ArcticToolsetICESat
{
    public class ProbabilisticRelaxation : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public ProbabilisticRelaxation()
        {
        }

        protected override void OnClick()
        {
            frmProbabilityRelaxation pForm = new frmProbabilityRelaxation();
            pForm.ShowDialog();

            ArcMap.Application.CurrentTool = null;
        }

        protected override void OnUpdate()
        {
        }
    }
}
