﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Reflection;
using System.Runtime.Serialization;
using System.Collections.Generic;

namespace DataStructDefinition
{
    public class SerializeAndDeserialize
    {
        #region serialize data
        public void serializeData(string filePathName, List<FPWaveformDataNode> serializeData)
        {
            System.IO.FileStream pFileStream = new System.IO.FileStream(filePathName, FileMode.Create);
            BinaryFormatter biFormatter = new BinaryFormatter();
            biFormatter.Serialize(pFileStream, serializeData);
            pFileStream.Close();
        }

        public void serializeData(string filePathName, Dictionary<string, List<alignWaveformDataNode>> serializeData)
        {
            System.IO.FileStream pFileStream = new System.IO.FileStream(filePathName, FileMode.Create);
            BinaryFormatter biFormatter = new BinaryFormatter();
            biFormatter.Serialize(pFileStream, serializeData);
            pFileStream.Close();
        }

        public void serializeData(string filePathName, Dictionary<string, List<effectiveSignalDataNode>> serializeData)
        {
            System.IO.FileStream pFileStream = new System.IO.FileStream(filePathName, FileMode.Create);
            BinaryFormatter biFormatter = new BinaryFormatter();
            biFormatter.Serialize(pFileStream, serializeData);
            pFileStream.Close();
        }


        #endregion

        #region deserialize data
        public List<FPWaveformDataNode> deSeriralizeData(string filePathName, string fromTypeFullName, string fromType, string toTypeFullName, string toType)
        {
            System.IO.FileStream filestream = new System.IO.FileStream(filePathName, FileMode.Open);
            BinaryFormatter binaryFormatterRead = new BinaryFormatter();

            Type pType = filestream.GetType();

            string toTypeAssemblyName = Assembly.GetExecutingAssembly().FullName;

            DictionarySerializationBinder dic = new DictionarySerializationBinder();

            dic.AddBinding(fromTypeFullName, toTypeFullName);
            dic.AddAssemblyQualifiedTypeBinding(fromType, toType, toTypeAssemblyName);

            binaryFormatterRead.Binder = dic;

            List<FPWaveformDataNode> pTemp = binaryFormatterRead.Deserialize(filestream) as List<FPWaveformDataNode>;

            filestream.Close();
            return pTemp;
        }
        #endregion

    }

    sealed class DictionarySerializationBinder : SerializationBinder
    {
        Dictionary<string, Type> _typeDictionary = new Dictionary<string, Type>();

        public override Type BindToType(string assemblyName, string typeName)
        {
            Type typeToReturn;

            if (_typeDictionary.TryGetValue(typeName, out typeToReturn))
            {
                return typeToReturn;
            }

            else
            {
                return null;
            }
        }

        public void AddBinding(string fromTypeName, string toTypeName)
        {

            Type toType = Type.GetType(toTypeName);

            if (toType == null)
            {
                throw new ArgumentException(string.Format(
                "Help, I could not convert '{0}' to a valid type.", toTypeName));
            }

            _typeDictionary.Add(fromTypeName, toType);

        }

        public void AddAssemblyQualifiedTypeBinding(string fromTypeName, string toTypeName, string toTypeAssemblyName)
        {

            Type typeToSerializeTo = GetAssemblyQualifiedType(toTypeAssemblyName, toTypeName);

            if (typeToSerializeTo == null)
            {

                throw new ArgumentException(string.Format(

                "Help, I could not convert '{0}' to a valid type.", toTypeName));

            }

            _typeDictionary.Add(fromTypeName, typeToSerializeTo);

        }

        private static Type GetAssemblyQualifiedType(string assemblyName, string typeName)
        {

            return Type.GetType(String.Format("{0}, {1}", typeName, assemblyName));

        }
    }

    [Serializable]
    public struct FPWaveformDataNode
    {
        private float[] waveform;
        public float[] Waveform
        {
            get { return waveform; }
            set { waveform = value; }
        }

        private float[] smoothedWF;
        public float[] SmoothedWF
        {
            get { return smoothedWF; }
            set { smoothedWF = value; }
        }

        private float[] timeTag;//relative time in the 1000 gate range
        public float[] TimeTag
        {
            get { return timeTag; }
            set { timeTag = value; }
        }

        private float elev;//already corrected by geoid
        public float Elev
        {
            get { return elev; }
            set { elev = value; }
        }

        private float elevMaxAmp;
        public float ElevMaxAmp
        {
            get { return elevMaxAmp; }
            set { elevMaxAmp = value; }
        }

        //the End Gate Elev has already been corrected by EGM96
        //the elev of the last waveform bin
        private float endGateElev;
        public float EndGateElev
        {
            get { return endGateElev; }
            set { endGateElev = value; }
        }

        private float gmc;
        public float GmC
        {
            get { return gmc; }
            set { gmc = value; }
        }

        //Compression paramters
        private int compType;
        public int CompressionType
        {
            get { return compType; }
            set { compType = value; }
        }

        private int nvalue;
        public int Nvalue
        {
            get { return nvalue; }
            set { nvalue = value; }
        }

        private int pvalue;
        public int Pvalue
        {
            get { return pvalue; }
            set { pvalue = value; }
        }

        private int qvalue;
        public int Qvalue
        {
            get { return qvalue; }
            set { qvalue = value; }
        }

        //Default Gaussian fitted standard deviation
        private float defaultGauFitSTD;
        public float DefaultGauFitSTD
        {
            get { return defaultGauFitSTD; }
            set { defaultGauFitSTD = value; }
        }

        private float geoid;
        public float Geoid
        {
            get { return geoid; }
            set { geoid = value; }
        }

        private int lakeID, threshold;
        public int Threshold
        {
            get { return threshold; }
            set { threshold = value; }
        }
        public int LakeID
        {
            get { return lakeID; }
            set { lakeID = value; }
        }

        private float signalBegin, signalEnd, ldRngOff, maxRngOff;
        public float LdRngOff
        {
            get { return ldRngOff; }
            set { ldRngOff = value; }
        }

        public float MaxRngOff
        {
            get { return maxRngOff; }
            set { maxRngOff = value; }
        }

        public float SignalEnd
        {
            get { return signalEnd; }
            set { signalEnd = value; }
        }
        public float SignalBegin
        {
            get { return signalBegin; }
            set { signalBegin = value; }
        }

        private DateTime dateTime;
        public DateTime DateTime
        {
            get { return dateTime; }
            set { dateTime = value; }
        }

        private long footprintID;
        public long FootprintID
        {
            get { return footprintID; }
            set { footprintID = value; }
        }

        private long granulNum;
        public long GranulNum
        {
            get { return granulNum; }
            set { granulNum = value; }
        }

        private int secondIndex;
        public int SecondIndex
        {
            get { return secondIndex; }
            set { secondIndex = value; }
        }

        private float snr;
        public float SNR
        {
            get { return snr; }
            set { snr = value; }
        }

        private double lat, lon;//WGS84 GCS

        public double Longitude
        {
            get { return lon; }
            set { lon = value; }
        }
        public double Latitude
        {
            get { return lat; }
            set { lat = value; }
        }

        private float validateDEM;
        public float ValidateDEM
        { get { return validateDEM; } set {validateDEM = value; } }
    }

    [Serializable]
    public struct alignWaveformDataNode
    {
        private int lakeID;
        public int LakeID
        {
            get { return lakeID; }
            set { lakeID = value; }
        }

        private DateTime date;
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        private float elev;//already corrected by geoid
        public float Elev
        {
            get { return elev; }
            set { elev = value; }
        }

        private float elevMaxAmp;
        public float ElevMaxAmp
        {
            get { return elevMaxAmp; }
            set { elevMaxAmp = value; }
        }

        private float geoid;
        public float Geoid
        {
            get { return geoid; }
            set { geoid = value; }
        }

        //Default Gaussian fitted standard deviation
        private float defaultGauFitSTD;
        public float DefaultGauFitSTD
        {
            get { return defaultGauFitSTD; }
            set { defaultGauFitSTD = value; }
        }

        private float ldRgOffset, sigBegOffset, sigEndOffset;
        public float SigEndOffset
        {
            get { return sigEndOffset; }
            set { sigEndOffset = value; }
        }
        public float SigBegOffset
        {
            get { return sigBegOffset; }
            set { sigBegOffset = value; }
        }
        public float LdRgOffset
        {
            get { return ldRgOffset; }
            set { ldRgOffset = value; }
        }

        //the End Gate Elev has already been corrected by EGM96
        //the elev of the last waveform bin
        private float endGateElev;
        public float EndGateElev
        {
            get { return endGateElev; }
            set { endGateElev = value; }
        }

        //This is calculated directly from EndGate Elev difference, not rounded.
        private float gateShift;
        public float GateShift
        {
            get { return gateShift; }
            set { gateShift = value; }
        }

        private float snr;
        public float SNR
        {
            get { return snr; }
            set { snr = value; }
        }

        private float[] voltWaveform;
        public float[] VoltWaveform
        {
            get { return voltWaveform; }
            set { voltWaveform = value; }
        }

        private float[] smthVoltWaveform;
        public float[] SmthVoltWaveform
        {
            get { return smthVoltWaveform; }
            set { smthVoltWaveform = value; }
        }

        //time labeled by Elev
        private float[] timeLabelledByElev;
        public float[] TimeLabelledByElev
        {
            get { return timeLabelledByElev; }
            set { timeLabelledByElev = value; }
        }

        private long footprintID;
        public long FootprintID
        {
            get { return footprintID; }
            set { footprintID = value; }
        }

        private long granulNum;
        public long GranulNum
        {
            get { return granulNum; }
            set { granulNum = value; }
        }

        private int secondIndex;
        public int SecondIndex
        {
            get { return secondIndex; }
            set { secondIndex = value; }
        }

        private double lat, lon;//WGS84 GCS
        public double Longitude
        {
            get { return lon; }
            set { lon = value; }
        }
        public double Latitude
        {
            get { return lat; }
            set { lat = value; }
        }

        private float minVolt;
        public float MinVolt
        {
            get { return minVolt; }
            set { minVolt = value; }
        }

        private float noiseLevel;
        public float NoiseLevel
        {
            get { return noiseLevel; }
            set { noiseLevel = value; }
        }

        private float validateDEM;
        public float ValidateDEM
        { get { return validateDEM; } set { validateDEM = value; } }
    }

    [Serializable]
    public struct effectiveSignalDataNode
    {
        private long footprintID;
        public long FootprintID
        {
            get { return footprintID; }
            set { footprintID = value; }
        }

        //Default Gaussian fitted standard deviation
        private float defaultGauFitSTD;
        public float DefaultGauFitSTD
        {
            get { return defaultGauFitSTD; }
            set { defaultGauFitSTD = value; }
        }

        private float gateShift;
        public float GateShift
        {
            get { return gateShift; }
            set { gateShift = value; }
        }

        //begin-gate and end-gate were the two positions used to extract effective signal part
        //these two are calculated by rounding SigBegOffset and SigEndOffset
        //e.g. 
        //if SigBegOffset/0.15 = 30.49
        //round(SigBegOffset/0.15) = 30
        private int begGate;
        public int BegGate
        {
            get { return begGate; }
            set { begGate = value; }
        }

        private float begGateElev;
        public float BegGateElev
        {
            get { return begGateElev; }
            set { begGateElev = value; }
        }

        ////after rounding the sigBegOffset, there might be a slight difference between signal-begin and begin-gate
        ////signalBeginOffset -  BegGateOffset
        ////if > 0, 
        ////e.g. SigBegOffset/0.15 = 30.25, round(SigBegOffset/0.15) = 30
        ////BegGate = 999 - 30
        ////Difference  =  0.25 * 0.15 m
        //private float signalBegAndBegGateDiff;
        //public float SignalBegAndBegGateDiff
        //{
        //    get { return signalBegAndBegGateDiff; }
        //    set { signalBegAndBegGateDiff = value; }
        //}

        private float[] signalWaveform;
        public float[] SignalWaveform
        {
            get { return signalWaveform; }
            set { signalWaveform = value; }
        }

        private float[] smoothedSignalWaveform;
        public float[] SmoothedSignalWaveform
        {
            get { return smoothedSignalWaveform; }
            set { smoothedSignalWaveform = value; }
        }

        private float minVolt;
        public float MinVolt
        {
            get { return minVolt; }
            set { minVolt = value; }
        }

        private float snr;
        public float SNR
        {
            get { return snr; }
            set { snr = value; }
        }

        private float noiseLevel;
        public float NoiseLevel
        {
            get { return noiseLevel; }
            set { noiseLevel = value; }
        }
    }

    [Serializable]
    public struct FirstSecondDerivativeNode
    {
        private long footprintID;
        public long FootprintID
        {
            get { return footprintID; }
            set { footprintID = value; }
        }

        private float minVolt;
        public float MinVolt
        {
            get { return minVolt; }
            set { minVolt = value; }
        }

        private float[] firstDerivative;
        public float[] FirstDerivative
        {
            get { return firstDerivative; }
            set { firstDerivative = value; }
        }

        private float[] secondDerivative;
        public float[] SecondDerivative
        {
            get { return secondDerivative; }
            set { secondDerivative = value; }
        }

        private float[] smoothedSignalWaveform;
        public float[] SmoothedSignalWaveform
        {
            get { return smoothedSignalWaveform; }
            set { smoothedSignalWaveform = value; }
        }

        private float[] initialWaveform;
        public float[] InitialWaveform
        {
            get { return initialWaveform; }
            set { initialWaveform = value; }
        }

        private float noiseLevel;
        public float NoiseLevel
        {
            get { return noiseLevel; }
            set { noiseLevel = value; }
        }
    }

    [Serializable]
    public struct InitialWFPeakParameterNode
    {
        private long footprintID;
        public long FootprintID
        {
            get { return footprintID; }
            set { footprintID = value; }
        }

        private float minVolt;
        public float MinVolt
        {
            get { return minVolt; }
            set { minVolt = value; }
        }

        private float noiseLevel;
        public float NoiseLevel
        {
            get { return noiseLevel; }
            set { noiseLevel = value; }
        }

        private List<singleGaussianParameters> allPeakParameters;
        public List<singleGaussianParameters> AllPeakParameters
        {
            get { return allPeakParameters; }
            set { allPeakParameters = value; }
        }
    }

    [Serializable]
    public struct singleGaussianParameters
    {
        private float amplitude;
        public float Amplitude
        {
            get { return amplitude; }
            set { amplitude = value; }
        }

        private float timeLocation;
        public float TimeLocation
        {
            get { return timeLocation; }
            set { timeLocation = value; }
        }

        private float sigma;
        public float Sigma
        {
            get { return sigma; }
            set { sigma = value; }
        }
    }

    [Serializable]
    public struct fittedGaussianParameterNode
    {
        private long footprintID;
        public long FootprintID
        {
            get { return footprintID; }
            set { footprintID = value; }
        }

        private float initialNoiseLevel;
        public float InitialNoiseLevel
        {
            get { return initialNoiseLevel; }
            set { initialNoiseLevel = value; }
        }


        private float fitNoiseLevel;
        public float FitNoiseLevel
        {
            get { return fitNoiseLevel; }
            set { fitNoiseLevel = value; }
        }

        private float gateShift;
        public float GateShift
        {
            get { return gateShift; }
            set { gateShift = value; }
        }

        private int begGate;
        public int BegGate
        {
            get { return begGate; }
            set { begGate = value; }
        }

        private float begGateElev;
        public float BegGateElev
        {
            get { return begGateElev; }
            set { begGateElev = value; }
        }

        //Default Gaussian fitted standard deviation
        private float defaultGauFitSTD;
        public float DefaultGauFitSTD
        {
            get { return defaultGauFitSTD; }
            set { defaultGauFitSTD = value; }
        }

        private float snr;
        public float SNR
        {
            get { return snr; }
            set { snr = value; }
        }

        //Newly fitting standard deviation
        private float newGauFitSTD;
        public float NewGauFitSTD
        {
            get { return newGauFitSTD; }
            set { newGauFitSTD = value; }
        }

        private float[] initialVoltWaveform;
        public float[] InitialVoltWaveform
        {
            get { return initialVoltWaveform; }
            set { initialVoltWaveform = value; }
        }

        private float[] smoothedVoltWaveform;
        public float[] SmoothedVoltWaveform
        {
            get { return smoothedVoltWaveform; }
            set { smoothedVoltWaveform = value; }
        }

        private float[] fittedVoltWaveform;
        public float[] FittedVoltWaveform
        {
            get { return fittedVoltWaveform; }
            set { fittedVoltWaveform = value; }
        }

        private List<singleGaussianParameters> initialPeaksParameters;
        public List<singleGaussianParameters> InitialPeaksParameters
        {
            get { return initialPeaksParameters; }
            set { initialPeaksParameters = value; }
        }

        private List<singleGaussianParameters> fittedPeaksParameters;
        public List<singleGaussianParameters> FittedPeaksParameters
        {
            get { return fittedPeaksParameters; }
            set { fittedPeaksParameters = value; }
        }

        private List<singleGaussianParameters> finalCkParameters;
        public List<singleGaussianParameters> FinalCkParameters
        {
            get { return finalCkParameters; }
            set { finalCkParameters = value; }
        }
    }

    [Serializable]
    struct correctedFPElevNode
    {
        private long granulNum;
        public long GranulNum
        {
            get { return granulNum; }
            set { granulNum = value; }
        }

        private int secondIndex;
        public int SecondIndex
        {
            get { return secondIndex; }
            set { secondIndex = value; }
        }

        private int lakeID;
        public int LakeID
        {
            get { return lakeID; }
            set { lakeID = value; }
        }

        private long footprintID;
        public long FootprintID
        {
            get { return footprintID; }
            set { footprintID = value; }
        }

        private DateTime date;
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        private float landRgOffset;
        public float LandRgOffset
        {
            get { return landRgOffset; }
            set { landRgOffset = value; }
        }

        private float maxAmpOffset;
        public float MaxAmpOffset
        {
            get { return maxAmpOffset; }
            set { maxAmpOffset = value; }
        }

        private float probRelaxationOffset;
        public float ProbRelaxationOffset
        {
            get { return probRelaxationOffset; }
            set { probRelaxationOffset = value; }
        }

        private float elevDefault;
        public float ElevDefault
        {
            get { return elevDefault; }
            set { elevDefault = value; }
        }

        private float elevMaxAmp;
        public float ElevMaxAmp
        {
            get { return elevMaxAmp; }
            set { elevMaxAmp = value; }
        }

        private float elevProbRelaxation;
        public float ElevProbRelaxation
        {
            get { return elevProbRelaxation; }
            set { elevProbRelaxation = value; }
        }

        private float snr;
        public float SNR
        {
            get { return snr; }
            set { snr = value; }
        }

        //Default Gaussian fitted standard deviation
        private float defaultGauFitSTD;
        public float DefaultGauFitSTD
        {
            get { return defaultGauFitSTD; }
            set { defaultGauFitSTD = value; }
        }

        //Newly fitting standard deviation
        private float newGauFitSTD;
        public float NewGauFitSTD
        {
            get { return newGauFitSTD; }
            set { newGauFitSTD = value; }
        }

        private float geoid;
        public float Geoid
        {
            get { return geoid; }
            set { geoid = value; }
        }

        private double lat, lon;//WGS84 GCS
        public double Longitude
        {
            get { return lon; }
            set { lon = value; }
        }
        public double Latitude
        {
            get { return lat; }
            set { lat = value; }
        }

        private int begGate;
        public int BegGate
        {
            get { return begGate; }
            set { begGate = value; }
        }

        private float begGateElev;
        public float BegGateElev
        {
            get { return begGateElev; }
            set { begGateElev = value; }
        }

        private float finalPeakLocation;
        public float FinalPeakLocation
        {
            get { return finalPeakLocation; }
            set { finalPeakLocation = value; }
        }

        private int finalPeakIndex;
        public int FinalPeakIndex
        {
            get { return finalPeakIndex; }
            set { finalPeakIndex = value; }
        }

        //initial estimation of peak number
        private int initialPeakNum;
        public int InitialPeakNum
        {
            get { return initialPeakNum; }
            set { initialPeakNum = value; }
        }

        //the number of peaks finally identified
        private int fittedPeakNum;
        public int FittedPeakNum
        {
            get { return fittedPeakNum; }
            set { fittedPeakNum = value; }
        }

        private bool hasNeighbor;
        public bool HasNeighbor
        {
            get { return hasNeighbor; }
            set { hasNeighbor = value; }
        }

        private float validateDEM;
        public float ValidateDEM
        {
            get { return validateDEM; }
            set { validateDEM = value; }
        }

        //the probabilities of each peak during the iteration
        private Dictionary<int, List<float>> probabilityChange;
        public Dictionary<int, List<float>> ProbabilityChange
        {
            get { return probabilityChange; }
            set { probabilityChange = value; }
        }

        private Dictionary<int, float> neighborProbDiffSumChang;
        public Dictionary<int, float> NeighborProbDiffSumChang
        {
            get { return neighborProbDiffSumChang; }
            set { neighborProbDiffSumChang = value; }
        }

        private Dictionary<int, float> neighborhoodEntropyChange;
        public Dictionary<int, float> NeighborhoodEntropyChange
        {
            get { return neighborhoodEntropyChange; }
            set { neighborhoodEntropyChange = value; }
        }

    }

    [Serializable]
    struct IterationCriteria
    {
        private int iterationNum;
        public int IterationNum
        {
            get { return iterationNum; }
            set { iterationNum = value; }
        }

        //sum of absolute probability differences between adjacent iterations
        private float probDiffAdjacentIter;
        public float ProbDiffAdjacentIter
        {
            get { return probDiffAdjacentIter; }
            set { probDiffAdjacentIter = value; }
        }

        //sum of absolute probability differences between initial iteration and current iteration
        private float probDiffInitialCurrent;
        public float ProbDiffInitialCurrent
        {
            get { return probDiffInitialCurrent; }
            set { probDiffInitialCurrent = value; }
        }

        //entropy in each iteration
        private float entropy;
        public float Entropy
        {
            get { return entropy; }
            set { entropy = value; }
        }

    }

    [Serializable]
    struct FootprintNeighborhoodNode
    {
        //number of peaks in the objective footprint
        private int peakNumber;
        public int PeakNumber
        {
            get { return peakNumber; }
            set { peakNumber = value; }
        }

        //contain the neighboring FP ID and also the number of peaks in that neighboring FP
        private Dictionary<long, int> neighborsDict;
        public Dictionary<long, int> NeighborsDict
        {
            get { return neighborsDict; }
            set { neighborsDict = value; }
        }

    }
}