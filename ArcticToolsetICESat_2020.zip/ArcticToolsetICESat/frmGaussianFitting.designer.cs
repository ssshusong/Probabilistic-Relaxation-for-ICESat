﻿namespace ArcticToolsetICESat
{
    partial class frmGaussianFitting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnOpenInitial = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.fittingBtn = new System.Windows.Forms.Button();
            this.btnOpn = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(99, 41);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(235, 20);
            this.textBox2.TabIndex = 35;
            // 
            // btnOpenInitial
            // 
            this.btnOpenInitial.Location = new System.Drawing.Point(348, 39);
            this.btnOpenInitial.Name = "btnOpenInitial";
            this.btnOpenInitial.Size = new System.Drawing.Size(53, 23);
            this.btnOpenInitial.TabIndex = 34;
            this.btnOpenInitial.Text = "Open";
            this.btnOpenInitial.UseVisualStyleBackColor = true;
            this.btnOpenInitial.Click += new System.EventHandler(this.btnOpenInitial_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "Initial Parameter: ";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(348, 66);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(53, 23);
            this.btnSave.TabIndex = 32;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 31;
            this.label2.Text = "Output Fittings: ";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(99, 68);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(235, 20);
            this.textBox3.TabIndex = 30;
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(262, 106);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(57, 23);
            this.CancelBtn.TabIndex = 29;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // fittingBtn
            // 
            this.fittingBtn.Location = new System.Drawing.Point(76, 106);
            this.fittingBtn.Name = "fittingBtn";
            this.fittingBtn.Size = new System.Drawing.Size(57, 23);
            this.fittingBtn.TabIndex = 28;
            this.fittingBtn.Text = "Fitting";
            this.fittingBtn.UseVisualStyleBackColor = true;
            this.fittingBtn.Click += new System.EventHandler(this.fittingBtn_Click);
            // 
            // btnOpn
            // 
            this.btnOpn.Location = new System.Drawing.Point(348, 10);
            this.btnOpn.Name = "btnOpn";
            this.btnOpn.Size = new System.Drawing.Size(53, 23);
            this.btnOpn.TabIndex = 27;
            this.btnOpn.Text = "Open";
            this.btnOpn.UseVisualStyleBackColor = true;
            this.btnOpn.Click += new System.EventHandler(this.btnOpn_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(5, 15);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(62, 13);
            this.Label1.TabIndex = 26;
            this.Label1.Text = "Waveform: ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(99, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(235, 20);
            this.textBox1.TabIndex = 25;
            // 
            // frmGaussianFitting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 137);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.btnOpenInitial);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.fittingBtn);
            this.Controls.Add(this.btnOpn);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.textBox1);
            this.Name = "frmGaussianFitting";
            this.Text = "frmGaussianFitting";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox textBox2;
        internal System.Windows.Forms.Button btnOpenInitial;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.TextBox textBox3;
        internal System.Windows.Forms.Button CancelBtn;
        internal System.Windows.Forms.Button fittingBtn;
        internal System.Windows.Forms.Button btnOpn;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox textBox1;
    }
}