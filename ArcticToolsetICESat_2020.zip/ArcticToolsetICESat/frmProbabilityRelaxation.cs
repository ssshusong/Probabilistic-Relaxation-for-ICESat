﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Xml;

using Microsoft.Office.Core;
using Microsoft.Office.Interop;
using Excel = Microsoft.Office.Interop.Excel;

using DataStructDefinition;

namespace ArcticToolsetICESat
{
    public partial class frmProbabilityRelaxation : Form
    {
        #region public variable
        string openInitialDataPathName;
        string openFittedParameterPathName;
        string saveCorrectedFPPathName;

        int numNeighborOneSide = 2;
        float probDiffStopCriteria = 0.01f;
        float entropyDiffStopCriteria = 0.25f;
        float probInitCurrDiffStopCriteria = 100.0f;//temporary
        int maxIterationNumber = 100;

        //peak amplitude should not be lower than the value below.
        float absPeakAmpControlFinal = 0.01f;
        //SNR control
        float SNRcontrol = 0.0f;
        float RMSEcontrol = 0.01f;
        float defaultRMSEcontrol = 0.05f;

        //determine which distance formula should be used; True --> calculateCompatibility, False --> calculateCompatibility2 (location difference)
        bool DisFlag = false;

        //Peak-distance (Flatness) Coefficient, used in the calculation of compatibility
        float flatnessCoef = 5;

        //High peak criterion: the highest peak should be at least 2 times higher than the second highest peak
        //Also amplitude of the highest peak should be at least larger than 0.4
        float highPeakRatio = 2;
        float absHighPeakAmp = 0.4f;
 

        public frmProbabilityRelaxation()
        {
            InitializeComponent();
        }

        private void btnOpn_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Title = "Open initial dataset";
            openDialog.Filter = "DAT（*.dat)|*.dat";
            openDialog.ShowDialog();
            openInitialDataPathName = openDialog.FileName;
            textBox1.Enabled = true;
            textBox1.Text = openInitialDataPathName;
            openDialog.Dispose();
        }

        private void btnOpenInitial_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Title = "Open fitted parameter estimates";
            openDialog.Filter = "DAT（*.dat)|*.dat";
            openDialog.ShowDialog();
            openFittedParameterPathName = openDialog.FileName;
            textBox2.Enabled = true;
            textBox2.Text = openFittedParameterPathName;
            openDialog.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.Title = "Save Probability Relaxation Results";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                saveCorrectedFPPathName = saveFileDialog1.FileName;
                textBox3.Text = saveCorrectedFPPathName;
            }
        }
        #endregion

        #region Main Entry

        private void fittingBtn_Click(object sender, EventArgs e)
        {
            #region check parameters
            if (textBox1.Text == null)
            {
                MessageBox.Show("Choose initial dataset.");
                return;
            }
            if (textBox2.Text == null)
            {
                MessageBox.Show("Choose parameter estimates.");
                return;
            }
            if (textBox3.Text == null)
            {
                MessageBox.Show("Specify output.");
                return;
            }

            #endregion

            #region readin initial dataset and
            Dictionary<string, List<alignWaveformDataNode>> pInitialDataset = readinInitialDataset(openInitialDataPathName);

            Dictionary<string, List<fittedGaussianParameterNode>> pFittedParaDict = readinFittedParameter(openFittedParameterPathName);
            #endregion

            #region Run Probabilistic Relaxation

            #region filter out the footprints with ineligible attributes
            Dictionary<string, List<fittedGaussianParameterNode>> pFilteredFittedParaDict = new Dictionary<string, List<fittedGaussianParameterNode>>();
            foreach (KeyValuePair<string, List<fittedGaussianParameterNode>> pKeyValue in pFittedParaDict)
            {
                string lakeID_Date = pKeyValue.Key;
                List<fittedGaussianParameterNode> pOneLakeProfile = pKeyValue.Value;
                List<fittedGaussianParameterNode> pNewProfile = new List<fittedGaussianParameterNode>();

                foreach (fittedGaussianParameterNode pFPfittedPara in pOneLakeProfile)
                {
                    List<singleGaussianParameters> pPeaks = pFPfittedPara.FittedPeaksParameters;
                    List<singleGaussianParameters> pFilteredPeaks = new List<singleGaussianParameters>(pPeaks);

                    foreach (singleGaussianParameters pSinglePeak in pPeaks)
                    {
                        if (pSinglePeak.Amplitude < absPeakAmpControlFinal) pFilteredPeaks.Remove(pSinglePeak);
                    }

                    if (pFilteredPeaks.Count == 0) continue;

                    float pSNR = pFPfittedPara.SNR;
                    float pRMSE = pFPfittedPara.NewGauFitSTD;
                    float defaultRMSE = pFPfittedPara.DefaultGauFitSTD;
                    if (pSNR < SNRcontrol && pRMSE < RMSEcontrol && defaultRMSE < defaultRMSEcontrol) continue;

                    fittedGaussianParameterNode pCheckedFP = pFPfittedPara;
                    pCheckedFP.FinalCkParameters = pFilteredPeaks;
                    pNewProfile.Add(pCheckedFP);
                }
                pFilteredFittedParaDict.Add(lakeID_Date, pNewProfile);
            }
            #endregion

            Dictionary<string, List<fittedGaussianParameterNode>> pTempDict = pFittedParaDict;

            //output iteration criteria
            Dictionary<string, List<IterationCriteria>> pIterationCriteria;

            //1st key == lakeID_Date, 2nd key == footprintID
            Dictionary<string, Dictionary<long, correctedFPElevNode>> pProbRelaxationCorrectedDict = runProbRelaxationAlgo(pFilteredFittedParaDict, pInitialDataset, out pIterationCriteria);

            #endregion

            #region save the result
            SaveToExcel(pProbRelaxationCorrectedDict);

            saveResults(pProbRelaxationCorrectedDict);

            #endregion

            this.Close();
        }

        private void SaveToExcel(Dictionary<string, Dictionary<long, correctedFPElevNode>> pProbRelaxationCorrectedDict)
        {
            int position = saveCorrectedFPPathName.LastIndexOf("\\");
            string pSavePath = saveCorrectedFPPathName.Substring(0, position + 1);

            //generate an Excel object
            Excel.Application pExcelApp = new Excel.Application();

            #region create a workbook for corrected attributes and populate the values
            Excel.Workbook xlsWBook1 = pExcelApp.Workbooks.Add();
            Excel.Sheets xlsSheets1 = xlsWBook1.Worksheets;

            foreach (KeyValuePair<string, Dictionary<long, correctedFPElevNode>> pLakeProfile in pProbRelaxationCorrectedDict)
            {
                string lakeID_Date = pLakeProfile.Key;
                int tempPos = lakeID_Date.LastIndexOf("/");
                lakeID_Date = lakeID_Date.Substring(0, tempPos + 5);
                string lakeID_Date_new = lakeID_Date.Replace("/", "_");
                //create a new worksheet for each lake profile --> Attributes
                Excel.Worksheet xlsWSheet1 = xlsSheets1.Add();
                xlsWSheet1.Name = lakeID_Date_new + "_Attributes";

                #region Populate the attributes of each footprint except for the probability of each peak
                Dictionary<long, correctedFPElevNode> pCorrectedLakeProfile = pLakeProfile.Value;

                #region fill in the attributes names
                xlsWSheet1.Cells[1, 1] = "FPID";
                xlsWSheet1.Cells[1, 2] = "Date";
                xlsWSheet1.Cells[1, 3] = "Lat";
                xlsWSheet1.Cells[1, 4] = "Lon";
                xlsWSheet1.Cells[1, 5] = "EleDefault";
                xlsWSheet1.Cells[1, 6] = "EleProRelax";
                xlsWSheet1.Cells[1, 7] = "Validate DEM";

                #endregion

                int i = 2;
                foreach (KeyValuePair<long, correctedFPElevNode> pCorrectedFPkeyValue in pCorrectedLakeProfile)
                {
                    long footprintID = pCorrectedFPkeyValue.Key;
                    correctedFPElevNode pFP = pCorrectedFPkeyValue.Value;

                    xlsWSheet1.Cells[i, 1] = footprintID;
                    xlsWSheet1.Cells[i, 2] = pFP.Date;
                    xlsWSheet1.Cells[i, 3] = pFP.Latitude;
                    xlsWSheet1.Cells[i, 4] = pFP.Longitude;
                    xlsWSheet1.Cells[i, 5] = pFP.ElevDefault;
                    xlsWSheet1.Cells[i, 6] = pFP.ElevProbRelaxation;
                    xlsWSheet1.Cells[i, 7] = pFP.ValidateDEM;


                    i++;
                }
                #endregion
            }

            xlsWBook1.SaveAs(pSavePath + "ProbRelaxation_Result.xlsx");
            xlsWBook1.Close(Type.Missing, Type.Missing, Type.Missing);
            #endregion

            pExcelApp.Quit();
        }

        private void saveResults(Dictionary<string, Dictionary<long, correctedFPElevNode>> pProbRelaxationCorrectedDict)
        {
            int position = saveCorrectedFPPathName.LastIndexOf("\\");
            string pPath = saveCorrectedFPPathName.Substring(0, position + 1);

            List<Type> knownTypes = new List<Type> { typeof(Dictionary<long, correctedFPElevNode>) };
            DataContractSerializer serializer = new DataContractSerializer(typeof(Dictionary<string, Dictionary<long, correctedFPElevNode>>), knownTypes);

            System.IO.FileStream fileStream = new FileStream(pPath + "Step5_ProbRelaxationCorrectedElev.dat", FileMode.Create);
            serializer.WriteObject(fileStream, pProbRelaxationCorrectedDict);
            fileStream.Close();
        }

        #endregion

        #region functions for Probability Relaxation
        private Dictionary<string, Dictionary<long, correctedFPElevNode>> runProbRelaxationAlgo(Dictionary<string, List<fittedGaussianParameterNode>> pFittedParaDict, Dictionary<string, List<alignWaveformDataNode>> pInitialDataset, out Dictionary<string, List<IterationCriteria>> pIterationCriteriaDict)
        {
            #region output data
            //1st key == lakeID_Date, 2nd key == footprintID
            Dictionary<string, Dictionary<long, correctedFPElevNode>> pProbRelaxationCorrDict = new Dictionary<string, Dictionary<long, correctedFPElevNode>>();

            //stopping criteria in the iteration process, key = lakeID_Date
            //1st key == lakeID_Date
            pIterationCriteriaDict = new Dictionary<string, List<IterationCriteria>>();

            #endregion

            #region relaxation iteration
            foreach (KeyValuePair<string, List<fittedGaussianParameterNode>> pOneICESatPassOneLake in pFittedParaDict)
            {
                #region output data
                //Generate a new dictionary for output
                //key = footprintID
                Dictionary<long, correctedFPElevNode> pCorrectedElevList = new Dictionary<long, correctedFPElevNode>();

                //Generate a list for stopping criteria
                List<IterationCriteria> pStopCriteriaList = new List<IterationCriteria>();

                #endregion

                #region get previous-step result
                string lakeID_Date = pOneICESatPassOneLake.Key;
                //get the fitted parameters
                List<fittedGaussianParameterNode> fittedParaOnOneLakeEachPass = pOneICESatPassOneLake.Value;
                //get the initial dataset
                List<alignWaveformDataNode> initialAlignedDataset = pInitialDataset[lakeID_Date];

                #endregion

                #region calculate initial probability
                //calculate initial probability for each peak
                //key is the Footprint ID, value is the peaks' probabilities
                //the 1st value is the probability of the 1st peak, 2nd value for 2nd peak, etc.
                Dictionary<long, float[]> pInitialPeakProbs = calInitialPeakProbability(fittedParaOnOneLakeEachPass);

                #endregion

                #region find neighborhood and construct the compatibility matrix
                //this dictionary describes the neighborhood for each objective footprint; key = objective footprint ID
                Dictionary<long, FootprintNeighborhoodNode> pNeighborhoodIdentifier = findNeighbors(fittedParaOnOneLakeEachPass);
                //1st key string = FootprintID_PeakID; 2nd key string = FootprintID_PeakID; float value -> compatibility
                Dictionary<string, Dictionary<string, float>> pCompatibilityMatrix = constructMatrix(ref pNeighborhoodIdentifier, fittedParaOnOneLakeEachPass);

                #endregion

                #region begin the iteration and update the probability-related attributes for each footprint
                float probDiff = 9999;
                float entropyDiff = 9999;
                float probInitCurrentDiff = 0;

                Dictionary<long, float[]> previousIterProbs = new Dictionary<long, float[]>(pInitialPeakProbs);
                Dictionary<long, float[]> currentIterProbs = new Dictionary<long, float[]>();

                int iterationNum = 1;
                while (probDiff > probDiffStopCriteria && probInitCurrentDiff < probInitCurrDiffStopCriteria && entropyDiff > entropyDiffStopCriteria && iterationNum < maxIterationNumber)
                {
                    foreach (KeyValuePair<long, FootprintNeighborhoodNode> pObjectiveFP in pNeighborhoodIdentifier)
                    {
                        #region update the probability
                        long objectiveFPID = pObjectiveFP.Key;

                        //prepare the output node
                        correctedFPElevNode pCorrFPElevNode;
                        if (pCorrectedElevList.ContainsKey(objectiveFPID)) pCorrFPElevNode = pCorrectedElevList[objectiveFPID];
                        else
                        {
                            pCorrFPElevNode = new correctedFPElevNode();
                            pCorrFPElevNode.ProbabilityChange = new Dictionary<int, List<float>>();
                        }

                        //get the neighbors                        
                        FootprintNeighborhoodNode pFPNeighhoodNode = pObjectiveFP.Value;
                        Dictionary<long, int> pNeighborhood = pFPNeighhoodNode.NeighborsDict;

                        //First determine whether this footprint has neighbors or not
                        if (pNeighborhood.Count == 0)//this FP has no neighbors
                        {
                            #region
                            //set the probability as the initial probability since it has no neighbors
                            float[] pPeakProb = pInitialPeakProbs[objectiveFPID];
                            if (currentIterProbs.ContainsKey(objectiveFPID)) currentIterProbs[objectiveFPID] = pPeakProb;
                            else currentIterProbs.Add(objectiveFPID, pPeakProb);

                            Dictionary<int, List<float>> pProbChangeDict = pCorrFPElevNode.ProbabilityChange;
                            for (int i = 0; i < pPeakProb.Length; i++)
                            {
                                List<float> pProbList;
                                if (pProbChangeDict.ContainsKey(i))
                                {
                                    pProbList = pProbChangeDict[i];
                                    pProbList.Add(pPeakProb[i]);

                                    pProbChangeDict[i] = pProbList;
                                }
                                else
                                {
                                    pProbList = new List<float>();
                                    pProbList.Add(pPeakProb[i]);

                                    pProbChangeDict.Add(i, pProbList);
                                }
                            }

                            pCorrFPElevNode.HasNeighbor = false;
                            pCorrFPElevNode.ProbabilityChange = pProbChangeDict;
                            #endregion
                        }
                        else // this FP does have neighbors
                        {
                            #region
                            //get the peak probabilities in previous iteration for the objective footprint
                            float[] pObjectivePreviousProps = previousIterProbs[objectiveFPID];

                            //iterate through the peaks in this footprint and update the probabilities
                            int objectivePeakNum = pFPNeighhoodNode.PeakNumber;
                            float[] pObjectiveNewProps = new float[objectivePeakNum];
                            float[] pObjectiveNormalizedProps = new float[objectivePeakNum];
                            for (int i = 0; i < objectivePeakNum; i++)
                            {
                                //total increment contributed by all the neighbors
                                float sumQij = 0;

                                //get the compatibility matrix for this peak in this FP
                                string FPID_PeakID = objectiveFPID.ToString() + "_" + i.ToString();
                                Dictionary<string, float> pPeakICompMatrix = pCompatibilityMatrix[FPID_PeakID];

                                foreach (KeyValuePair<long, int> pNeighborFP in pNeighborhood)
                                {
                                    long neighborID = pNeighborFP.Key;
                                    int neighborPeakNum = pNeighborFP.Value;

                                    //get previous peak-probabilities for neighbor footprint
                                    float[] pNeighborPreviousProps = previousIterProbs[neighborID];

                                    for (int j = 0; j < neighborPeakNum; j++)
                                    {
                                        string neighborID_PeakID = neighborID.ToString() + "_" + j.ToString();

                                        //get the probability of peak j in this neighbor footprint
                                        float pPeakjProp = pNeighborPreviousProps[j];

                                        //get the compatibility value 
                                        float compatibilityValue = pPeakICompMatrix[neighborID_PeakID];

                                        sumQij = sumQij + pPeakjProp * compatibilityValue;
                                    }
                                }

                                //average increment contributed by these neighbors
                                float avgQij = sumQij / pNeighborhood.Count;

                                //new probability
                                pObjectiveNewProps[i] = pObjectivePreviousProps[i] * (1 + avgQij);
                            }

                            float totalNewProb = pObjectiveNewProps.Sum();

                            //normalize the new probabilities to the range [-1, 1]
                            pObjectiveNormalizedProps = pObjectiveNewProps.Select(x => x / totalNewProb).ToArray();

                            //control the probability, make sure it's not too too small
                            float maxProbTemp = -9999;
                            int maxProbPos = -1;
                            int numControl = 0;
                            float controlValue = 0.00001f;
                            for (int h = 0; h < pObjectiveNormalizedProps.Length; h++)
                            {
                                if (pObjectiveNormalizedProps[h] < controlValue)
                                {
                                    pObjectiveNormalizedProps[h] = controlValue;
                                    numControl++;
                                }

                                if (pObjectiveNormalizedProps[h]>maxProbTemp)
                                {
                                    maxProbTemp = pObjectiveNormalizedProps[h];
                                    maxProbPos = h;
                                }

                                if (pObjectiveNormalizedProps[h] == 1.0 && pObjectiveNormalizedProps.Length > 1) pObjectiveNormalizedProps[h] = maxProbTemp - controlValue;
                            }
                            if (maxProbTemp == 1.0 && numControl > 0) numControl--;
                            pObjectiveNormalizedProps[maxProbPos] = pObjectiveNormalizedProps[maxProbPos] - numControl * controlValue;

                            if (currentIterProbs.ContainsKey(objectiveFPID)) currentIterProbs[objectiveFPID] = pObjectiveNormalizedProps;
                            else currentIterProbs.Add(objectiveFPID, pObjectiveNormalizedProps);

                            Dictionary<int, List<float>> pProbChangeDict = pCorrFPElevNode.ProbabilityChange;
                            for (int i = 0; i < pObjectiveNormalizedProps.Length; i++)
                            {
                                List<float> pProbList;
                                if (pProbChangeDict.ContainsKey(i))
                                {
                                    pProbList = pProbChangeDict[i];
                                    pProbList.Add(pObjectiveNormalizedProps[i]);

                                    pProbChangeDict[i] = pProbList;
                                }
                                else
                                {
                                    pProbList = new List<float>();
                                    pProbList.Add(pObjectiveNormalizedProps[i]);

                                    pProbChangeDict.Add(i, pProbList);
                                }
                            }

                            pCorrFPElevNode.HasNeighbor = true;
                            pCorrFPElevNode.ProbabilityChange = pProbChangeDict;

                            #endregion
                        }

                        if (pCorrectedElevList.ContainsKey(objectiveFPID)) pCorrectedElevList[objectiveFPID] = pCorrFPElevNode;
                        else pCorrectedElevList.Add(objectiveFPID, pCorrFPElevNode);
                        #endregion
                    }

                    #region calculate and update the iteration-stop variables
                    float tempProbDiff = 0, tempEntropyCurrent=0,  tempEntropyPrevoius= 0, tempProbInitCurrDiff = 0;
                    foreach (KeyValuePair<long, float[]> pCurrentProbsKeyValue in currentIterProbs)
                    {
                        long footprintID = pCurrentProbsKeyValue.Key;

                        #region calculate the stop criteria within the neighborhood
                        float neighborhoodProbDiffSum = 0, neighborhoodEntropyCurrent = 0;
                        float[] pObjCurrentProbs = pCurrentProbsKeyValue.Value;
                        float[] pObjPreviousProbs = previousIterProbs[footprintID];

                        for (int i = 0; i < pObjCurrentProbs.Length;i++)
                        {
                            neighborhoodProbDiffSum = neighborhoodProbDiffSum + Math.Abs(pObjCurrentProbs[i] - pObjPreviousProbs[i]);
                            neighborhoodEntropyCurrent = Convert.ToSingle(neighborhoodEntropyCurrent + (-pObjCurrentProbs[i] * Math.Log(pObjCurrentProbs[i])));
                        }

                        //get the neighborhood
                        FootprintNeighborhoodNode pNeighborhood = pNeighborhoodIdentifier[footprintID];
                        Dictionary<long, int> pNeighbors = pNeighborhood.NeighborsDict;
                        foreach (KeyValuePair<long, int> neighbor in pNeighbors)
                        {
                            long neighborFPID = neighbor.Key;
                            int neighborPeakNum = neighbor.Value;

                            float[] pNeighborCurrentProbs = currentIterProbs[neighborFPID];
                            float[] pNeighborPreviousProbs = previousIterProbs[neighborFPID];

                            for (int i = 0; i < neighborPeakNum; i++)
                            {
                                neighborhoodProbDiffSum = neighborhoodProbDiffSum + Math.Abs(pNeighborCurrentProbs[i] - pNeighborPreviousProbs[i]);
                                neighborhoodEntropyCurrent = Convert.ToSingle(neighborhoodEntropyCurrent + (-pNeighborCurrentProbs[i] * Math.Log(pNeighborCurrentProbs[i])));
                            }
                        }

                        correctedFPElevNode pCorrFPElevNode = pCorrectedElevList[footprintID];
                        Dictionary<int, float> pNeighborhoodProbDiffSumChange; //= new Dictionary<int, float>();//
                        Dictionary<int, float> pNeighborhoodEntropyChange; //= new Dictionary<int, float>();//

                        if (pCorrFPElevNode.NeighborProbDiffSumChang == null) pNeighborhoodProbDiffSumChange = new Dictionary<int, float>();
                        else pNeighborhoodProbDiffSumChange = pCorrFPElevNode.NeighborProbDiffSumChang;

                        if (pCorrFPElevNode.NeighborhoodEntropyChange == null) pNeighborhoodEntropyChange = new Dictionary<int, float>();
                        else pNeighborhoodEntropyChange = pCorrFPElevNode.NeighborhoodEntropyChange;

                        pNeighborhoodProbDiffSumChange.Add(iterationNum, neighborhoodProbDiffSum);
                        pNeighborhoodEntropyChange.Add(iterationNum, neighborhoodEntropyCurrent);

                        pCorrFPElevNode.NeighborProbDiffSumChang = pNeighborhoodProbDiffSumChange;
                        pCorrFPElevNode.NeighborhoodEntropyChange = pNeighborhoodEntropyChange;

                        pCorrectedElevList[footprintID] = pCorrFPElevNode;
                        #endregion



                        float[] pCurrentProbs = pCurrentProbsKeyValue.Value;
                        float[] pPreviousProbs = previousIterProbs[footprintID];
                        float[] pInitialProbs = pInitialPeakProbs[footprintID];
                        for (int i = 0; i < pCurrentProbs.Length; i++)
                        {
                            tempProbDiff = tempProbDiff + Math.Abs(pCurrentProbs[i] - pPreviousProbs[i]);
                            tempEntropyCurrent = Convert.ToSingle(tempEntropyCurrent + (-pCurrentProbs[i] * Math.Log(pCurrentProbs[i])));
                            tempEntropyPrevoius = Convert.ToSingle(tempEntropyPrevoius + (-pPreviousProbs[i] * Math.Log(pPreviousProbs[i])));
                            tempProbInitCurrDiff = tempProbInitCurrDiff + Math.Abs(pCurrentProbs[i] - pInitialProbs[i]);
                        }
                    }

                    #region stop Criteria change in the whole profile
                    //update the iteration-stop variables
                    probDiff = tempProbDiff;
                    probInitCurrentDiff = tempProbInitCurrDiff;
                    entropyDiff = tempEntropyCurrent;//Math.Abs(tempEntropyCurrent - tempEntropyPrevoius);



                    //prepare the output iteration criteria
                    IterationCriteria pIterationCriteria = new IterationCriteria();
                    pIterationCriteria.IterationNum = iterationNum;
                    pIterationCriteria.Entropy = tempEntropyCurrent;
                    pIterationCriteria.ProbDiffAdjacentIter = probDiff;
                    pIterationCriteria.ProbDiffInitialCurrent = probInitCurrentDiff;
                    pStopCriteriaList.Add(pIterationCriteria);
                    #endregion

                    #endregion

                    previousIterProbs = currentIterProbs;
                    currentIterProbs = new Dictionary<long, float[]>();

                    iterationNum++;
                }

                //iteration-stop criteria
                pIterationCriteriaDict.Add(lakeID_Date, pStopCriteriaList);
                #endregion

                #region update the other attributes for each footprint and prepare for output
                foreach (KeyValuePair<long, float[]> pFPPeakProbsKeyValue in previousIterProbs)
                {
                    long pFootprintID = pFPPeakProbsKeyValue.Key;

                    #region get previous datasets
                    //get the alignWaveformDataNode
                    alignWaveformDataNode pInitialDataNode = new alignWaveformDataNode();
                    foreach (alignWaveformDataNode pAlignWFNode in initialAlignedDataset)
                    {
                        long tempFPID = pAlignWFNode.FootprintID;
                        if (tempFPID==pFootprintID)
                        {
                            pInitialDataNode = pAlignWFNode;
                            break;
                        }
                    }

                    //get the fittedGaussianParameterNode
                    fittedGaussianParameterNode pFittedParaNode = new fittedGaussianParameterNode();
                    foreach (fittedGaussianParameterNode pFittedPara in fittedParaOnOneLakeEachPass)
                    {
                        long tempFPID = pFittedPara.FootprintID;
                        if (tempFPID == pFootprintID)
                        {
                            pFittedParaNode = pFittedPara;
                            break;
                        }
                    }

                    #endregion

                    #region Identify the peak for Elev correction based on the relaxation result
                    float[] pProbs = pFPPeakProbsKeyValue.Value;
                    int peakIndex = -9999;
                    float maxProbability = -1;

                    for (int i = 0; i < pProbs.Length; i++)
                    {
                        if (pProbs[i]>maxProbability)
                        {
                            maxProbability = pProbs[i];
                            peakIndex = i;
                        }
                    }
                    #endregion

                    #region populate the other attributes
                    correctedFPElevNode pCorrFPElevNode;
                    if (pCorrectedElevList.ContainsKey(pFootprintID))
                    {
                        pCorrFPElevNode = pCorrectedElevList[pFootprintID];

                        //calculate the corrected elevation
                        float begGateElev = pFittedParaNode.BegGateElev;
                        singleGaussianParameters pSelectedPeak = pFittedParaNode.FittedPeaksParameters[peakIndex];
                        float peakLocation = pSelectedPeak.TimeLocation;
                        float geoidValue = pInitialDataNode.Geoid;
                        //begGateElev has been already corrected by EGM2008
                        float correctedElev = begGateElev - 0.149896f * (peakLocation) +0.075f;// -geoidValue;

                        pCorrFPElevNode.FootprintID = pFootprintID;
                        pCorrFPElevNode.GranulNum = pInitialDataNode.GranulNum;
                        pCorrFPElevNode.SecondIndex = pInitialDataNode.SecondIndex;
                        pCorrFPElevNode.LakeID = pInitialDataNode.LakeID;
                        pCorrFPElevNode.Date = pInitialDataNode.Date;
                        pCorrFPElevNode.ElevDefault = pInitialDataNode.Elev;
                        pCorrFPElevNode.ElevMaxAmp = pInitialDataNode.ElevMaxAmp;
                        pCorrFPElevNode.Latitude = pInitialDataNode.Latitude;
                        pCorrFPElevNode.Longitude = pInitialDataNode.Longitude;
                        pCorrFPElevNode.LandRgOffset = pInitialDataNode.LdRgOffset;
                        pCorrFPElevNode.ValidateDEM = pInitialDataNode.ValidateDEM;
                        pCorrFPElevNode.MaxAmpOffset = pInitialDataNode.ElevMaxAmp - pInitialDataNode.EndGateElev + geoidValue;
                        pCorrFPElevNode.ProbRelaxationOffset = (543 - pFittedParaNode.BegGate - (peakLocation)) * 0.149896f;
                        pCorrFPElevNode.BegGate = pFittedParaNode.BegGate;
                        pCorrFPElevNode.BegGateElev = pFittedParaNode.BegGateElev;
                        pCorrFPElevNode.InitialPeakNum = pFittedParaNode.InitialPeaksParameters.Count;
                        pCorrFPElevNode.FittedPeakNum = pFittedParaNode.FittedPeaksParameters.Count;
                        pCorrFPElevNode.DefaultGauFitSTD = pFittedParaNode.DefaultGauFitSTD;
                        pCorrFPElevNode.NewGauFitSTD = pFittedParaNode.NewGauFitSTD;
                        pCorrFPElevNode.Geoid = geoidValue;
                        pCorrFPElevNode.SNR = pFittedParaNode.SNR;

                        pCorrFPElevNode.ElevProbRelaxation = correctedElev;
                        pCorrFPElevNode.FinalPeakLocation = peakLocation;
                        pCorrFPElevNode.FinalPeakIndex = peakIndex;

                        pCorrectedElevList[pFootprintID] = pCorrFPElevNode;

                    }
                    else
                    {
                        pCorrFPElevNode = new correctedFPElevNode();

                        //calculate the corrected elevation
                        float begGateElev = pFittedParaNode.BegGateElev;
                        singleGaussianParameters pSelectedPeak = pFittedParaNode.FittedPeaksParameters[peakIndex];
                        float peakLocation = pSelectedPeak.TimeLocation;
                        float geoidValue = pInitialDataNode.Geoid;
                        //begGateElev has been already corrected by EGM2008
                        float correctedElev = begGateElev - 0.149896f * (peakLocation) +0.075f;// -geoidValue;

                        pCorrFPElevNode.FootprintID = pFootprintID;
                        pCorrFPElevNode.GranulNum = pInitialDataNode.GranulNum;
                        pCorrFPElevNode.SecondIndex = pInitialDataNode.SecondIndex;
                        pCorrFPElevNode.LakeID = pInitialDataNode.LakeID;
                        pCorrFPElevNode.Date = pInitialDataNode.Date;
                        pCorrFPElevNode.ElevDefault = pInitialDataNode.Elev;
                        pCorrFPElevNode.ElevMaxAmp = pInitialDataNode.ElevMaxAmp;
                        pCorrFPElevNode.Latitude = pInitialDataNode.Latitude;
                        pCorrFPElevNode.Longitude = pInitialDataNode.Longitude;
                        pCorrFPElevNode.LandRgOffset = pInitialDataNode.LdRgOffset;
                        pCorrFPElevNode.ValidateDEM = pInitialDataNode.ValidateDEM;
                        pCorrFPElevNode.MaxAmpOffset = pInitialDataNode.ElevMaxAmp - pInitialDataNode.EndGateElev + geoidValue;
                        pCorrFPElevNode.ProbRelaxationOffset = (543 - pFittedParaNode.BegGate - (peakLocation)) * 0.149896f;
                        pCorrFPElevNode.BegGate = pFittedParaNode.BegGate;
                        pCorrFPElevNode.BegGateElev = pFittedParaNode.BegGateElev;
                        pCorrFPElevNode.InitialPeakNum = pFittedParaNode.InitialPeaksParameters.Count;
                        pCorrFPElevNode.FittedPeakNum = pFittedParaNode.FittedPeaksParameters.Count;
                        pCorrFPElevNode.DefaultGauFitSTD = pFittedParaNode.DefaultGauFitSTD;
                        pCorrFPElevNode.NewGauFitSTD = pFittedParaNode.NewGauFitSTD;
                        pCorrFPElevNode.Geoid = geoidValue;
                        pCorrFPElevNode.SNR = pFittedParaNode.SNR;

                        pCorrFPElevNode.ElevProbRelaxation = correctedElev;
                        pCorrFPElevNode.FinalPeakLocation = peakLocation;
                        pCorrFPElevNode.FinalPeakIndex = peakIndex;

                        pCorrectedElevList.Add(pFootprintID, pCorrFPElevNode);
                    }

                    #endregion
                }

                pProbRelaxationCorrDict.Add(lakeID_Date, pCorrectedElevList);
                #endregion
            }

            #endregion

            return pProbRelaxationCorrDict;
        }

        private Dictionary<string, Dictionary<string, float>> constructMatrix(ref Dictionary<long, FootprintNeighborhoodNode> pNeighborhoodIdentifier, List<fittedGaussianParameterNode> fittedParaOnOneLakeEachPass)
        {
            //1st key string = FootprintID_PeakID; 2nd key string = FootprintID_PeakID; float value -> compatibility
            Dictionary<string, Dictionary<string, float>> pCompatibilityMatrix = new Dictionary<string, Dictionary<string, float>>();

            //iterate through the footprints on one lake in one day
            foreach (fittedGaussianParameterNode pObjectiveFP in fittedParaOnOneLakeEachPass)
            {
                long objectiveFPID = pObjectiveFP.FootprintID;

                //Get the fitted parameters for objective FP 
                List<singleGaussianParameters> pObjectiveFP_FittedParaList = pObjectiveFP.FittedPeaksParameters;
                float objectiveFPBegGateElev = pObjectiveFP.BegGateElev;//Begin-Gate Elev

                //Get the neighbor FPs
                FootprintNeighborhoodNode pNeighborhood = pNeighborhoodIdentifier[objectiveFPID];
                //key = footprintID, Value = number of peaks
                Dictionary<long, int> neighbors = pNeighborhood.NeighborsDict;

                #region pre-judge on whether the neighbors are eligible to provide reliable contextual information
                //if the footprint has a clear and dominant peak, then no need for contextual info
                bool objFPClearHighPeak = false;
                float objElevByMaxPeak = -9999;

                //Fitted peaks
                pObjectiveFP_FittedParaList.Sort((x, y) => -1 * x.Amplitude.CompareTo(y.Amplitude));
                float p1stPeakAmp_Fit = pObjectiveFP_FittedParaList[0].Amplitude;
                float p2ndPeakAmp_Fit;
                if (pObjectiveFP_FittedParaList.Count == 1) p2ndPeakAmp_Fit = 0.0001f;
                else p2ndPeakAmp_Fit = pObjectiveFP_FittedParaList[1].Amplitude;

                //Initial peaks
                List<singleGaussianParameters> pObjectiveFP_InitialParaList = pObjectiveFP.InitialPeaksParameters;
                pObjectiveFP_InitialParaList.Sort((x, y) => -1 * x.Amplitude.CompareTo(y.Amplitude));
                float p1stPeakAmp_initial = pObjectiveFP_InitialParaList[0].Amplitude;
                float p2ndPeakAmp_initial;
                if (pObjectiveFP_InitialParaList.Count == 1) p2ndPeakAmp_initial = 0.0001f;
                else p2ndPeakAmp_initial = pObjectiveFP_InitialParaList[1].Amplitude;

                float obj1stPeakLocation = pObjectiveFP_FittedParaList[0].TimeLocation;
                objElevByMaxPeak = objectiveFPBegGateElev - 0.149896f * obj1stPeakLocation;

                if (p1stPeakAmp_Fit >= highPeakRatio * p2ndPeakAmp_Fit && p1stPeakAmp_Fit >= absHighPeakAmp && p1stPeakAmp_initial >= highPeakRatio * p2ndPeakAmp_initial)
                    objFPClearHighPeak = true;

                /*If there is no eligible neighbor, then set the neighborhood to be empty
                 *or in other words, the neighborhood cannot provide reliable spatially contextual information for the objective footprint
                 */
                if (objFPClearHighPeak)//the highest peak is eligible to give a trustworthy elevation, then it does not need the contextual information
                {
                    //Assign an empty neighbor list
                    pNeighborhood.NeighborsDict = new Dictionary<long, int>();
                    pNeighborhoodIdentifier[objectiveFPID] = pNeighborhood;
                }
                else //the highest peak is ineligible to give a trustworthy elevation, it needs the contextual information from neighbors
                {
                    //define a new neighborhood
                    Dictionary<long, int> newNeighbors = new Dictionary<long, int>();

                    #region neighborhood elev information
                    //the max and the min elevation within this neighborhood
                    float maxElev_5pts = float.MinValue, minElev_5pts = float.MaxValue;

                    //key = footprintID, Value = elevation by max peak
                    Dictionary<long, float> neighborElevList = new Dictionary<long, float>();
                    neighborElevList.Add(objectiveFPID, objElevByMaxPeak);

                    foreach (KeyValuePair<long, int> NeighborFP in neighbors)
                    {
                        long neighborFPID = NeighborFP.Key;
                        //get fitted parameters for the neighbor FP
                        fittedGaussianParameterNode pNeighborFP = new fittedGaussianParameterNode();
                        foreach (fittedGaussianParameterNode pSingleFP_Para in fittedParaOnOneLakeEachPass)
                        {
                            if (pSingleFP_Para.FootprintID == neighborFPID)
                            {
                                pNeighborFP = pSingleFP_Para;
                                break;
                            }
                        }

                        float neighborFPBegGateElev = pNeighborFP.BegGateElev;//Begin-Gate Elev, used for compatibility calculation 
                        List<singleGaussianParameters> pNeighborFP_FittedParaList = pNeighborFP.FittedPeaksParameters;
                        pNeighborFP_FittedParaList.Sort((x, y) => -1 * x.Amplitude.CompareTo(y.Amplitude));

                        float p1stPeakLocation = pNeighborFP_FittedParaList[0].TimeLocation;
                        float neighborElevByMaxPeak = neighborFPBegGateElev - 0.149896f * p1stPeakLocation;

                        if (neighborElevByMaxPeak > maxElev_5pts) maxElev_5pts = neighborElevByMaxPeak;
                        if (neighborElevByMaxPeak < minElev_5pts) minElev_5pts = neighborElevByMaxPeak;

                        neighborElevList.Add(neighborFPID, neighborElevByMaxPeak);
                    }

                    #endregion

                    //Get the max and min tentative elevation given by the fitted highest peak of the waveform within the 5-pts neighborhood
                    if (objElevByMaxPeak > maxElev_5pts) maxElev_5pts = objElevByMaxPeak;
                    if (objElevByMaxPeak < minElev_5pts) minElev_5pts = objElevByMaxPeak;


                    //if the neighborhood is relatively flat, then use it directly
                    //but if not, choose the ones close to object FP elev
                    if ((maxElev_5pts - minElev_5pts) < 2* 0.149896f * flatnessCoef) newNeighbors = neighbors;//the neighborhood is flat
                    else//the neighborhood is not flat, the choose the neighbors
                    {
                        #region find the max and min tentative elev in the 3-pts neighborhood
                        long neighborID_3pts_small = long.MaxValue, neighborID_3pts_large = long.MinValue;
                        float maxElev_3pts = float.MinValue, minElev_3pts = float.MaxValue;

                        foreach (KeyValuePair<long, float> neighborElev in neighborElevList)
                        {
                            long neighborID_temp = neighborElev.Key;

                            if (neighborID_temp <= objectiveFPID && neighborID_temp < neighborID_3pts_small) neighborID_3pts_small = neighborID_temp;
                            if (neighborID_temp >= objectiveFPID && neighborID_temp > neighborID_3pts_large) neighborID_3pts_large = neighborID_temp;

                        }

                        if (neighborElevList[neighborID_3pts_small] > neighborElevList[neighborID_3pts_large])
                        {
                            maxElev_3pts = neighborElevList[neighborID_3pts_small];
                            minElev_3pts = neighborElevList[neighborID_3pts_large];
                        }
                        else
                        {
                            maxElev_3pts = neighborElevList[neighborID_3pts_large];
                            minElev_3pts = neighborElevList[neighborID_3pts_small];
                        }

                        //Get the max and min tentative elevation given by the fitted highest peak of the waveform within the 3-pts neighborhood
                        if (objElevByMaxPeak > maxElev_3pts) maxElev_3pts = objElevByMaxPeak;
                        if (objElevByMaxPeak < minElev_3pts) minElev_3pts = objElevByMaxPeak;
                        #endregion

                        if (maxElev_3pts - minElev_3pts < 0.149896f * flatnessCoef)
                        {
                            newNeighbors.Add(neighborID_3pts_small, neighbors[neighborID_3pts_small]);
                            newNeighbors.Add(neighborID_3pts_large, neighbors[neighborID_3pts_large]);
                        }


                        #region temp
                        //float midElev = (maxElev_5pts + minElev_5pts) / 2;
                        //if (objElevByMaxPeak>=midElev)
                        //{
                        //    foreach (KeyValuePair<long, float> neighborElev in neighborElevList)
                        //    {
                        //        long ID = neighborElev.Key;
                        //        if (neighborElev.Value >= midElev) newNeighbors.Add(ID, neighbors[ID]);
                        //    }
                        //}
                        //else
                        //{
                        //    foreach (KeyValuePair<long, float> neighborElev in neighborElevList)
                        //    {
                        //        long ID = neighborElev.Key;
                        //        if (neighborElev.Value < midElev) newNeighbors.Add(ID, neighbors[ID]);
                        //    }
                        //}
                        #endregion
                    }

                    pNeighborhood.NeighborsDict = newNeighbors;
                    pNeighborhoodIdentifier[objectiveFPID] = pNeighborhood;
                }

                #endregion

                #region calculate compatibility
                //max compatibility, used to normalized the value of compatibility to the range [-1, 1]
                float maxCompatibility = float.MinValue;
                //temporary compatibility matrix, defined for the normalization
                Dictionary<string, Dictionary<string, float>> pTempCompMatrix = new Dictionary<string, Dictionary<string, float>>();

                pObjectiveFP_FittedParaList.Sort((x, y) => x.TimeLocation.CompareTo(y.TimeLocation));
                int objectiveFP_PeakNum = pNeighborhood.PeakNumber;
                
                foreach (KeyValuePair<long,int> pTempNeighbor in neighbors)
                {
                    long neighborFPID = pTempNeighbor.Key;

                    //get fitted parameters for the neighbor FP
                    fittedGaussianParameterNode pNeighborFP = new fittedGaussianParameterNode();
                    foreach (fittedGaussianParameterNode pSingleFP_Para in fittedParaOnOneLakeEachPass)
                    {
                        if (pSingleFP_Para.FootprintID==neighborFPID)
                        {
                            pNeighborFP = pSingleFP_Para;
                            break;
                        }
                    }

                    float neighborFPBegGateElev = pNeighborFP.BegGateElev;//Begin-Gate Elev, used for compatibility calculation 
                    List<singleGaussianParameters> pNeighborFP_FittedParaList = pNeighborFP.FittedPeaksParameters;
                    pNeighborFP_FittedParaList.Sort((x, y) => x.TimeLocation.CompareTo(y.TimeLocation));

                    for (int i = 0; i < objectiveFP_PeakNum; i++)
                    {
                        string objectiveID_PeakNum = objectiveFPID.ToString() + "_" + i.ToString();
                        singleGaussianParameters objectiveFPsinglePeakPara = pObjectiveFP_FittedParaList[i];

                        Dictionary<string, float> pOneObjPeakTempDict;
                        if (pTempCompMatrix.ContainsKey(objectiveID_PeakNum)) pOneObjPeakTempDict = pTempCompMatrix[objectiveID_PeakNum];
                        else pOneObjPeakTempDict = new Dictionary<string, float>();

                        for (int j = 0; j < pNeighborFP_FittedParaList.Count; j++)
                        {
                            singleGaussianParameters neighborFPsinglePeakPara = pNeighborFP_FittedParaList[j];

                            float pCompatibility;
                            if (DisFlag) pCompatibility = calculateCompatibility(objectiveFPsinglePeakPara.TimeLocation, objectiveFPsinglePeakPara.Sigma, objectiveFPBegGateElev, neighborFPsinglePeakPara.TimeLocation, neighborFPsinglePeakPara.Sigma, neighborFPBegGateElev);
                            else pCompatibility = calculateCompatibility2(objectiveFPsinglePeakPara.TimeLocation, objectiveFPsinglePeakPara.Sigma, objectiveFPBegGateElev, neighborFPsinglePeakPara.TimeLocation, neighborFPsinglePeakPara.Sigma, neighborFPBegGateElev);


                            pOneObjPeakTempDict.Add(neighborFPID.ToString() + "_" + j.ToString(), pCompatibility);

                            if (Math.Abs(pCompatibility) > maxCompatibility) maxCompatibility = Math.Abs(pCompatibility);
                        }

                        if (pTempCompMatrix.ContainsKey(objectiveID_PeakNum)) pTempCompMatrix[objectiveID_PeakNum] = pOneObjPeakTempDict;
                        else pTempCompMatrix.Add(objectiveID_PeakNum, pOneObjPeakTempDict);
                    }
                }

                #endregion

                #region Normailize the compatibility
                foreach (KeyValuePair<string, Dictionary<string, float>> pKeyValue in pTempCompMatrix)
                {
                    Dictionary<string, float> newDict = new Dictionary<string, float>();

                    Dictionary<string, float> pTempDict = pKeyValue.Value;

                    foreach (KeyValuePair<string, float> pTempKeyValue in pTempDict)
                    {
                        float normalizedCompValue = Convert.ToSingle(pTempKeyValue.Value / maxCompatibility);
                        newDict.Add(pTempKeyValue.Key, normalizedCompValue);
                    }

                    pCompatibilityMatrix.Add(pKeyValue.Key, newDict);
                }

                #endregion
            }

            return pCompatibilityMatrix;
        }

        private Dictionary<long, FootprintNeighborhoodNode> findNeighbors(List<fittedGaussianParameterNode> fittedParaOnOneLakeEachPass)
        {
            //key footprintID
            Dictionary<long, FootprintNeighborhoodNode> pNeighborhoodIdentifierDict = new Dictionary<long, FootprintNeighborhoodNode>();

            //Determine the max and min ID
            int elementNum = fittedParaOnOneLakeEachPass.Count;
            long maxID = long.MinValue, minID = long.MaxValue;

            foreach (fittedGaussianParameterNode tempFP in fittedParaOnOneLakeEachPass)
            {
                if (tempFP.FootprintID > maxID) maxID = tempFP.FootprintID;
                if (tempFP.FootprintID < minID) minID = tempFP.FootprintID;
            }
            
            foreach (fittedGaussianParameterNode pObjectiveFP in fittedParaOnOneLakeEachPass)
            {
                long objectiveFPID = pObjectiveFP.FootprintID;

                //find the neighboring footprint
                bool sideLargeflag = false, sideSmallflag = false;
                int sideLargeNeighborNum = 0, sideSmallNeighborNum = 0;
                long sideLargeID = objectiveFPID + 1, sideSmallID = objectiveFPID - 1;

                //neighborhood dictionary
                Dictionary<long, int> neighborDict = new Dictionary<long, int>();

                while (!sideLargeflag || !sideSmallflag)
                {
                    //large side
                    foreach (fittedGaussianParameterNode pNeighborFP in fittedParaOnOneLakeEachPass)
                    {
                        if (sideLargeID > maxID || sideLargeflag) break;

                        long neighborFPID = pNeighborFP.FootprintID;
                        if (neighborFPID == sideLargeID)
                        {
                            int peakNum = pNeighborFP.FittedPeaksParameters.Count;
                            sideLargeNeighborNum++;
                            neighborDict.Add(neighborFPID, peakNum);
                            break;
                        }
                    }

                    //small side
                    foreach (fittedGaussianParameterNode pNeighborFP in fittedParaOnOneLakeEachPass)
                    {
                        if (sideSmallID < minID || sideSmallflag) break;

                        long neighborFPID = pNeighborFP.FootprintID;
                        if (neighborFPID == sideSmallID)
                        {
                            int peakNum = pNeighborFP.FittedPeaksParameters.Count;
                            sideSmallNeighborNum++;
                            neighborDict.Add(neighborFPID, peakNum);
                        }
                    }

                    sideLargeID++; sideSmallID--;
                    if (sideLargeID > maxID || sideLargeNeighborNum == numNeighborOneSide) sideLargeflag = true;
                    if (sideSmallID < minID || sideSmallNeighborNum == numNeighborOneSide) sideSmallflag = true;
                }

                //populate the neighborhood list
                FootprintNeighborhoodNode pNewNeighborhood = new FootprintNeighborhoodNode();
                pNewNeighborhood.PeakNumber = pObjectiveFP.FittedPeaksParameters.Count;
                pNewNeighborhood.NeighborsDict = neighborDict;
                pNeighborhoodIdentifierDict.Add(objectiveFPID, pNewNeighborhood);
            }

            return pNeighborhoodIdentifierDict;
        }

        private float calculateCompatibility(float peak1Mean, float peak1Sig, float peak1RefBegElev, float peak2Mean, float peak2Sig, float peak2RefBegElev)
        {
            //Distance between two Univariate-Gaussian, refer
            //Kailath, T. (1967), The Divergence and Bhattacharyya Distance Measures in Signal Selection, IEEE Transactions on Communication Technology, 15(1), 52-60.

            float pDistance = Convert.ToSingle(0.25 * Math.Pow(((peak1RefBegElev - peak2RefBegElev) / 0.149896f - (peak1Mean - peak2Mean)), 2) / (Math.Pow(peak1Sig, 2) + Math.Pow(peak2Sig, 2)) + 0.5 * Math.Log((Math.Pow(peak1Sig, 2) + Math.Pow(peak2Sig, 2)) / (2 * peak1Sig * peak2Sig)));

            //calculate compatibility : the bigger the distance is, the lower the compatibility would be
            //log(1/pDistance)
            return Convert.ToSingle(Math.Log(1 / pDistance));
        }

        private float calculateCompatibility2(float peak1Mean, float peak1Sig, float peak1RefBegElev, float peak2Mean, float peak2Sig, float peak2RefBegElev)
        {
            float locationDis = Convert.ToSingle(Math.Abs((peak1RefBegElev - peak2RefBegElev) / 0.149896f - (peak1Mean - peak2Mean)));

            if (locationDis < 0.05) locationDis = 0.05f;

            //calculate compatibility : the bigger the distance is, the lower the compatibility would be
            //log(1/pDistance)
            return Convert.ToSingle(Math.Log(flatnessCoef / locationDis));
        }

        private float calculateCompatibility3(float peak1Mean, float peak1Sig, float peak1RefBegElev, float peak2Mean, float peak2Sig, float peak2RefBegElev)
        {
            //Distance calculated using the initial formula
            float pDistance = Convert.ToSingle(Math.Abs((peak1RefBegElev - peak2RefBegElev) / 0.149896f - (peak1Mean - peak2Mean)) / (peak1Sig + peak2Sig));


            //calculate compatibility : the bigger the distance is, the lower the compatibility would be
            //log(1/pDistance)
            return Convert.ToSingle(Math.Log(1 / pDistance));
        }

        private Dictionary<long, float[]> calInitialPeakProbability(List<fittedGaussianParameterNode> fittedParaOnOneLakeEachPass)
        {
            Dictionary<long, float[]> pProbability = new Dictionary<long, float[]>();

            //fittedParaOnOneLakeEachPass is one footprint profile on the same lake (footprints on one lake in the same day)
            foreach (fittedGaussianParameterNode pFPParaNode in fittedParaOnOneLakeEachPass)
            {
                long footprintID = pFPParaNode.FootprintID;
                List<singleGaussianParameters> pOneFPFittedParaList = pFPParaNode.FittedPeaksParameters;
                //sort the list so that the first element is the first peak
                pOneFPFittedParaList.Sort((x,y)=>x.TimeLocation.CompareTo(y.TimeLocation));
                
                //sort the list and create a new list
                //List<singleGaussianParameters> ptemp = pOneFPFittedParaList.OrderBy(x => x.TimeLocation).ToList();

                float[] peakAmp = new float[pOneFPFittedParaList.Count], peakProbability = new float[pOneFPFittedParaList.Count];
                float totalAmp = 0;

                int j = 0;
                foreach (singleGaussianParameters pSinglePeakPara in pOneFPFittedParaList)
                {
                    totalAmp = totalAmp + pSinglePeakPara.Amplitude;
                    peakAmp[j] = pSinglePeakPara.Amplitude;
                    j++;
                }

                //calculate the probability
                for (int i = 0; i < peakAmp.Length; i++)
                {
                    float tempValue = peakAmp[i] / totalAmp;

                    peakProbability[i] = tempValue;
                }

                pProbability.Add(footprintID, peakProbability);
            }


            return pProbability;
        }

        #endregion

        #region readin functions
        private Dictionary<string, List<fittedGaussianParameterNode>> readinFittedParameter(string openFittedParameterPathName)
        {
            FileStream readStream = new FileStream(openFittedParameterPathName, FileMode.Open);
            List<Type> knownTypes = new List<Type> { typeof(List<fittedGaussianParameterNode>) };
            DataContractSerializer serializer = new DataContractSerializer(typeof(Dictionary<string, List<fittedGaussianParameterNode>>), knownTypes);

            XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(readStream, new XmlDictionaryReaderQuotas());

            Dictionary<string, List<fittedGaussianParameterNode>> pDictionary = serializer.ReadObject(reader, true) as Dictionary<string, List<fittedGaussianParameterNode>>;

            readStream.Close();

            return pDictionary;
        }

        private Dictionary<string, List<alignWaveformDataNode>> readinInitialDataset(string openInitialDataPathName)
        {
            FileStream ReadStream = new FileStream(openInitialDataPathName, FileMode.Open);

            List<Type> knownTypes = new List<Type> { typeof(List<alignWaveformDataNode>) };
            DataContractSerializer serializer = new DataContractSerializer(typeof(Dictionary<string, List<alignWaveformDataNode>>), knownTypes);

            XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(ReadStream, new XmlDictionaryReaderQuotas());//CreateTextReader(ReadStream, new XmlDictionaryReaderQuotas());

            Dictionary<string, List<alignWaveformDataNode>> ptemp = serializer.ReadObject(reader, true) as Dictionary<string, List<alignWaveformDataNode>>;


            ReadStream.Close();

            return ptemp;
        }

        #endregion
    }
}
