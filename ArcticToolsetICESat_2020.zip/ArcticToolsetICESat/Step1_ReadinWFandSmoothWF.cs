﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace ArcticToolsetICESat
{
    public class ReadinWFandSmoothWF : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public ReadinWFandSmoothWF()
        {
        }

        protected override void OnClick()
        {
            frmReadinAndSmoothWF pForm = new frmReadinAndSmoothWF();
            pForm.ShowDialog();

            ArcMap.Application.CurrentTool = null;
        }

        protected override void OnUpdate()
        {
        }
    }
}
