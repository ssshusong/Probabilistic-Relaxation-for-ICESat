﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace ArcticToolsetICESat
{
    public class AlignWaveforms : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public AlignWaveforms()
        {
        }

        protected override void OnClick()
        {
            frmAlignWaveforms pForm = new frmAlignWaveforms();
            pForm.ShowDialog();

            ArcMap.Application.CurrentTool = null;
        }

        protected override void OnUpdate()
        {
        }
    }
}
