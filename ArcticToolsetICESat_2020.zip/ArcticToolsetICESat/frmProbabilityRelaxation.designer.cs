﻿namespace ArcticToolsetICESat
{
    partial class frmProbabilityRelaxation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnOpenInitial = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.fittingBtn = new System.Windows.Forms.Button();
            this.btnOpn = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(95, 50);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(235, 20);
            this.textBox2.TabIndex = 46;
            // 
            // btnOpenInitial
            // 
            this.btnOpenInitial.Location = new System.Drawing.Point(344, 48);
            this.btnOpenInitial.Name = "btnOpenInitial";
            this.btnOpenInitial.Size = new System.Drawing.Size(53, 23);
            this.btnOpenInitial.TabIndex = 45;
            this.btnOpenInitial.Text = "Open";
            this.btnOpenInitial.UseVisualStyleBackColor = true;
            this.btnOpenInitial.Click += new System.EventHandler(this.btnOpenInitial_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 44;
            this.label3.Text = "Fitted Parameter: ";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(344, 75);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(53, 23);
            this.btnSave.TabIndex = 43;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 42;
            this.label2.Text = "Output: ";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(95, 77);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(235, 20);
            this.textBox3.TabIndex = 41;
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(258, 112);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(57, 23);
            this.CancelBtn.TabIndex = 40;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = true;
            // 
            // fittingBtn
            // 
            this.fittingBtn.Location = new System.Drawing.Point(72, 112);
            this.fittingBtn.Name = "fittingBtn";
            this.fittingBtn.Size = new System.Drawing.Size(57, 23);
            this.fittingBtn.TabIndex = 39;
            this.fittingBtn.Text = "OK";
            this.fittingBtn.UseVisualStyleBackColor = true;
            this.fittingBtn.Click += new System.EventHandler(this.fittingBtn_Click);
            // 
            // btnOpn
            // 
            this.btnOpn.Location = new System.Drawing.Point(344, 19);
            this.btnOpn.Name = "btnOpn";
            this.btnOpn.Size = new System.Drawing.Size(53, 23);
            this.btnOpn.TabIndex = 38;
            this.btnOpn.Text = "Open";
            this.btnOpn.UseVisualStyleBackColor = true;
            this.btnOpn.Click += new System.EventHandler(this.btnOpn_Click);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(1, 24);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(77, 13);
            this.Label1.TabIndex = 37;
            this.Label1.Text = "Initial Dataset: ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(95, 21);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(235, 20);
            this.textBox1.TabIndex = 36;
            // 
            // frmProbabilityRelaxation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 147);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.btnOpenInitial);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.fittingBtn);
            this.Controls.Add(this.btnOpn);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.textBox1);
            this.MaximizeBox = false;
            this.Name = "frmProbabilityRelaxation";
            this.Text = "Probability Relaxation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox textBox2;
        internal System.Windows.Forms.Button btnOpenInitial;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Button btnSave;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.TextBox textBox3;
        internal System.Windows.Forms.Button CancelBtn;
        internal System.Windows.Forms.Button fittingBtn;
        internal System.Windows.Forms.Button btnOpn;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox textBox1;
    }
}