﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace ArcticToolsetICESat
{
    public class IdentifyPeaks : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        public IdentifyPeaks()
        {
        }

        protected override void OnClick()
        {
            frmIdentifyPeaks pform = new frmIdentifyPeaks();
            pform.ShowDialog();

            ArcMap.Application.CurrentTool = null;
        }

        protected override void OnUpdate()
        {
        }
    }
}
